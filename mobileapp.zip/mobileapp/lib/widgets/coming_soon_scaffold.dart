import 'package:flutter/material.dart';

/// Shared shell for sections that aren't built out yet.
class ComingSoonScaffold extends StatelessWidget {
  final String title;

  const ComingSoonScaffold({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xff020B23),
      appBar: AppBar(
        backgroundColor: const Color(0xff020B23),
        elevation: 0,
        title: Text(
          title,
          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
      body: const Center(
        child: Text(
          "Coming Soon",
          style: TextStyle(color: Colors.white70, fontSize: 18, fontWeight: FontWeight.w600),
        ),
      ),
    );
  }
}
