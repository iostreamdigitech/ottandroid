import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import '../player/controllers/payment_engine.dart';
import '../player/models/payment_state.dart';

/// Full-bleed payment surface, shared by every purchase flow.
///
/// Renders each non-idle [PaymentStatus]: the three progress steps, the
/// success screen and the failure screen. It reads engine state and calls
/// back - it owns no payment logic of its own.
///
/// Stack it over whatever page started the purchase; it collapses to nothing
/// while [PaymentStatus.idle].
class PaymentStatusOverlay extends StatelessWidget {
  final PaymentEngine engine;

  /// Success screen - the button is labelled by the purchase itself.
  final VoidCallback onContinue;

  /// Failure screen, "Try Again".
  final VoidCallback onRetry;

  const PaymentStatusOverlay({
    super.key,
    required this.engine,
    required this.onContinue,
    required this.onRetry,
  });

  static const Color _background = Color(0xff020B23);
  static const Color _surface = Color(0xff151C35);
  static const Color _primary = Color(0xff7A3CFF);
  static const Color _secondary = Color(0xffFF2D75);
  static const Color _success = Color(0xff22C55E);
  static const Color _danger = Color(0xffFF4D67);

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      final PaymentStatus status = engine.paymentStatus.value;

      if (status == PaymentStatus.idle) {
        return const SizedBox.shrink();
      }

      return _scrim(
        child: AnimatedSwitcher(
          duration: const Duration(milliseconds: 250),
          child: _panel(
            context,
            status: status,
            child: _bodyFor(status),
          ),
        ),
      );
    });
  }

  // ---------------------------------------------------------------------------
  // CHROME
  // ---------------------------------------------------------------------------

  Widget _scrim({required Widget child}) {
    // Expands rather than using Positioned: this widget sits inside an Obx,
    // so it is never the direct child of the Stack that hosts it and a
    // Positioned here would be rejected as misplaced parent data.
    return SizedBox.expand(
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
        child: Container(
          color: _background.withOpacity(.92),
          child: SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(
                  horizontal: 24,
                  vertical: 32,
                ),
                child: child,
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _panel(
    BuildContext context, {
    required PaymentStatus status,
    required Widget child,
  }) {
    return ConstrainedBox(
      key: ValueKey(status),
      constraints: const BoxConstraints(maxWidth: 440),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(
          horizontal: 28,
          vertical: 36,
        ),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(28),
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              _surface,
              Color(0xff0D1530),
            ],
          ),
          border: Border.all(
            color: Colors.white.withOpacity(.08),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(.35),
              blurRadius: 30,
              offset: const Offset(0, 14),
            ),
          ],
        ),
        child: child,
      ),
    );
  }

  Widget _bodyFor(PaymentStatus status) {
    switch (status) {
      case PaymentStatus.success:
        return _successBody();
      case PaymentStatus.failed:
        return _failureBody();
      default:
        return _progressBody(status);
    }
  }

  // ---------------------------------------------------------------------------
  // PROGRESS
  // ---------------------------------------------------------------------------

  Widget _progressBody(PaymentStatus status) {
    final String plan = engine.itemTitle.value;

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        const SizedBox(
          height: 62,
          width: 62,
          child: CircularProgressIndicator(
            strokeWidth: 3,
            valueColor: AlwaysStoppedAnimation(_primary),
            backgroundColor: Color(0x337A3CFF),
          ),
        ),

        const SizedBox(height: 28),

        _title(engine.paymentTitle.value),

        const SizedBox(height: 10),

        _message(engine.paymentMessage.value),

        if (plan.isNotEmpty) ...[
          const SizedBox(height: 22),
          _planChip(plan),
        ],

        // The verify step is the one the user must not interrupt, so it gets
        // an explicit warning rather than a generic spinner caption.
        if (status == PaymentStatus.verifying) ...[
          const SizedBox(height: 22),
          _notice(
            icon: Icons.lock_outline,
            text: 'Your payment is being confirmed with your bank.',
          ),
        ],
      ],
    );
  }

  // ---------------------------------------------------------------------------
  // SUCCESS
  // ---------------------------------------------------------------------------

  Widget _successBody() {
    final result = engine.verification.value;

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        _badge(
          icon: Icons.check_rounded,
          colors: const [_success, Color(0xff16A34A)],
        ),

        const SizedBox(height: 26),

        _title(engine.paymentTitle.value),

        const SizedBox(height: 10),

        _message(engine.paymentMessage.value),

        if (result != null && result.hasSubscriptionDetails) ...[
          const SizedBox(height: 24),
          _subscriptionSummary(result.planName, result.endDate),
        ],

        if (engine.transactionId.value.isNotEmpty) ...[
          const SizedBox(height: 20),
          _reference(
            label: 'Transaction ID',
            value: engine.transactionId.value,
          ),
        ],

        const SizedBox(height: 30),

        _primaryButton(
          // "Continue Watching" after a subscription, "Watch Now" after a
          // rental - the purchase decides its own wording.
          label: engine.continueLabel.value,
          icon: Icons.play_arrow_rounded,
          onTap: onContinue,
        ),
      ],
    );
  }

  Widget _subscriptionSummary(String planName, String endDate) {
    final String validTill = _formatDate(endDate);

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(
        horizontal: 18,
        vertical: 16,
      ),
      decoration: BoxDecoration(
        color: _success.withOpacity(.10),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: _success.withOpacity(.28),
        ),
      ),
      child: Column(
        children: [
          if (planName.isNotEmpty)
            Text(
              planName,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 17,
                fontWeight: FontWeight.w700,
              ),
            ),

          if (planName.isNotEmpty && validTill.isNotEmpty)
            const SizedBox(height: 6),

          if (validTill.isNotEmpty)
            Text(
              'Active until $validTill',
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Colors.white70,
                fontSize: 13,
              ),
            ),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // FAILURE
  // ---------------------------------------------------------------------------

  Widget _failureBody() {
    final bool cancelled =
        engine.failureKind.value == PaymentFailureKind.cancelled;

    final String detail = engine.paymentErrorDetail.value;

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        _badge(
          icon: cancelled
              ? Icons.close_rounded
              : Icons.priority_high_rounded,
          colors: cancelled
              ? const [Color(0xff64748B), Color(0xff475569)]
              : const [_danger, Color(0xffD92D4B)],
        ),

        const SizedBox(height: 26),

        _title(engine.paymentTitle.value),

        const SizedBox(height: 10),

        _message(engine.paymentMessage.value),

        if (detail.isNotEmpty) ...[
          const SizedBox(height: 18),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(
              horizontal: 16,
              vertical: 12,
            ),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(.04),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: Colors.white.withOpacity(.08),
              ),
            ),
            child: Text(
              detail,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Colors.white60,
                fontSize: 13,
                height: 1.4,
              ),
            ),
          ),
        ],

        // References matter most when money may have moved - they are what
        // support will ask for.
        if (engine.transactionId.value.isNotEmpty) ...[
          const SizedBox(height: 18),
          _reference(
            label: 'Transaction ID',
            value: engine.transactionId.value,
          ),
        ],

        if (engine.orderId.value.isNotEmpty) ...[
          const SizedBox(height: 10),
          _reference(
            label: 'Order ID',
            value: engine.orderId.value,
          ),
        ],

        const SizedBox(height: 30),

        _primaryButton(
          label: 'Try Again',
          icon: Icons.refresh_rounded,
          onTap: onRetry,
        ),
      ],
    );
  }

  // ---------------------------------------------------------------------------
  // PIECES
  // ---------------------------------------------------------------------------

  Widget _badge({
    required IconData icon,
    required List<Color> colors,
  }) {
    return Container(
      height: 84,
      width: 84,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: colors,
        ),
        boxShadow: [
          BoxShadow(
            color: colors.first.withOpacity(.35),
            blurRadius: 26,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Icon(
        icon,
        color: Colors.white,
        size: 46,
      ),
    );
  }

  Widget _title(String text) {
    return Text(
      text,
      textAlign: TextAlign.center,
      style: const TextStyle(
        color: Colors.white,
        fontSize: 22,
        fontWeight: FontWeight.w800,
        letterSpacing: -0.3,
      ),
    );
  }

  Widget _message(String text) {
    if (text.isEmpty) {
      return const SizedBox.shrink();
    }

    return Text(
      text,
      textAlign: TextAlign.center,
      style: const TextStyle(
        color: Colors.white70,
        fontSize: 14,
        height: 1.5,
      ),
    );
  }

  Widget _planChip(String planName) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 16,
        vertical: 8,
      ),
      decoration: BoxDecoration(
        color: _primary.withOpacity(.14),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: _primary.withOpacity(.35),
        ),
      ),
      child: Text(
        planName,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 13,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  Widget _notice({
    required IconData icon,
    required String text,
  }) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(
          icon,
          color: Colors.white38,
          size: 15,
        ),
        const SizedBox(width: 8),
        Flexible(
          child: Text(
            text,
            style: const TextStyle(
              color: Colors.white38,
              fontSize: 12,
            ),
          ),
        ),
      ],
    );
  }

  Widget _reference({
    required String label,
    required String value,
  }) {
    return Column(
      children: [
        Text(
          label,
          style: const TextStyle(
            color: Colors.white38,
            fontSize: 11,
            letterSpacing: .6,
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 4),
        SelectableText(
          value,
          textAlign: TextAlign.center,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 14,
            fontWeight: FontWeight.w600,
            letterSpacing: .4,
          ),
        ),
      ],
    );
  }

  Widget _primaryButton({
    required String label,
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return SizedBox(
      width: double.infinity,
      height: 52,
      child: DecoratedBox(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          gradient: const LinearGradient(
            colors: [_primary, _secondary],
          ),
          boxShadow: [
            BoxShadow(
              color: _primary.withOpacity(.30),
              blurRadius: 18,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: onTap,
            child: Center(
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    icon,
                    color: Colors.white,
                    size: 20,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    label,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  /// Backends return dates in a few shapes; show a friendly one when we can
  /// parse it, otherwise show exactly what was sent.
  String _formatDate(String raw) {
    if (raw.isEmpty) {
      return '';
    }

    final DateTime? parsed = DateTime.tryParse(raw);

    if (parsed == null) {
      return raw;
    }

    return DateFormat('d MMM yyyy').format(parsed);
  }
}
