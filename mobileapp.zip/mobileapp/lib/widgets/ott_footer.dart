import 'package:flutter/material.dart';

class FooterItem {
  final String title;
  final VoidCallback? onTap;

  const FooterItem({
    required this.title,
    this.onTap,
  });
}

class OTTFooter extends StatelessWidget {
  const OTTFooter({super.key});

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;

    final bool isMobile = width < 700;
    final bool isTablet = width >= 700 && width < 1100;

    return Container(
      width: double.infinity,
      color: const Color(0xff0B0F12),
      child: Column(
        children: [
          // =====================================================
          // MAIN FOOTER
          // =====================================================

          Padding(
            padding: EdgeInsets.symmetric(
              horizontal: isMobile
                  ? 24
                  : isTablet
                  ? 36
                  : 60,
              vertical: isMobile ? 35 : 48,
            ),
            child: ConstrainedBox(
              constraints: const BoxConstraints(
                maxWidth: 1400,
              ),
              child: isMobile
                  ? _buildMobileFooter(context)
                  : _buildDesktopFooter(
                context,
                isTablet: isTablet,
              ),
            ),
          ),

          // =====================================================
          // DIVIDER
          // =====================================================

          Container(
            height: 1,
            color: Colors.white.withOpacity(.08),
          ),

          // =====================================================
          // BOTTOM COPYRIGHT
          // =====================================================

          Padding(
            padding: EdgeInsets.symmetric(
              horizontal: isMobile ? 24 : 60,
              vertical: 20,
            ),
            child: ConstrainedBox(
              constraints: const BoxConstraints(
                maxWidth: 1400,
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      "© 2026 OTTONE. All rights reserved.",
                      style: TextStyle(
                        color: Colors.white.withOpacity(.45),
                        fontSize: 12,
                      ),
                    ),
                  ),

                  if (!isMobile)
                    Text(
                      "www.myottone.com",
                      style: TextStyle(
                        color: Colors.white.withOpacity(.35),
                        fontSize: 12,
                      ),
                    ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // DESKTOP FOOTER
  // ============================================================

  Widget _buildDesktopFooter(
      BuildContext context, {
        required bool isTablet,
      }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // ======================================================
        // BRAND
        // ======================================================

        Expanded(
          flex: 3,
          child: _buildBrandSection(
            isMobile: false,
          ),
        ),

        SizedBox(
          width: isTablet ? 35 : 70,
        ),

        // ======================================================
        // COMPANY
        // ======================================================

        Expanded(
          flex: 2,
          child: _buildCompanySection(context),
        ),

        const SizedBox(width: 35),

        // ======================================================
        // HELP
        // ======================================================

        Expanded(
          flex: 2,
          child: _buildHelpSection(context),
        ),

        const SizedBox(width: 35),

        // ======================================================
        // DOWNLOAD
        // ======================================================

        Expanded(
          flex: 2,
          child: _buildDownloadSection(),
        ),
      ],
    );
  }

  // ============================================================
  // MOBILE FOOTER
  // ============================================================

  Widget _buildMobileFooter(
      BuildContext context,
      ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildBrandSection(
          isMobile: true,
        ),

        const SizedBox(height: 35),

        _buildSectionDivider(),

        const SizedBox(height: 28),

        _buildCompanySection(context),

        const SizedBox(height: 28),

        _buildSectionDivider(),

        const SizedBox(height: 28),

        _buildHelpSection(context),

        const SizedBox(height: 28),

        _buildSectionDivider(),

        const SizedBox(height: 28),

        _buildDownloadSection(),
      ],
    );
  }

  // ============================================================
  // BRAND SECTION
  // ============================================================

  Widget _buildBrandSection({
    required bool isMobile,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // LOGO

        Image.asset(
          "assets/ottonelogo.png",
          height: 40,
          fit: BoxFit.contain,
        ),

        const SizedBox(height: 18),

        Text(
          "Your entertainment, anytime, anywhere.",
          style: TextStyle(
            color: Colors.white.withOpacity(.48),
            fontSize: 13,
            height: 1.5,
          ),
        ),

        const SizedBox(height: 22),

        // SOCIAL ICONS

        Row(
          children: [
            _SocialButton(
              icon: Icons.facebook_outlined,
              tooltip: "Facebook",
              onTap: () {
                debugPrint("Facebook");
              },
            ),

            const SizedBox(width: 10),

            _SocialButton(
              icon: Icons.camera_alt_outlined,
              tooltip: "Instagram",
              onTap: () {
                debugPrint("Instagram");
              },
            ),

            const SizedBox(width: 10),

            _SocialButton(
              icon: Icons.alternate_email,
              tooltip: "Twitter/X",
              onTap: () {
                debugPrint("Twitter/X");
              },
            ),

            const SizedBox(width: 10),

            _SocialButton(
              icon: Icons.play_circle_outline,
              tooltip: "YouTube",
              onTap: () {
                debugPrint("YouTube");
              },
            ),
          ],
        ),

        if (isMobile) ...[
          const SizedBox(height: 22),

          Text(
            "© 2026 OTTONE. All rights reserved.",
            style: TextStyle(
              color: Colors.white.withOpacity(.4),
              fontSize: 12,
            ),
          ),
        ],
      ],
    );
  }

  // ============================================================
  // COMPANY
  // ============================================================

  Widget _buildCompanySection(
      BuildContext context,
      ) {
    return _buildFooterGroup(
      title: "Company",
      items: [
        FooterItem(
          title: "About",
          onTap: () {
            Navigator.pushNamed(
              context,
              "/about",
            );
          },
        ),

        FooterItem(
          title: "Careers",
          onTap: () {
            Navigator.pushNamed(
              context,
              "/careers",
            );
          },
        ),

        FooterItem(
          title: "www.myottone.com",
          onTap: () {
            debugPrint("Website");
          },
        ),

        FooterItem(
          title: "Send Feedback",
          onTap: () {
            Navigator.pushNamed(
              context,
              "/feedback",
            );
          },
        ),

        FooterItem(
          title: "info@myottone.com",
          onTap: () {
            debugPrint("Email");
          },
        ),
      ],
    );
  }

  // ============================================================
  // HELP
  // ============================================================

  Widget _buildHelpSection(
      BuildContext context,
      ) {
    return _buildFooterGroup(
      title: "Help & Legal",
      items: [
        FooterItem(
          title: "Need Help?",
          onTap: () {},
        ),

        FooterItem(
          title: "Visit Help Center",
          onTap: () {
            Navigator.pushNamed(
              context,
              "/help",
            );
          },
        ),

        FooterItem(
          title: "Terms of Use",
          onTap: () {
            Navigator.pushNamed(
              context,
              "/terms",
            );
          },
        ),

        FooterItem(
          title: "Privacy Policy",
          onTap: () {
            Navigator.pushNamed(
              context,
              "/privacy",
            );
          },
        ),

        FooterItem(
          title: "Refund Policy",
          onTap: () {
            Navigator.pushNamed(
              context,
              "/refund",
            );
          },
        ),
      ],
    );
  }

  // ============================================================
  // DOWNLOAD
  // ============================================================

  Widget _buildDownloadSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          "Download it on",
          style: TextStyle(
            color: Colors.white70,
            fontSize: 14,
            fontWeight: FontWeight.w600,
          ),
        ),

        const SizedBox(height: 16),

        _DownloadButton(
          asset: "assets/googleplay.png",
          onTap: () {
            debugPrint("Google Play");
          },
        ),

        const SizedBox(height: 12),

        _DownloadButton(
          asset: "assets/appstore.png",
          onTap: () {
            debugPrint("App Store");
          },
        ),
      ],
    );
  }

  // ============================================================
  // FOOTER GROUP
  // ============================================================

  Widget _buildFooterGroup({
    required String title,
    required List<FooterItem> items,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 15,
            fontWeight: FontWeight.w700,
          ),
        ),

        const SizedBox(height: 18),

        ...items.map(
              (item) => Padding(
            padding: const EdgeInsets.only(
              bottom: 12,
            ),
            child: _FooterLink(
              item: item,
            ),
          ),
        ),
      ],
    );
  }

  // ============================================================
  // SECTION DIVIDER
  // ============================================================

  Widget _buildSectionDivider() {
    return Container(
      height: 1,
      width: double.infinity,
      color: Colors.white.withOpacity(.06),
    );
  }
}

// ================================================================
// SOCIAL BUTTON
// ================================================================

class _SocialButton extends StatefulWidget {
  final IconData icon;
  final String tooltip;
  final VoidCallback onTap;

  const _SocialButton({
    required this.icon,
    required this.tooltip,
    required this.onTap,
  });

  @override
  State<_SocialButton> createState() =>
      _SocialButtonState();
}

class _SocialButtonState
    extends State<_SocialButton> {
  bool hover = false;

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: widget.tooltip,
      child: MouseRegion(
        cursor: SystemMouseCursors.click,
        onEnter: (_) {
          setState(() {
            hover = true;
          });
        },
        onExit: (_) {
          setState(() {
            hover = false;
          });
        },
        child: GestureDetector(
          onTap: widget.onTap,
          child: AnimatedContainer(
            duration: const Duration(
              milliseconds: 180,
            ),
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: hover
                  ? Colors.white.withOpacity(.12)
                  : Colors.white.withOpacity(.05),
              borderRadius:
              BorderRadius.circular(20),
              border: Border.all(
                color: Colors.white.withOpacity(
                  hover ? .18 : .08,
                ),
              ),
            ),
            child: Icon(
              widget.icon,
              color: hover
                  ? Colors.white
                  : Colors.white70,
              size: 20,
            ),
          ),
        ),
      ),
    );
  }
}

// ================================================================
// DOWNLOAD BUTTON
// ================================================================

class _DownloadButton extends StatefulWidget {
  final String asset;
  final VoidCallback onTap;

  const _DownloadButton({
    required this.asset,
    required this.onTap,
  });

  @override
  State<_DownloadButton> createState() =>
      _DownloadButtonState();
}

class _DownloadButtonState
    extends State<_DownloadButton> {
  bool hover = false;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      onEnter: (_) {
        setState(() {
          hover = true;
        });
      },
      onExit: (_) {
        setState(() {
          hover = false;
        });
      },
      child: GestureDetector(
        onTap: widget.onTap,
        child: AnimatedContainer(
          duration: const Duration(
            milliseconds: 180,
          ),
          width: 170,
          padding: const EdgeInsets.all(2),
          decoration: BoxDecoration(
            borderRadius:
            BorderRadius.circular(9),
            boxShadow: hover
                ? [
              BoxShadow(
                color: Colors.black
                    .withOpacity(.35),
                blurRadius: 12,
                offset:
                const Offset(0, 5),
              ),
            ]
                : null,
          ),
          child: ClipRRect(
            borderRadius:
            BorderRadius.circular(7),
            child: Image.asset(
              widget.asset,
              width: 170,
              fit: BoxFit.contain,
            ),
          ),
        ),
      ),
    );
  }
}

// ================================================================
// FOOTER LINK
// ================================================================

class _FooterLink extends StatefulWidget {
  final FooterItem item;

  const _FooterLink({
    required this.item,
  });

  @override
  State<_FooterLink> createState() =>
      _FooterLinkState();
}

class _FooterLinkState
    extends State<_FooterLink> {
  bool hover = false;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      onEnter: (_) {
        setState(() {
          hover = true;
        });
      },
      onExit: (_) {
        setState(() {
          hover = false;
        });
      },
      child: GestureDetector(
        onTap: widget.item.onTap,
        child: AnimatedDefaultTextStyle(
          duration: const Duration(
            milliseconds: 160,
          ),
          style: TextStyle(
            color: hover
                ? Colors.white
                : Colors.white60,
            fontSize: 14,
            height: 1.3,
            fontWeight: hover
                ? FontWeight.w500
                : FontWeight.w400,
            decoration: hover
                ? TextDecoration.underline
                : TextDecoration.none,
            decorationColor:
            Colors.white70,
          ),
          child: Text(
            widget.item.title,
          ),
        ),
      ),
    );
  }
}