import 'package:flutter/material.dart';

import '../features/home/models/movie.dart';


/// Reusable clickable poster card used across the home page movie rows.
class MovieCardWidget extends StatelessWidget {
  final Movie movie;
  final VoidCallback onTap;
  final double width;

  const MovieCardWidget({
    super.key,
    required this.movie,
    required this.onTap,
    this.width = 160,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: width,
        margin: const EdgeInsets.symmetric(horizontal: 8),
        decoration: BoxDecoration(
          color: const Color(0xff141E38),
          borderRadius: BorderRadius.circular(15),
        ),
        child: Column(
          children: [
            Expanded(
              child: ClipRRect(
                borderRadius: const BorderRadius.vertical(top: Radius.circular(15)),
                child: Image.network(
                  movie.posterUrl,
                  fit: BoxFit.cover,
                  width: double.infinity,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    movie.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: Colors.white),
                  ),
                  if (movie.progress != null) ...[
                    const SizedBox(height: 5),
                    LinearProgressIndicator(
                      value: movie.progress,
                      color: Colors.red,
                      backgroundColor: Colors.grey.shade800,
                    ),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
