import 'package:flutter/material.dart';

import '../features/home/models/movie.dart';



class MovieInformationCard extends StatelessWidget {
  final Movie movie;

  const MovieInformationCard(
      this.movie, {
        super.key,
      });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(28),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.05),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(
          color: Colors.white10,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(.25),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [

          const Row(
            children: [
              Icon(
                Icons.info_outline,
                color: Colors.redAccent,
                size: 26,
              ),
              SizedBox(width: 10),
              Text(
                "Movie Information",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 26,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),

          const SizedBox(height: 30),

          Row(
            children: [

              Expanded(
                child: Column(
                  children: [

                    _infoTile(
                      Icons.calendar_month,
                      "Release Date",
                      movie.year ?? "-",
                    ),

                    _divider(),

                    _infoTile(
                      Icons.schedule,
                      "Runtime",
                      movie.duration ?? "-",
                    ),

                    _divider(),

                    _infoTile(
                      Icons.language,
                      "Language",
                      movie.genre ?? "-",
                    ),

                    _divider(),

                    _infoTile(
                      Icons.subtitles,
                      "Subtitle",
                      movie.title ?? "English",
                    ),
                  ],
                ),
              ),

              const SizedBox(width: 30),

              Expanded(
                child: Column(
                  children: [

                    _infoTile(
                      Icons.movie_creation_outlined,
                      "Genre",
                      movie.genre ?? "-",
                    ),

                    _divider(),

                    _infoTile(
                      Icons.high_quality,
                      "Video Quality",
                      "4K HDR",
                    ),

                    _divider(),

                    _infoTile(
                      Icons.surround_sound,
                      "Audio",
                      "Dolby Atmos",
                    ),

                    _divider(),

                    _infoTile(
                      Icons.person_outline,
                      "Director",
                      "-",
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _divider() {
    return Divider(
      color: Colors.white.withOpacity(.08),
      height: 26,
    );
  }

  Widget _infoTile(
      IconData icon,
      String title,
      String value,
      ) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [

          Container(
            width: 46,
            height: 46,
            decoration: BoxDecoration(
              color: Colors.redAccent.withOpacity(.12),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
              icon,
              color: Colors.redAccent,
              size: 22,
            ),
          ),

          const SizedBox(width: 16),

          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [

                Text(
                  title,
                  style: const TextStyle(
                    color: Colors.white54,
                    fontSize: 13,
                  ),
                ),

                const SizedBox(height: 4),

                Text(
                  value,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 17,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}