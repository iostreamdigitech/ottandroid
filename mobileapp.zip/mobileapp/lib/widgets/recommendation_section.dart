import 'package:flutter/material.dart';

import '../features/home/models/movie.dart';



class RecommendationSection extends StatelessWidget {
  final List<Movie> movies;
  final Function(Movie)? onMovieTap;

  const RecommendationSection({
    super.key,
    required this.movies,
    this.onMovieTap,
  });

  @override
  Widget build(BuildContext context) {
    if (movies.isEmpty) return const SizedBox();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [

        Row(
          children: const [

            Icon(
              Icons.local_fire_department,
              color: Colors.redAccent,
              size: 30,
            ),

            SizedBox(width: 10),

            Text(
              "More Like This",
              style: TextStyle(
                color: Colors.white,
                fontSize: 30,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),

        const SizedBox(height: 25),

        SizedBox(
          height: 360,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: movies.length,
            separatorBuilder: (_, __) =>
            const SizedBox(width: 20),
            itemBuilder: (_, index) {
              return _RecommendationCard(
                movie: movies[index],
                onTap: () => onMovieTap?.call(movies[index]),
              );
            },
          ),
        ),
      ],
    );
  }
}

class _RecommendationCard extends StatefulWidget {
  final Movie movie;
  final VoidCallback? onTap;

  const _RecommendationCard({
    required this.movie,
    this.onTap,
  });

  @override
  State<_RecommendationCard> createState() =>
      _RecommendationCardState();
}

class _RecommendationCardState
    extends State<_RecommendationCard> {

  bool hover = false;

  @override
  Widget build(BuildContext context) {

    return MouseRegion(
      onEnter: (_) => setState(() => hover = true),
      onExit: (_) => setState(() => hover = false),

      child: GestureDetector(
        onTap: widget.onTap,

        child: AnimatedContainer(
          duration: const Duration(milliseconds: 250),

          width: 210,

          transform: Matrix4.identity()
            ..scale(hover ? 1.05 : 1.0),

          child: Column(
            crossAxisAlignment:
            CrossAxisAlignment.start,

            children: [

              Expanded(
                child: ClipRRect(
                  borderRadius:
                  BorderRadius.circular(20),

                  child: Stack(
                    fit: StackFit.expand,
                    children: [

                      Image.network(
                        widget.movie.posterUrl ?? "",
                        fit: BoxFit.cover,
                      ),

                      AnimatedOpacity(
                        opacity: hover ? 1 : 0,
                        duration: const Duration(
                          milliseconds: 250,
                        ),

                        child: Container(
                          color: Colors.black54,

                          child: const Center(
                            child: CircleAvatar(
                              radius: 34,
                              backgroundColor:
                              Colors.redAccent,

                              child: Icon(
                                Icons.play_arrow,
                                color: Colors.white,
                                size: 42,
                              ),
                            ),
                          ),
                        ),
                      ),

                      Positioned(
                        top: 12,
                        right: 12,

                        child: Container(
                          padding:
                          const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 6,
                          ),

                          decoration: BoxDecoration(
                            color: Colors.black87,
                            borderRadius:
                            BorderRadius.circular(20),
                          ),

                          child: Row(
                            mainAxisSize:
                            MainAxisSize.min,
                            children: [

                              const Icon(
                                Icons.star,
                                color: Colors.amber,
                                size: 14,
                              ),

                              const SizedBox(width: 4),

                              Text(
                                "${widget.movie.rating ?? "8.5"}",
                                style:
                                const TextStyle(
                                  color: Colors.white,
                                  fontWeight:
                                  FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 12),

              Text(
                widget.movie.title,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,

                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 5),

              Text(
                "${widget.movie.genre ?? ""} • ${widget.movie.year ?? ""}",
                style: const TextStyle(
                  color: Colors.white70,
                  fontSize: 14,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}