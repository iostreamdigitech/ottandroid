import 'package:flutter/material.dart';

import '../core/constants/app_colors.dart';

import '../features/home/models/movie.dart';
import 'gradient_button.dart';
import 'info_chip.dart';

class MovieInfo extends StatelessWidget {
  final Movie movie;

  /// Routed through the play gate by [MovieDetailPage] - this widget never
  /// opens the player itself.
  final VoidCallback onPlay;

  const MovieInfo(
    this.movie, {
    super.key,
    required this.onPlay,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [

          /// Movie Title
          Text(
            movie.title,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 34,
              fontWeight: FontWeight.bold,
              height: 1.1,
            ),
          ),

          const SizedBox(height: 18),

          /// Movie Info Chips
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              if (movie.year.isNotEmpty) InfoChip(movie.year),
              if (movie.duration.isNotEmpty) InfoChip(movie.duration),
              if (movie.genre.isNotEmpty) InfoChip(movie.genre),
              if (movie.rating > 0) InfoChip("⭐ ${movie.rating}"),
            ],
          ),

          const SizedBox(height: 18),

          /// Rating
          Row(
            children: [
              const Icon(
                Icons.star_rounded,
                color: Colors.amber,
                size: 22,
              ),
              const SizedBox(width: 6),
              Text(
                "${movie.rating}/5",
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                ),
              ),
              const SizedBox(width: 10),
              const Text(
                "• 12.5K Ratings",
                style: TextStyle(
                  color: Colors.white60,
                  fontSize: 15,
                ),
              ),
            ],
          ),

          const SizedBox(height: 28),

          /// Play Button
          SizedBox(
            width: double.infinity,
            child: GradientButton(
              title: "Play",
              icon: Icons.play_arrow_rounded,
              onTap: onPlay,
            ),
          ),

          const SizedBox(height: 14),

          /// My List
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              style: OutlinedButton.styleFrom(
                minimumSize: const Size(double.infinity, 56),
                side: const BorderSide(color: Colors.white24),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
              ),
              icon: const Icon(
                Icons.add,
                color: Colors.white,
              ),
              label: const Text(
                "My List",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 17,
                ),
              ),
              onPressed: () {},
            ),
          ),

          const SizedBox(height: 28),

          /// Movie Details Card
          Container(
            decoration: BoxDecoration(
              color: AppColors.card,
              borderRadius: BorderRadius.circular(22),
            ),
            padding: const EdgeInsets.symmetric(
              horizontal: 18,
              vertical: 22,
            ),
            child: Row(
              children: [

                Expanded(
                  child: _StatItem(
                    Icons.calendar_today_outlined,
                    "Release",
                    movie.year,
                  ),
                ),

                Expanded(
                  child: _StatItem(
                    Icons.schedule,
                    "Duration",
                    movie.duration,
                  ),
                ),

                Expanded(
                  child: _StatItem(
                    Icons.movie_outlined,
                    "Genre",
                    movie.genre,
                  ),
                ),

                Expanded(
                  child: _StatItem(
                    Icons.verified_user_outlined,
                    "Rating",
                    "U/A",
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _StatItem extends StatelessWidget {
  final IconData icon;
  final String title;
  final String value;

  const _StatItem(
      this.icon,
      this.title,
      this.value,
      );

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [

        Icon(
          icon,
          color: Colors.white70,
          size: 26,
        ),

        const SizedBox(height: 10),

        Text(
          title,
          style: const TextStyle(
            color: Colors.white54,
            fontSize: 12,
          ),
        ),

        const SizedBox(height: 6),

        Text(
          value,
          textAlign: TextAlign.center,
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w600,
            fontSize: 14,
          ),
        ),
      ],
    );
  }
}