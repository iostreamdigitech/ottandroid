import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../models/subscription_plan.dart';
import '../player/controllers/subscription_controller.dart';
import '../player/models/payment_state.dart';

/// Presentation for a single plan.
///
/// The Subscribe button hands straight off to
/// [SubscriptionController.subscribe] - no API call, no Razorpay, no
/// navigation lives here.
class SubscriptionCard extends StatelessWidget {
  final SubscriptionPlan plan;

  SubscriptionCard({
    super.key,
    required this.plan,
  });

  final SubscriptionController controller =
      Get.find<SubscriptionController>();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xff151C35),
            Color(0xff0D1530),
          ],
        ),
        border: Border.all(
          color: Colors.white.withOpacity(.08),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(.25),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            plan.planName,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 22,
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 12),

          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                '${plan.currency} ${plan.price.toStringAsFixed(0)}',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 32,
                  fontWeight: FontWeight.w800,
                ),
              ),

              const SizedBox(width: 5),

              const Padding(
                padding: EdgeInsets.only(
                  bottom: 5,
                ),
                child: Text(
                  '/ plan',
                  style: TextStyle(
                    color: Colors.white54,
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: 18),

          ...plan.features.map(
            (feature) => Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Row(
                children: [
                  const Icon(
                    Icons.check_circle,
                    color: Color(0xff8B5CF6),
                    size: 18,
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      feature,
                      style: const TextStyle(
                        color: Colors.white70,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 20),

          _subscribeButton(),
        ],
      ),
    );
  }

  /// Dimmed and inert while any payment is in flight, so a second tap cannot
  /// start a second order behind the payment placeholder.
  Widget _subscribeButton() {
    return Obx(() {
      final bool busy = controller
          .payments
          .paymentStatus
          .value
          .blocksPlanSelection;

      return Opacity(
        opacity: busy ? .55 : 1,
        child: SizedBox(
          width: double.infinity,
          height: 50,
          child: DecoratedBox(
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [
                  Color(0xff7A3CFF),
                  Color(0xffFF2D75),
                ],
              ),
              borderRadius: BorderRadius.circular(14),
            ),
            child: ElevatedButton(
              onPressed: busy
                  ? null
                  : () {
                      controller.subscribe(plan);
                    },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.transparent,
                disabledBackgroundColor: Colors.transparent,
                shadowColor: Colors.transparent,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),
              child: const Text(
                'Subscribe Now',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ),
      );
    });
  }
}
