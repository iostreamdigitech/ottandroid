import 'package:flutter/material.dart';

import '../core/constants/app_colors.dart';
import '../features/home/models/movie.dart';


class MovieHeader extends StatelessWidget {
  final Movie movie;

  const MovieHeader({
    super.key,
    required this.movie,
  });

  @override
  Widget build(BuildContext context) {
    return SliverAppBar(
      backgroundColor: AppColors.bg,
      pinned: true,
      stretch: true,
      elevation: 0,
      expandedHeight: 320,

      iconTheme: const IconThemeData(
        color: Colors.white,
      ),

      actions: [
        IconButton(
          icon: const Icon(Icons.cast_rounded),
          onPressed: () {
            // TODO Cast
          },
        ),
        IconButton(
          icon: const Icon(Icons.share_outlined),
          onPressed: () {
            // TODO Share
          },
        ),
        const SizedBox(width: 8),
      ],

      flexibleSpace: FlexibleSpaceBar(
        collapseMode: CollapseMode.parallax,
        background: ClipRRect(
          borderRadius: const BorderRadius.only(
            bottomLeft: Radius.circular(28),
            bottomRight: Radius.circular(28),
          ),
          child: Stack(
            fit: StackFit.expand,
            children: [

              /// Banner
              Image.network(
                (movie.bannerUrl?.isNotEmpty ?? false)
                    ? movie.bannerUrl!
                    : movie.posterUrl,
                fit: BoxFit.cover,

                loadingBuilder: (
                    context,
                    child,
                    progress,
                    ) {
                  if (progress == null) return child;

                  return Container(
                    color: Colors.black,
                    child: const Center(
                      child: CircularProgressIndicator(),
                    ),
                  );
                },

                errorBuilder: (
                    context,
                    error,
                    stackTrace,
                    ) {
                  return Container(
                    color: Colors.grey.shade900,
                    child: const Center(
                      child: Icon(
                        Icons.movie_creation_outlined,
                        color: Colors.white54,
                        size: 70,
                      ),
                    ),
                  );
                },
              ),

              /// Dark Overlay
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    stops: const [
                      0.0,
                      0.45,
                      0.75,
                      1.0,
                    ],
                    colors: [
                      Colors.transparent,
                      Colors.black.withOpacity(.20),
                      Colors.black.withOpacity(.70),
                      AppColors.bg,
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}