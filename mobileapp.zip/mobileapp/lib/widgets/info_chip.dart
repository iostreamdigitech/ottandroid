import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class InfoChip extends StatelessWidget {

  final String text;

  const InfoChip(this.text,{super.key});

  @override
  Widget build(BuildContext context) {

    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 14,
        vertical: 8,
      ),

      decoration: BoxDecoration(
        color: const Color(0xff141E38),
        borderRadius: BorderRadius.circular(14),
      ),

      child: Text(
        text,
        style: const TextStyle(
          color: Colors.white70,
          fontSize: 13,
        ),
      ),
    );
  }
}