import 'dart:ui';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';

import '../models/BannerModel.dart';

class HeroBanner extends StatefulWidget {
  final List<BannerModel> banners;

  const HeroBanner({
    super.key,
    required this.banners,
  });

  @override
  State<HeroBanner> createState() => _HeroBannerState();
}

class _HeroBannerState extends State<HeroBanner> {
  final CarouselSliderController _controller =
  CarouselSliderController();

  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery
        .of(context)
        .size;

    final bool isDesktop = size.width >= 1200;
    final bool isTablet =
        size.width >= 700 && size.width < 1200;
    final bool isMobile = size.width < 700;

    final bannerHeight = isDesktop
        ? 580.0
        : isTablet
        ? 450.0
        : 400.0;

    if (widget.banners.isEmpty) {
      return const SizedBox.shrink();
    }

    return Column(
      children: [

        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 18),

          child: Container(
            height: bannerHeight,

            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(30),

              border: Border.all(
                color: Colors.white10,
              ),

              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(.40),
                  blurRadius: 25,
                  offset: const Offset(0, 12),
                )
              ],
            ),

            child: ClipRRect(
              borderRadius: BorderRadius.circular(30),

              child: CarouselSlider.builder(

                carouselController: _controller,

                itemCount: widget.banners.length,

                options: CarouselOptions(
                  viewportFraction: 1,
                  height: bannerHeight,
                  enlargeCenterPage: false,

                  autoPlay: true,
                  autoPlayCurve: Curves.easeInOutCubic,
                  autoPlayInterval: const Duration(seconds: 5),
                  autoPlayAnimationDuration: const Duration(milliseconds: 900),

                  scrollPhysics: const BouncingScrollPhysics(),

                  pageSnapping: true,

                  enableInfiniteScroll: true,

                  onPageChanged: (index, reason) {
                    if (mounted) {
                      setState(() {
                        _currentIndex = index;
                      });
                    }
                  },
                ),

                itemBuilder:
                    (context, index, realIndex) {
                  final banner =
                  widget.banners[index];

                  return _buildBanner(
                    context,
                    banner,
                    isMobile,
                    isTablet,
                    isDesktop,
                  );
                },
              ),
            ),
          ),
        ),

        const SizedBox(height: 18),


      ],
    );
  }


  String _getBannerImage(BannerModel banner,
      bool isMobile,
      bool isTablet,
      bool isDesktop,) {
    if (isDesktop) {
      return banner.webBannerUrl;
    }

    if (isTablet) {
      return banner.tvBannerUrl.isNotEmpty
          ? banner.tvBannerUrl
          : banner.webBannerUrl;
    }

    return banner.mobileBannerUrl;
  }

  Widget _buildBanner(BuildContext context,
      BannerModel banner,
      bool isMobile,
      bool isTablet,
      bool isDesktop,) {
    return Stack(
      fit: StackFit.expand,
      children: [

        /// Background Image
        Hero(
          tag: banner.id,
          child: CachedNetworkImage(
            imageUrl: _getBannerImage(
              banner,
              isMobile,
              isTablet,
              isDesktop,
            ),
            fit: BoxFit.cover,
            fadeInDuration: const Duration(milliseconds: 500),
            placeholder: (context, url) =>
                Container(
                  color: const Color(0xff111827),
                  child: const Center(
                    child: CircularProgressIndicator(
                      color: Colors.white,
                    ),
                  ),
                ),
            errorWidget: (_, __, ___) =>
                Container(
                  color: Colors.black,
                  child: const Icon(
                    Icons.broken_image,
                    color: Colors.white38,
                    size: 60,
                  ),
                ),
          ),
        ),

        /// Left Gradient
        Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
              colors: [
                const Color(0xff020B23),
                const Color(0xff020B23).withOpacity(.95),
                const Color(0xff020B23).withOpacity(.70),
                Colors.transparent,
              ],
              stops: const [
                0,
                .35,
                .70,
                1,
              ],
            ),
          ),
        ),

        /// Bottom Gradient
        Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.bottomCenter,
              end: Alignment.topCenter,
              colors: [
                Colors.black.withOpacity(.85),
                Colors.black.withOpacity(.20),
                Colors.transparent,
              ],
            ),
          ),
        ),
        if (!isDesktop)
        /// Glass Blur
        BackdropFilter(
          filter: ImageFilter.blur(
            sigmaX: 1.2,
            sigmaY: 1.2,
          ),
          child: Container(
            color: Colors.transparent,
          ),
        ),

        /// Desktop Floating Poster
        if (isDesktop)
          Positioned(
            right: 50,
            bottom: 45,
            child: Hero(
              tag: "${banner.id}_poster",
              child: Container(
                width: 220,
                height: 320,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(
                    color: Colors.white12,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(.45),
                      blurRadius: 30,
                      offset: const Offset(0, 18),
                    ),
                  ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(24),
                  child: CachedNetworkImage(
                    imageUrl: _getBannerImage(
                      banner,
                      isMobile,
                      isTablet,
                      isDesktop,
                    ),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
          ),

        /// Content
        Positioned(
          left: isMobile ? 20 : 45,
          bottom: isMobile ? 30 : 55,
          child: SizedBox(
            width: isDesktop
                ? 520
                : isTablet
                ? 430
                : MediaQuery
                .of(context)
                .size
                .width - 70,
            child: _buildContent(
              context,
              banner,
              isMobile,
            ),
          ),
        ),

        /// Indicator Overlay
        Positioned(
          left: 0,
          right: 0,
          bottom: 12,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(
              widget.banners.length,
                  (index) {
                final active = index == _currentIndex;

                return AnimatedContainer(
                  duration:
                  const Duration(milliseconds: 300),
                  margin: const EdgeInsets.symmetric(
                    horizontal: 4,
                  ),
                  height: 8,
                  width: active ? 20 : 8,
                  decoration: BoxDecoration(
                    color: active
                        ? Colors.white
                        : Colors.white38,
                    borderRadius:
                    BorderRadius.circular(20),
                  ),
                );
              },
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildContent(BuildContext context,
      BannerModel banner,
      bool isMobile,) {
    final width = MediaQuery.of(context).size.width;

    double titleSize;

    if (width >= 1400) {
      titleSize = 58;
    } else if (width >= 1200) {
      titleSize = 52;
    } else if (width >= 900) {
      titleSize = 44;
    } else if (width >= 700) {
      titleSize = 38;
    } else if (width >= 500) {
      titleSize = 30;
    } else {
      titleSize = 20;
    }
    final descWidth = MediaQuery.of(context).size.width * .42;


    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.end,
      children: [

        /// NEW RELEASE
        Container(
          padding: const EdgeInsets.symmetric(
            horizontal: 12,
            vertical: 6,
          ),
          decoration: BoxDecoration(
            color: const Color(0xff2563EB),
            borderRadius: BorderRadius.circular(30),
          ),
          child: const Text(
            "NEW RELEASE",
            style: TextStyle(
              color: Colors.white,
              fontSize: 12,
              fontWeight: FontWeight.w600,
              letterSpacing: 1,
            ),
          ),
        ),

        const SizedBox(height: 18),

        /// Movie Title
        Text(
          banner.title,
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: titleSize,
            height: 1.05,
          ),
        ),

        const SizedBox(height: 14),

        /// Movie Info
        Wrap(
          spacing: 8,
          crossAxisAlignment: WrapCrossAlignment.center,
          children: [

            _infoChip("2026"),
            _dot(),
            _infoChip(
              "Action",
            ),
            _dot(),
            _infoChip("2h 18m"),
            _dot(),
            _infoChip("UA 16+"),

          ],
        ),

        const SizedBox(height: 18),

        /// Description
        SizedBox(
          width: descWidth,
          child: Text(
            banner.description,
            maxLines: 3,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: Colors.white70,
              fontSize: 15,
              height: 1.6,
            ),
          ),
        ),

        const SizedBox(height: 28),

        /// Buttons
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: [
              _watchNowButton(banner),
              const SizedBox(width: 16),
              _myListButton(banner),
            ],
          ),
        )
      ],
    );
  }
  Widget _watchNowButton(BannerModel banner) {
    return SizedBox(
      height: 52,
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () => _watchNow(banner),
        child: Ink(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            gradient: const LinearGradient(
              colors: [
                Color(0xff6D4CFF),
                Color(0xffFF2E63),
              ],
            ),
          ),
          child: const Padding(
            padding: EdgeInsets.symmetric(
              horizontal: 24,
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.play_arrow_rounded, color: Colors.white),
                SizedBox(width: 8),
                Text(
                  "Watch Now",
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
  Widget _myListButton(BannerModel banner) {
    return SizedBox(
      height: 52,
      child: OutlinedButton.icon(
        onPressed: () => _addToWatchList(banner),
        icon: const Icon(Icons.add, color: Colors.white),
        label: const Text(
          "My List",
          style: TextStyle(color: Colors.white),
        ),
        style: OutlinedButton.styleFrom(
          side: BorderSide(
            color: Colors.white.withOpacity(.15),
          ),
          backgroundColor: Colors.white.withOpacity(.05),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
          ),
        ),
      ),
    );
  }
  /// Small text widget
  Widget _infoChip(String text) {
    return Text(
      text,
      style: const TextStyle(
        color: Colors.white70,
        fontSize: 14,
        fontWeight: FontWeight.w500,
      ),
    );
  }

  /// Bullet separator
  Widget _dot() {
    return Container(
      width: 4,
      height: 4,
      decoration: const BoxDecoration(
        color: Colors.white54,
        shape: BoxShape.circle,
      ),
    );
  }

  /// Banner Tap
  void _onBannerTap(BannerModel banner) {
    switch (banner.clickAction.toUpperCase()) {
      case "MOVIE":
      // TODO:
      // Navigator.push(...MovieDetailsPage());
        break;

      case "SERIES":
      // TODO:
        break;

      case "LIVE":
      // TODO:
        break;

      case "EXTERNAL":
      // TODO:
        break;

      default:
        break;
    }
  }

  /// Watch Now Button
  void _watchNow(BannerModel banner) {
    _onBannerTap(banner);
  }

  /// Add to Watchlist
  void _addToWatchList(BannerModel banner) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: const Color(0xff111827),
        content: Text(
          "${banner.title} added to My List",
        ),
      ),
    );
  }
}