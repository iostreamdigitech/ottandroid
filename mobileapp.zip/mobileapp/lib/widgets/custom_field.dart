import 'package:flutter/material.dart';

class CustomField extends StatelessWidget {

  final TextEditingController controller;
  final String hint;
  final IconData icon;

  final bool obscureText;
  final TextInputType keyboardType;

  final String? Function(String?)? validator;


  const CustomField({

    super.key,

    required this.controller,

    required this.hint,

    required this.icon,

    this.obscureText = false,

    this.keyboardType = TextInputType.text,

    this.validator,

  });


  @override
  Widget build(BuildContext context) {

    return TextFormField(

      controller: controller,

      obscureText: obscureText,

      keyboardType: keyboardType,

      validator: validator,


      style: const TextStyle(
        color: Colors.white,
        fontSize: 16,
      ),


      decoration: InputDecoration(

        hintText: hint,

        hintStyle: const TextStyle(
          color: Colors.white54,
        ),


        prefixIcon: Icon(
          icon,
          color: Colors.white70,
        ),


        filled: true,

        fillColor:
        Colors.white.withOpacity(0.12),


        contentPadding:
        const EdgeInsets.symmetric(
          vertical: 18,
          horizontal: 16,
        ),


        border: OutlineInputBorder(

          borderRadius:
          BorderRadius.circular(16),

          borderSide:
          BorderSide.none,

        ),


        enabledBorder:
        OutlineInputBorder(

          borderRadius:
          BorderRadius.circular(16),

          borderSide:
          BorderSide.none,

        ),


        focusedBorder:
        OutlineInputBorder(

          borderRadius:
          BorderRadius.circular(16),

          borderSide:
          const BorderSide(
            color: Color(0xffff1100),
            width: 1.5,
          ),

        ),


        errorBorder:
        OutlineInputBorder(

          borderRadius:
          BorderRadius.circular(16),

          borderSide:
          const BorderSide(
            color: Colors.red,
          ),

        ),

      ),

    );

  }

}