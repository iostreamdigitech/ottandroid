import 'package:flutter/material.dart';

import '../features/home/models/movie.dart';


class ScreenshotSection extends StatelessWidget {
  final Movie movie;

  const ScreenshotSection({
    super.key,
    required this.movie,
  });

  @override
  Widget build(BuildContext context) {
    final screenshots = [];

    if (screenshots.isEmpty) {
      return const SizedBox();
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [

        const Row(
          children: [
            Icon(
              Icons.photo_library_outlined,
              color: Colors.redAccent,
            ),
            SizedBox(width: 10),
            Text(
              "Screenshots",
              style: TextStyle(
                color: Colors.white,
                fontSize: 28,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),

        const SizedBox(height: 24),

        SizedBox(
          height: 200,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: screenshots.length,
            separatorBuilder: (_, __) => const SizedBox(width: 18),
            itemBuilder: (context, index) {
              return _ScreenshotCard(
                image: screenshots[index],
              );
            },
          ),
        ),
      ],
    );
  }
}

class _ScreenshotCard extends StatefulWidget {
  final String image;

  const _ScreenshotCard({
    required this.image,
  });

  @override
  State<_ScreenshotCard> createState() => _ScreenshotCardState();
}

class _ScreenshotCardState extends State<_ScreenshotCard> {
  bool hover = false;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      onEnter: (_) => setState(() => hover = true),
      onExit: (_) => setState(() => hover = false),
      child: GestureDetector(
        onTap: () => _openPreview(context),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          width: 340,
          transform: Matrix4.identity()
            ..scale(hover ? 1.04 : 1.0),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: hover
                    ? Colors.black54
                    : Colors.black26,
                blurRadius: hover ? 18 : 8,
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: Stack(
              fit: StackFit.expand,
              children: [

                Image.network(
                  widget.image,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) =>
                      Container(color: Colors.grey.shade900),
                ),

                AnimatedOpacity(
                  duration: const Duration(milliseconds: 250),
                  opacity: hover ? 1 : 0,
                  child: Container(
                    color: Colors.black45,
                    child: const Center(
                      child: Icon(
                        Icons.fullscreen,
                        color: Colors.white,
                        size: 42,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _openPreview(BuildContext context) {
    showDialog(
      context: context,
      barrierColor: Colors.black87,
      builder: (_) {
        return Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.all(30),
          child: Stack(
            children: [

              InteractiveViewer(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: Image.network(
                    widget.image,
                    fit: BoxFit.contain,
                  ),
                ),
              ),

              Positioned(
                top: 20,
                right: 20,
                child: CircleAvatar(
                  backgroundColor: Colors.black54,
                  child: IconButton(
                    icon: const Icon(
                      Icons.close,
                      color: Colors.white,
                    ),
                    onPressed: () => Navigator.pop(context),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}