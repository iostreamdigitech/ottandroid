import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:ottoneapp/widgets/recommendation_section.dart';
import 'package:ottoneapp/widgets/screenshot_section.dart';

import '../features/home/models/movie.dart';
import '../models/CastMember.dart';

import '../screens/movie_detail.dart';
import 'cast_section.dart';
import 'movie_desktop_header.dart';
import 'movie_information_card.dart';
import 'movie_quick_info.dart';
import 'overview.dart';

class MovieDesktopLayout extends StatelessWidget {
  final Movie movie;
  final VoidCallback onPlay;
  const MovieDesktopLayout({
    super.key,
    required this.movie,
    required this.onPlay,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xff050A18),

      body: CustomScrollView(
        slivers: [

          /// Hero Banner
          SliverToBoxAdapter(
            child: MovieDesktopHeader(
              movie: movie,
              onPlay: onPlay,
            ),
          ),

          /// Content
          SliverPadding(
            padding: const EdgeInsets.symmetric(
              horizontal: 40,
              vertical: 30,
            ),

            sliver: SliverToBoxAdapter(
              child: Center(
                child: ConstrainedBox(
                  constraints:
                  const BoxConstraints(maxWidth: 1500),

                  child: Column(
                    children: [

                      Row(
                        crossAxisAlignment:
                        CrossAxisAlignment.start,

                        children: [

                          Expanded(
                            flex: 3,
                            child: MovieInformationCard(movie),
                          ),

                          const SizedBox(width: 30),

                          SizedBox(
                            width: 320,
                            child: MovieQuickInfo(movie),
                          ),
                        ],
                      ),

                      const SizedBox(height: 35),

                      Overview(movie),

                      const SizedBox(height: 35),

                      CastSection(
                        cast: [
                          CastMember(
                            name: "Naslen",
                            role: "Lead Role",
                            image: "assets/cast/naslen.jpg",
                          ),
                          CastMember(
                            name: "Mamitha Baiju",
                            role: "Lead Role",
                            image: "assets/cast/mamitha.jpg",
                          ),
                          CastMember(
                            name: "Sangeeth Prathap",
                            role: "Supporting",
                            image: "assets/cast/sangeeth.jpg",
                          ),
                          CastMember(
                            name: "Akshara Kishor",
                            role: "Supporting",
                            image: "assets/cast/akshara.jpg",
                          ),
                          CastMember(
                            name: "Shyam Mohan",
                            role: "Supporting",
                            image: "assets/cast/shyam.jpg",
                          ),
                        ],
                      ),

                      const SizedBox(height: 35),

                      ScreenshotSection(
                        movie: movie,
                      ),

                      const SizedBox(height: 35),




                      RecommendationSection(
                        movies: [
                          Movie(
                            id: 101,
                            title: "Leo",
                            posterUrl:
                            "https://image.tmdb.org/t/p/w500/8b8R8l88Qje9dn9OE8PY05Nxl1X.jpg",
                            rating: 8.4,
                            genre: "Action",
                            year: "2023", videoUrl: '',
                          ),
                          Movie(
                            id: 102,
                            title: "Jailer",
                            posterUrl:
                            "https://image.tmdb.org/t/p/w500/eA9ZQfWQjA4L6JQ7F4iAfDdcQa1.jpg",
                            rating: 8.1,
                            genre: "Action",
                            year: "2023",videoUrl: '',
                          ),
                          Movie(
                            id: 103,
                            title: "Vikram",
                            posterUrl:
                            "https://image.tmdb.org/t/p/w500/9z4jRr43JdtU66P0xOtr0QjzY4n.jpg",
                            rating: 8.6,
                            genre: "Action",
                            year: "2022",videoUrl: '',
                          ),
                          Movie(
                            id: 104,
                            title: "Master",
                            posterUrl:
                            "https://image.tmdb.org/t/p/w500/1ukwQbK4JmEX7KAF6m5XwM4K4rK.jpg",
                            rating: 7.9,
                            genre: "Drama",
                            year: "2021",videoUrl: '',
                          ),
                          Movie(
                            id: 105,
                            title: "Tourist Family",
                            posterUrl:
                            "https://picsum.photos/300/450?random=10",
                            rating: 8.9,
                            genre: "Comedy",
                            year: "2025",videoUrl: '',
                          ),
                          Movie(
                            id: 106,
                            title: "Dragon",
                            posterUrl:
                            "https://picsum.photos/300/450?random=11",
                            rating: 8.5,
                            genre: "Drama",
                            year: "2025",videoUrl: '',
                          ),
                        ],
                        onMovieTap: (movie) {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => MovieDetailPage(movie: movie),
                            ),
                          );
                        },
                      ),

                      const SizedBox(height: 60),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}