import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../models/CastMember.dart';
import 'cast_card.dart';

class CastSection extends StatelessWidget {
  final List<CastMember> cast;

  const CastSection({
    super.key,
    required this.cast,
  });

  @override
  Widget build(BuildContext context) {
    if (cast.isEmpty) return const SizedBox();

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 18),
      child: Column(
        children: [
          Row(
            children: [
              const Expanded(
                child: Text(
                  "Cast & Crew",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              TextButton(
                onPressed: () {},
                child: const Text(
                  "See All",
                  style: TextStyle(
                    color: Colors.deepPurpleAccent,
                  ),
                ),
              )
            ],
          ),

          const SizedBox(height: 15),

          SizedBox(
            height: 165,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              physics: const BouncingScrollPhysics(),
              itemCount: cast.length,
              separatorBuilder: (_, __) => const SizedBox(width: 14),
              itemBuilder: (_, index) {
                return CastCard(member: cast[index]);
              },
            ),
          ),
        ],
      ),
    );
  }
}