import 'package:flutter/material.dart';


InputDecoration fieldDecoration(
    String hint,
    IconData icon,
    ) {

  return InputDecoration(

    hintText: hint,

    hintStyle: const TextStyle(
      color: Colors.white54,
      fontSize: 15,
    ),


    prefixIcon: Icon(
      icon,
      color: Colors.white70,
    ),


    filled: true,

    fillColor:
    Colors.white.withOpacity(0.12),


    contentPadding:
    const EdgeInsets.symmetric(
      vertical: 18,
      horizontal: 16,
    ),


    border: OutlineInputBorder(

      borderRadius:
      BorderRadius.circular(16),

      borderSide:
      BorderSide.none,

    ),


    enabledBorder: OutlineInputBorder(

      borderRadius:
      BorderRadius.circular(16),

      borderSide:
      BorderSide.none,

    ),


    focusedBorder: OutlineInputBorder(

      borderRadius:
      BorderRadius.circular(16),

      borderSide:
      const BorderSide(
        color: Color(0xffff1100),
        width: 1.5,
      ),

    ),


    errorBorder: OutlineInputBorder(

      borderRadius:
      BorderRadius.circular(16),

      borderSide:
      const BorderSide(
        color: Colors.red,
      ),

    ),

  );
}