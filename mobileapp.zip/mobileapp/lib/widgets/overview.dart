import 'package:flutter/material.dart';
import 'package:readmore/readmore.dart';

import '../core/constants/app_colors.dart';
import '../features/home/models/movie.dart';


class Overview extends StatelessWidget {
  final Movie movie;

  const Overview(this.movie, {super.key});

  Widget _infoRow({
    required String title,
    required String value,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: RichText(
        text: TextSpan(
          style: const TextStyle(
            fontSize: 15,
            height: 1.5,
          ),
          children: [
            TextSpan(
              text: "$title: ",
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w600,
              ),
            ),
            TextSpan(
              text: value,
              style: const TextStyle(
                color: Colors.white70,
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          /// Header
          Row(
            children: [
              const Expanded(
                child: Text(
                  "Overview",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),

              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: AppColors.card,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(
                  Icons.favorite_border,
                  color: Colors.white70,
                ),
              ),
            ],
          ),

          const SizedBox(height: 20),

          _infoRow(
            title: "Director",
            value: "Girish A.D.",
          ),

          _infoRow(
            title: "Cast",
            value: "Naslen, Mamitha Baiju, Sangeeth Prathap",
          ),

          _infoRow(
            title: "Genre",
            value: movie.genre,
          ),

          _infoRow(
            title: "Language",
            value: "Malayalam",
          ),

          _infoRow(
            title: "Quality",
            value: "4K • Dolby Vision • HDR10+",
          ),

          const SizedBox(height: 18),

          const Divider(
            color: Colors.white12,
          ),

          const SizedBox(height: 18),

          ReadMoreText(
            movie.description.isEmpty
                ? "No description available."
                : movie.description,
            trimLines: 4,
            trimMode: TrimMode.Line,
            trimCollapsedText: " Read More",
            trimExpandedText: " Show Less",
            style: const TextStyle(
              color: Colors.white70,
              fontSize: 15,
              height: 1.8,
            ),
            moreStyle: const TextStyle(
              color: AppColors.primary,
              fontWeight: FontWeight.bold,
            ),
            lessStyle: const TextStyle(
              color: AppColors.primary,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}