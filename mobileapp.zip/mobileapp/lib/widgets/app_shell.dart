import 'package:flutter/material.dart';

import '../core/utils/device_utils.dart';
import '../enum/MenuItemType.dart';
import '../features/home/widgets/background_decoration.dart';
import 'hover_side_menu.dart';
import 'ott_footer.dart';

/// Shared post-login chrome: on desktop widths this adds the persistent
/// [HoverSideMenu], the ott_home_page background theme, and the [OTTFooter]
/// around any page's content. On mobile/tablet widths it is a no-op passthrough
/// so each page's own mobile layout (app bar, drawer, bottom nav) is unaffected.
class AppShell extends StatelessWidget {
  final Widget child;
  final MenuItemType activeMenu;

  const AppShell({
    super.key,
    required this.child,
    required this.activeMenu,
  });

  @override
  Widget build(BuildContext context) {
    if (!DeviceUtils.isDesktop(context)) {
      return child;
    }

    return Scaffold(
      backgroundColor: const Color(0xff020B23),
      body: Stack(
        children: [
          const BackgroundDecoration(),
          Row(
            children: [
              HoverSideMenu(
                selected: activeMenu,
                onMenuSelected: (_) {},
              ),
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      SizedBox(
                        height: MediaQuery.of(context).size.height,
                        child: child,
                      ),
                      const OTTFooter(),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
