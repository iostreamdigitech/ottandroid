import 'dart:ui';

import 'package:flutter/material.dart';

import '../features/home/models/movie.dart';



class MovieDesktopHeader extends StatelessWidget {
  final Movie movie;
  final VoidCallback onPlay;
  const MovieDesktopHeader({
    super.key,
    required this.movie,
    required this.onPlay,
  });

  static const double _headerHeight = 520;
  static const double _posterWidth = 240;
  static const double _posterHeight = 360;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: _headerHeight + 110,
      child: Stack(
        clipBehavior: Clip.none,
        children: [

          /// BACKDROP
          SizedBox(
            height: _headerHeight,
            width: double.infinity,
            child: Stack(
              fit: StackFit.expand,
              children: [

                Image.network(
                  movie.bannerUrl ?? movie.posterUrl ?? "",
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(
                    color: const Color(0xff1B1F30),
                  ),
                ),

                /// Blur
                BackdropFilter(
                  filter: ImageFilter.blur(
                    sigmaX: 1.5,
                    sigmaY: 1.5,
                  ),
                  child: Container(
                    color: Colors.black.withOpacity(.15),
                  ),
                ),

                /// Left Gradient
                Container(
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                      colors: [
                        Color(0xF0050A18),
                        Color(0xCC050A18),
                        Color(0x66050A18),
                        Colors.transparent,
                      ],
                    ),
                  ),
                ),

                /// Bottom Gradient
                Align(
                  alignment: Alignment.bottomCenter,
                  child: Container(
                    height: 220,
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Colors.transparent,
                          Color(0xff050A18),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),

          /// TOP ACTION BAR
          Positioned(
            top: 24,
            left: 24,
            right: 24,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [

                _circleButton(
                  icon: Icons.arrow_back_ios_new,
                  onTap: () => Navigator.pop(context),
                ),

                Row(
                  children: [

                    _circleButton(
                      icon: Icons.cast,
                      onTap: () {},
                    ),

                    const SizedBox(width: 14),

                    _circleButton(
                      icon: Icons.favorite_border,
                      onTap: () {},
                    ),

                    const SizedBox(width: 14),

                    _circleButton(
                      icon: Icons.share_outlined,
                      onTap: () {},
                    ),
                  ],
                ),
              ],
            ),
          ),

          /// Poster & content (Part 2)
          Positioned(
            left: 60,
            bottom: 0,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [

                Hero(
                  tag: movie.id,
                  child: Container(
                    width: _posterWidth,
                    height: _posterHeight,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: const [
                        BoxShadow(
                          color: Colors.black54,
                          blurRadius: 25,
                          offset: Offset(0, 12),
                        ),
                      ],
                      image: DecorationImage(
                        image: NetworkImage(
                          movie.posterUrl ?? "",
                        ),
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                ),

                const SizedBox(width: 40),

                /// Part 2 goes here
            SizedBox(
              width: 760,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.end,
                children: [

                  /// Title
                  Text(
                    movie.title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 44,
                      fontWeight: FontWeight.bold,
                      height: 1.15,
                    ),
                  ),

                  const SizedBox(height: 18),

                  /// Rating
                  Wrap(
                    spacing: 12,
                    runSpacing: 12,
                    crossAxisAlignment: WrapCrossAlignment.center,
                    children: [

                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 14,
                          vertical: 8,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.amber.withOpacity(.15),
                          borderRadius: BorderRadius.circular(30),
                          border: Border.all(
                            color: Colors.amber,
                          ),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [

                            const Icon(
                              Icons.star,
                              color: Colors.amber,
                              size: 18,
                            ),

                            const SizedBox(width: 6),

                            Text(
                              "${movie.rating ?? "8.5"}/10",
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),

                      _chip(Icons.calendar_today, movie.year ?? "2025"),

                      _chip(Icons.schedule, movie.duration ?? "2h 30m"),

                      _chip(Icons.movie_filter, movie.genre ?? "Action"),
                    ],
                  ),

                  const SizedBox(height: 22),

                  /// Overview
                  SizedBox(
                    width: 700,
                    child: Text(
                      movie.description ??
                          "No description available.",
                      maxLines: 4,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: Colors.grey.shade300,
                        fontSize: 17,
                        height: 1.7,
                      ),
                    ),
                  ),

                  const SizedBox(height: 32),

                  /// Buttons
                  Row(
                    children: [

                      ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.redAccent,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(
                            horizontal: 34,
                            vertical: 18,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                          ),
                        ),
                        onPressed: onPlay,
                        icon: const Icon(Icons.play_arrow_rounded),
                        label: const Text(
                          "Play Now",
                          style: TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),

                      const SizedBox(width: 18),

                      OutlinedButton.icon(
                        style: OutlinedButton.styleFrom(
                          foregroundColor: Colors.white,
                          side: const BorderSide(
                            color: Colors.white24,
                          ),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 30,
                            vertical: 18,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                          ),
                        ),
                        onPressed: () {},
                        icon: const Icon(Icons.ondemand_video),
                        label: const Text(
                          "Trailer",
                          style: TextStyle(fontSize: 16),
                        ),
                      ),

                      const SizedBox(width: 18),

                      OutlinedButton.icon(
                        style: OutlinedButton.styleFrom(
                          foregroundColor: Colors.white,
                          side: const BorderSide(
                            color: Colors.white24,
                          ),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 30,
                            vertical: 18,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                          ),
                        ),
                        onPressed: () {},
                        icon: const Icon(Icons.add),
                        label: const Text(
                          "My List",
                          style: TextStyle(fontSize: 16),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _chip(
      IconData icon,
      String text,
      ) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 14,
        vertical: 8,
      ),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.08),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(
          color: Colors.white24,
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [

          Icon(
            icon,
            size: 16,
            color: Colors.white70,
          ),

          const SizedBox(width: 8),

          Text(
            text,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 14,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
  Widget _circleButton({
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(30),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(30),
        child: BackdropFilter(
          filter: ImageFilter.blur(
            sigmaX: 12,
            sigmaY: 12,
          ),
          child: Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(.35),
              borderRadius: BorderRadius.circular(30),
              border: Border.all(
                color: Colors.white24,
              ),
            ),
            child: Icon(
              icon,
              color: Colors.white,
              size: 22,
            ),
          ),
        ),
      ),
    );
  }
}