import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import '../auth/utils/auth_utils.dart';
import '../core/utils/app_navigator.dart';
import '../features/livetv/live_tv_page.dart';
import '../screens/downloads_page.dart';

import '../screens/placeholders/about_page.dart';
import '../screens/placeholders/movies_page.dart';
import '../screens/placeholders/my_list_page.dart';
import '../screens/placeholders/tv_shows_page.dart';
import '../screens/settings_page.dart';

class AppDrawer extends StatelessWidget {
  const AppDrawer({super.key});
  static const FlutterSecureStorage _storage =
  FlutterSecureStorage();


  Future<Map<String, dynamic>?> loadUser() async {
    final token = await _storage.read(key: "ott_token");


    if (token == null || token.isEmpty) {
      return null;
    }


    final payload = AuthUtils.getPayload(token);

    debugPrint("JWT Payload: $payload");
    return payload;
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<Map<String, dynamic>?>(
      future: loadUser(),
      builder: (context, snapshot) {
        final user = snapshot.data;
        debugPrint("${snapshot.data}");

        final String name =
            user?["full name"] ??
                user?["preferred_username"] ??
                "Guest User";

        final String email =
            user?["email"] ??
                user?["mobile"] ??
                "Sign in to continue";

        return Drawer(
          width: 310,
          elevation: 0,
          backgroundColor: Colors.transparent,
          child: ClipRRect(
            child: BackdropFilter(
              filter: ImageFilter.blur(
                sigmaX: 20,
                sigmaY: 20,
              ),
              child: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Color(0xff020B23),
                      Color(0xff081326),
                      Color(0xff111C44),
                    ],
                  ),
                ),
                child: SafeArea(
                  child: Column(
                    children: [

                      const SizedBox(height: 15),

                      /// Logo
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 22),
                        child: Row(
                          children: [

                            Container(
                              width: 52,
                              height: 52,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(15),
                                gradient: const LinearGradient(
                                  colors: [
                                    Color(0xff6D4CFF),
                                    Color(0xffFF2E63),
                                  ],
                                ),
                              ),
                              child: const Icon(
                                Icons.movie_creation_rounded,
                                color: Colors.white,
                              ),
                            ),

                            const SizedBox(width: 14),

                            const Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [

                                Text(
                                  "OTTONE",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 24,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),

                                SizedBox(height: 3),

                                Text(
                                  "Unlimited Entertainment",
                                  style: TextStyle(
                                    color: Colors.white60,
                                    fontSize: 12,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 28),

                      /// USER CARD
                      Container(
                        margin: const EdgeInsets.symmetric(horizontal: 18),
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(.05),
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(
                            color: Colors.white10,
                          ),
                        ),
                        child: Row(
                          children: [

                            const CircleAvatar(
                              radius: 24,
                              backgroundColor: Color(0xff202B52),
                              child: Icon(
                                Icons.person,
                                color: Colors.white70,
                              ),
                            ),

                            const SizedBox(width: 14),

                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [

                                  Text(
                                    name,
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16,
                                    ),
                                  ),

                                  const SizedBox(height: 4),

                                  Text(
                                    email,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                      color: Colors.white60,
                                      fontSize: 12,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 25),

                      Expanded(
                        child: ListView(
                          padding: EdgeInsets.zero,
                          children: [

                            _menu(
                              context,
                              Icons.home_rounded,
                              "Home",
                                  () => Navigator.pop(context),
                              true,
                            ),

                            _menu(
                              context,
                              Icons.movie_creation_outlined,
                              "Movies",
                                  () => _open(context, const MoviesPage()),
                            ),

                            _menu(
                              context,
                              Icons.tv_rounded,
                              "TV Shows",
                                  () => _open(context, const TvShowsPage()),
                            ),

                            _menu(
                              context,
                              Icons.live_tv_rounded,
                              "Live TV",
                                  () => _open(context, const LiveTvPage()),
                            ),

                            _menu(
                              context,
                              Icons.favorite_outline,
                              "My List",
                                  () => _open(context, const MyListPage()),
                            ),

                            _menu(
                              context,
                              Icons.download_rounded,
                              "Downloads",
                                  () => _open(context, const DownloadsPage()),
                            ),

                            _menu(
                              context,
                              Icons.settings_outlined,
                              "Settings",
                                  () => _open(context, const SettingsPage()),
                            ),

                            _menu(
                              context,
                              Icons.info_outline,
                              "About",
                                  () => _open(context, const AboutPage()),
                            ),
                          ],
                        ),
                      ),

                      const Divider(
                        color: Colors.white12,
                        indent: 20,
                        endIndent: 20,
                      ),

                      const Padding(
                        padding: EdgeInsets.only(
                          bottom: 18,
                          top: 10,
                        ),
                        child: Text(
                          "Version 1.0.0",
                          style: TextStyle(
                            color: Colors.white38,
                            fontSize: 12,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _menu(
      BuildContext context,
      IconData icon,
      String title,
      VoidCallback onTap, [
        bool selected = false,
      ]) {
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: 14,
        vertical: 4,
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: onTap,
          child: Ink(
            padding: const EdgeInsets.symmetric(
              horizontal: 16,
              vertical: 14,
            ),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              gradient: selected
                  ? const LinearGradient(
                colors: [
                  Color(0xff6D4CFF),
                  Color(0xffFF2E63),
                ],
              )
                  : null,
            ),
            child: Row(
              children: [

                Icon(
                  icon,
                  color: Colors.white,
                ),

                const SizedBox(width: 18),

                Expanded(
                  child: Text(
                    title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),

                if (selected)
                  const Icon(
                    Icons.chevron_right,
                    color: Colors.white,
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _open(BuildContext context, Widget page) {
    Navigator.pop(context);
    AppNavigator.push(context, page);
  }
}