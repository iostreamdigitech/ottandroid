import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:ottoneapp/enum/MenuItemType.dart';

import 'package:ottoneapp/screens/placeholders/movies_page.dart';
import 'package:ottoneapp/screens/placeholders/my_list_page.dart';

import 'package:ottoneapp/screens/settings_page.dart';

import '../features/home/page/base_screen.dart';
import '../features/livetv/live_tv_page.dart';
import '../features/profile/page/profile_page.dart';
import '../features/search/search_page.dart';

class HoverSideMenu extends StatefulWidget {
  final Function(MenuItemType) onMenuSelected;
  final MenuItemType selected;

  const HoverSideMenu({
    super.key,
    required this.onMenuSelected,
    this.selected = MenuItemType.home,
  });

  @override
  State<HoverSideMenu> createState() => _HoverSideMenuState();
}

class _HoverSideMenuState extends State<HoverSideMenu> {
  bool expanded = false;
  late MenuItemType selectedMenu = widget.selected;

  @override
  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      onEnter: (_) => setState(() => expanded = true),
      onExit: (_) => setState(() => expanded = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        curve: Curves.easeInOut,
        width: expanded ? 260 : 72,
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xFF101820),
              Color(0xFF0D1117),
              Color(0xFF050608),
            ],
          ),
          border: Border(
            right: BorderSide(
              color: Colors.white.withOpacity(.08),
            ),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(.45),
              blurRadius: 20,
              offset: const Offset(4, 0),
            ),
          ],
        ),
        child: SafeArea(
          child: Column(
            children: [
              const SizedBox(height: 20),

              /// Logo
              AnimatedContainer(
                duration: const Duration(milliseconds: 250),
                height: 70,
                width: double.infinity,
                alignment:
                expanded ? Alignment.centerLeft : Alignment.center,
                padding: EdgeInsets.only(left: expanded ? 20 : 0),
                child: Image.asset(
                  expanded
                      ? "assets/logoweb.png"
                      : "assets/ottone_logo.png",
                  height: expanded ? 42 : 34,
                  fit: BoxFit.contain,
                ),
              ),

              const SizedBox(height: 20),

              /// Main Menu
              Expanded(
                child: ListView(
                  padding: EdgeInsets.zero,
                  children: [
                    menu(Icons.home_rounded, "Home", MenuItemType.home),
                    menu(Icons.search_rounded, "Search", MenuItemType.search),
                    menu(Icons.live_tv_rounded, "Live TV", MenuItemType.liveTv),
                    menu(Icons.movie_creation_outlined, "Movies",
                        MenuItemType.movies),
                    menu(Icons.sports_cricket_rounded, "Sports",
                        MenuItemType.sports),
                    menu(Icons.favorite_outline_rounded, "My List",
                        MenuItemType.myList),
                  ],
                ),
              ),

              const Divider(
                color: Colors.white12,
                indent: 14,
                endIndent: 14,
              ),

              menu(
                Icons.person_outline_rounded,
                "My Ottone",
                MenuItemType.profile,
              ),

              menu(
                Icons.settings_outlined,
                "Settings",
                MenuItemType.settings,
              ),

              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }

  Widget menu(
      IconData icon,
      String title,
      MenuItemType type,
      ) {
    final selected = selectedMenu == type;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () {
          setState(() => selectedMenu = type);

          switch (type) {
            case MenuItemType.home:
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (_) => const BaseScreen()),
                    (_) => false,
              );
              break;

            case MenuItemType.search:
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (_) => const SearchPage()),
                    (_) => false,
              );
              break;

            case MenuItemType.liveTv:
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (_) => const LiveTvPage()),
                    (_) => false,
              );
              break;

            case MenuItemType.movies:
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (_) => const MoviesPage()),
                    (_) => false,
              );
              break;

            case MenuItemType.myList:
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (_) => const MyListPage()),
                    (_) => false,
              );
              break;

            case MenuItemType.profile:
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (_) => const ProfilePage()),
                    (_) => false,
              );
              break;

            case MenuItemType.settings:
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (_) => const SettingsPage()),
                    (_) => false,
              );
              break;

            case MenuItemType.sports:
              widget.onMenuSelected(type);
              break;
            case MenuItemType.subscription:
              // TODO: Handle this case.
              throw UnimplementedError();
          }

          widget.onMenuSelected(type);
        },
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          height: 54,
          padding: EdgeInsets.symmetric(
            horizontal: expanded ? 18 : 0,
          ),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            gradient: selected
                ? const LinearGradient(
              colors: [
                Color(0xFFFF3D00),
                Color(0xFFFF6D00),
              ],
            )
                : null,
          ),
          child: expanded
              ? Row(
            children: [
              Icon(
                icon,
                color: selected ? Colors.white : Colors.white70,
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Text(
                  title,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color:
                    selected ? Colors.white : Colors.white70,
                    fontWeight: selected
                        ? FontWeight.bold
                        : FontWeight.w500,
                  ),
                ),
              ),
            ],
          )
              : Center(
            child: Icon(
              icon,
              color: selected ? Colors.white : Colors.white70,
            ),
          ),
        ),
      ),
    );
  }
}