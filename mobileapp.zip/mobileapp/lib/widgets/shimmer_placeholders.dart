import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';

class ShimmerBox extends StatelessWidget {
  final double width;
  final double height;
  final BorderRadius borderRadius;

  const ShimmerBox({
    super.key,
    required this.width,
    required this.height,
    this.borderRadius = const BorderRadius.all(Radius.circular(12)),
  });

  @override
  Widget build(BuildContext context) {
    return Shimmer.fromColors(
      baseColor: const Color(0xff141E38),
      highlightColor: const Color(0xff223054),
      child: Container(
        width: width,
        height: height,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: borderRadius,
        ),
      ),
    );
  }
}

class ShimmerBannerCarousel extends StatelessWidget {
  const ShimmerBannerCarousel({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(12),
      child: ShimmerBox(
        width: double.infinity,
        height: 240,
        borderRadius: BorderRadius.circular(20),
      ),
    );
  }
}

class ShimmerMovieRow extends StatelessWidget {
  final int itemCount;

  const ShimmerMovieRow({super.key, this.itemCount = 4});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 220,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: itemCount,
        itemBuilder: (context, index) {
          return const Padding(
            padding: EdgeInsets.symmetric(horizontal: 8),
            child: ShimmerBox(width: 160, height: 220),
          );
        },
      ),
    );
  }
}

class ShimmerGenreRow extends StatelessWidget {
  final int itemCount;

  const ShimmerGenreRow({super.key, this.itemCount = 6});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 70,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: itemCount,
        itemBuilder: (context, index) {
          return const Padding(
            padding: EdgeInsets.symmetric(horizontal: 8),
            child: ShimmerBox(width: 110, height: 45, borderRadius: BorderRadius.all(Radius.circular(14))),
          );
        },
      ),
    );
  }
}
