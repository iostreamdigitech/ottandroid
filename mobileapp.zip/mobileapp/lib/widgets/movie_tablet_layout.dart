import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:ottoneapp/widgets/similar_movies.dart';

import '../core/constants/app_colors.dart';
import '../features/home/models/movie.dart';
import '../models/CastMember.dart';

import 'cast_section.dart';
import 'movieInfo.dart';
import 'movie_header.dart';
import 'overview.dart';
class MovieTabletLayout extends StatelessWidget {
  final Movie movie;

  /// Routed through the play gate by [MovieDetailPage].
  final VoidCallback onPlay;

  const MovieTabletLayout({
    required this.movie,
    required this.onPlay,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(),
        slivers: [
          /// Banner
          MovieHeader(movie: movie),

          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 20,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  /// Movie Information
                  MovieInfo(movie, onPlay: onPlay),

                  const SizedBox(height: 20),

                  /// Action Buttons
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: onPlay,
                          icon: const Icon(Icons.play_arrow),
                          label: const Text("Watch Now"),
                          style: ElevatedButton.styleFrom(
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            backgroundColor: Colors.red,
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      IconButton.filled(
                        onPressed: () {},
                        icon: const Icon(Icons.add),
                      ),
                      const SizedBox(width: 8),
                      IconButton.filled(
                        onPressed: () {},
                        icon: const Icon(Icons.share),
                      ),
                    ],
                  ),

                  const SizedBox(height: 30),

                  /// Overview
                  Overview(movie),

                  const SizedBox(height: 30),

                  /// Cast
                  CastSection(
                    cast: [
                      CastMember(
                        name: "Naslen",
                        role: "Lead Role",
                        image: "assets/cast/naslen.jpg",
                      ),
                      CastMember(
                        name: "Mamitha Baiju",
                        role: "Lead Role",
                        image: "assets/cast/mamitha.jpg",
                      ),
                      CastMember(
                        name: "Sangeeth Prathap",
                        role: "Supporting",
                        image: "assets/cast/sangeeth.jpg",
                      ),
                      CastMember(
                        name: "Akshara Kishor",
                        role: "Supporting",
                        image: "assets/cast/akshara.jpg",
                      ),
                      CastMember(
                        name: "Shyam Mohan",
                        role: "Supporting",
                        image: "assets/cast/shyam.jpg",
                      ),
                    ],
                  ),

                  const SizedBox(height: 30),

                  /// Similar Movies
                  const SimilarMovies(),

                  const SizedBox(height: 40),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}