import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class SimilarMovies extends StatelessWidget {
  const SimilarMovies({super.key});

  @override
  Widget build(BuildContext context) {
    final movies = [
      {
        "title": "Hridayam",
        "image":
        "https://images.justwatch.com/poster/255892066/s718/hridayam.jpg",
      },
      {
        "title": "Bangalore Days",
        "image":
        "https://images.justwatch.com/poster/310857289/s718/bangalore-days.jpg",
      },
      {
        "title": "Thiruchitrambalam",
        "image":
        "https://images.justwatch.com/poster/302179768/s718/thiruchitrambalam.jpg",
      },
      {
        "title": "100 Days of Love",
        "image":
        "https://images.justwatch.com/poster/177238456/s718/100-days-of-love.jpg",
      },
      {
        "title": "Premam",
        "image":
        "https://images.justwatch.com/poster/177983691/s718/premam.jpg",
      },
    ];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Expanded(
                child: Text(
                  "Similar Movies",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              TextButton(
                onPressed: () {},
                child: const Text(
                  "See All",
                  style: TextStyle(
                    color: Colors.deepPurpleAccent,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: 15),

          SizedBox(
            height: 210,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: movies.length,
              separatorBuilder: (_, __) => const SizedBox(width: 14),
              itemBuilder: (_, index) {
                final movie = movies[index];

                return GestureDetector(
                  onTap: () {},
                  child: Container(
                    width: 130,
                    decoration: BoxDecoration(
                      color: const Color(0xff111B38),
                      borderRadius: BorderRadius.circular(18),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: ClipRRect(
                            borderRadius: const BorderRadius.vertical(
                              top: Radius.circular(18),
                            ),
                            child: Image.network(
                              movie["image"]!,
                              width: double.infinity,
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(10),
                          child: Text(
                            movie["title"]!,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}