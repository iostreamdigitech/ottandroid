import 'package:flutter/material.dart';

import '../features/home/models/movie.dart';



class MovieQuickInfo extends StatelessWidget {
  final Movie movie;

  const MovieQuickInfo(
      this.movie, {
        super.key,
      });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.05),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(
          color: Colors.white10,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(.25),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [

          const Text(
            "Quick Info",
            style: TextStyle(
              color: Colors.white,
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 25),

          _quickTile(
            Icons.star_rounded,
            Colors.amber,
            "IMDb Rating",
            movie.rating?.toString() ?? "8.5",
          ),

          const SizedBox(height: 18),

          _quickTile(
            Icons.hd_rounded,
            Colors.blue,
            "Quality",
             "4K HDR",
          ),

          const SizedBox(height: 18),

          _quickTile(
            Icons.volume_up_rounded,
            Colors.green,
            "Audio",
             "Dolby Atmos",
          ),

          const SizedBox(height: 18),

          _quickTile(
            Icons.closed_caption,
            Colors.orange,
            "Subtitle",
             "English",
          ),

          const SizedBox(height: 18),

          _quickTile(
            Icons.public,
            Colors.cyan,
            "Country",
             "India",
          ),

          const SizedBox(height: 18),

          _quickTile(
            Icons.workspace_premium,
            Colors.purple,
            "Certificate",
             "U/A 13+",
          ),

          const SizedBox(height: 30),

          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: Colors.redAccent.withOpacity(.15),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(
                color: Colors.redAccent.withOpacity(.4),
              ),
            ),
            child: const Column(
              children: [

                Icon(
                  Icons.play_circle_fill,
                  color: Colors.redAccent,
                  size: 42,
                ),

                SizedBox(height: 10),

                Text(
                  "Available to Stream",
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),

                SizedBox(height: 5),

                Text(
                  "Watch now in Ultra HD",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white70,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _quickTile(
      IconData icon,
      Color color,
      String title,
      String value,
      ) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.03),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [

          CircleAvatar(
            radius: 22,
            backgroundColor: color.withOpacity(.15),
            child: Icon(
              icon,
              color: color,
              size: 22,
            ),
          ),

          const SizedBox(width: 14),

          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [

                Text(
                  title,
                  style: const TextStyle(
                    color: Colors.white60,
                    fontSize: 12,
                  ),
                ),

                const SizedBox(height: 3),

                Text(
                  value,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}