import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../core/utils/app_navigator.dart';
import '../enum/MenuItemType.dart';
import '../features/home/page/base_screen.dart';
import '../models/subscription_plan.dart';
import '../player/controllers/subscription_controller.dart';
import '../player/models/payment_state.dart';
import '../widgets/app_shell.dart';
import '../widgets/payment_status_overlay.dart';
import '../widgets/subscription_card.dart';

class SubscriptionPage extends StatelessWidget {
  SubscriptionPage({super.key});

  /// Reuse the live controller when there is one.
  ///
  /// `Get.put` would replace it, leaving the old instance - and its registered
  /// Razorpay listeners - dangling.
  final SubscriptionController controller =
  Get.isRegistered<SubscriptionController>()
      ? Get.find<SubscriptionController>()
      : Get.put(SubscriptionController());

  static const Color background = Color(0xff020B23);
  static const Color surface = Color(0xff101936);
  static const Color primary = Color(0xff7A3CFF);
  static const Color secondary = Color(0xffFF2D75);

  static const double tabletBreakpoint = 768;
  static const double desktopBreakpoint = 1200;

  @override
  Widget build(BuildContext context) {
    return AppShell(
      activeMenu: MenuItemType.subscription,
      child: Obx(
            () => PopScope(
          // Leaving while an order is being created, the gateway is opening,
          // or a payment is being verified would orphan the transaction.
          // Once there is a result, back behaves normally again.
          canPop: !controller.payments.paymentStatus.value.isInProgress,
          child: Stack(
            children: [
              _buildScaffold(),

              PaymentStatusOverlay(
                engine: controller.payments,
                onContinue: () => _handleContinue(context),
                onRetry: controller.payments.reset,
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Success screen, "Continue Watching".
  ///
  /// The payment result is cleared first so coming back to the plans later
  /// starts from a clean slate rather than the finished attempt.
  void _handleContinue(BuildContext context) {
    controller.payments.reset();

    AppNavigator.pushAndRemoveAll(
      context,
      const BaseScreen(),
    );
  }

  Widget _buildScaffold() {
    return Scaffold(
        backgroundColor: background,
        appBar: _buildAppBar(),
        body: SafeArea(
          child: Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color(0xff020B23),
                  Color(0xff091126),
                  Colors.black,
                ],
              ),
            ),
            child: LayoutBuilder(
              builder: (context, constraints) {
                return _buildResponsiveBody(
                  context,
                  constraints,
                );
              },
            ),
          ),
        ),
    );
  }

  // ---------------------------------------------------------------------------
  // APP BAR
  // ---------------------------------------------------------------------------

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      elevation: 0,
      backgroundColor: background,
      centerTitle: true,
      title: const Text(
        'Subscription Plans',
        style: TextStyle(
          fontWeight: FontWeight.bold,
          fontSize: 20,
          color: Colors.white,
        ),
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // RESPONSIVE BODY
  // ---------------------------------------------------------------------------

  Widget _buildResponsiveBody(
      BuildContext context,
      BoxConstraints constraints,
      ) {
    final width = constraints.maxWidth;

    final bool isMobile = width < tabletBreakpoint;
    final bool isTablet =
        width >= tabletBreakpoint && width < desktopBreakpoint;
    final bool isDesktop = width >= desktopBreakpoint;

    double maxWidth;

    if (isMobile) {
      maxWidth = width;
    } else if (isTablet) {
      maxWidth = 1100;
    } else {
      maxWidth = 1400;
    }

    return Center(
      child: ConstrainedBox(
        constraints: BoxConstraints(
          maxWidth: maxWidth,
        ),
        child: Column(
          children: [
            const SizedBox(height: 20),

            // Header
            _buildHeader(
              isMobile: isMobile,
              isTablet: isTablet,
              isDesktop: isDesktop,
            ),

            const SizedBox(height: 20),

            // Monthly / Yearly
            _buildSegment(
              isMobile: isMobile,
            ),

            const SizedBox(height: 24),

            // Plans
            Expanded(
              child: Obx(
                    () {
                  if (controller.isLoading.value) {
                    return _buildLoading();
                  }

                  if (controller.errorMessage.value.isNotEmpty) {
                    return _buildError();
                  }

                  if (controller.currentPlans.isEmpty) {
                    return _buildEmpty();
                  }

                  return RefreshIndicator(
                    onRefresh: controller.loadPlans,
                    child: _buildPlans(
                      context,
                      constraints.maxWidth,
                      isMobile,
                      isTablet,
                      isDesktop,
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // HEADER
  // ---------------------------------------------------------------------------

  Widget _buildHeader({
    required bool isMobile,
    required bool isTablet,
    required bool isDesktop,
  }) {
    return Padding(
      padding: EdgeInsets.symmetric(
        horizontal: isMobile ? 20 : 30,
      ),
      child: Column(
        children: [
          Text(
            'Choose the perfect plan',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white,
              fontSize: isMobile
                  ? 24
                  : isTablet
                  ? 30
                  : 34,
              fontWeight: FontWeight.w800,
              letterSpacing: -0.5,
            ),
          ),

          const SizedBox(height: 8),

          const Text(
            'Enjoy premium entertainment without limits',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white60,
              fontSize: 14,
            ),
          ),

          if (isDesktop) ...[
            const SizedBox(height: 6),
            const Text(
              'Choose a plan that fits your entertainment needs',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.white38,
                fontSize: 12,
              ),
            ),
          ],
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // MONTHLY / YEARLY SEGMENT
  // ---------------------------------------------------------------------------

  Widget _buildSegment({
    required bool isMobile,
  }) {
    return Obx(
          () => Container(
        margin: EdgeInsets.symmetric(
          horizontal: isMobile ? 20 : 30,
        ),
        height: 52,
        constraints: const BoxConstraints(
          maxWidth: 420,
        ),
        decoration: BoxDecoration(
          color: surface,
          borderRadius: BorderRadius.circular(30),
          border: Border.all(
            color: Colors.white.withOpacity(.08),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(.15),
              blurRadius: 20,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        padding: const EdgeInsets.all(4),
        child: Row(
          children: [
            Expanded(
              child: _segmentItem(
                title: 'Monthly',
                selected: controller.selectedTab.value == 0,
                onTap: () {
                  controller.changeTab(0);
                },
              ),
            ),
            Expanded(
              child: _segmentItem(
                title: 'Yearly',
                selected: controller.selectedTab.value == 1,
                onTap: () {
                  controller.changeTab(1);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _segmentItem({
    required String title,
    required bool selected,
    required VoidCallback onTap,
  }) {
    return InkWell(
      borderRadius: BorderRadius.circular(28),
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        curve: Curves.easeInOut,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(28),
          gradient: selected
              ? const LinearGradient(
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
            colors: [
              primary,
              secondary,
            ],
          )
              : null,
        ),
        child: Center(
          child: AnimatedDefaultTextStyle(
            duration: const Duration(milliseconds: 200),
            style: TextStyle(
              color: Colors.white,
              fontWeight:
              selected ? FontWeight.bold : FontWeight.w500,
              fontSize: 14,
            ),
            child: Text(title),
          ),
        ),
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // PLANS
  // ---------------------------------------------------------------------------

  Widget _buildPlans(
      BuildContext context,
      double width,
      bool isMobile,
      bool isTablet,
      bool isDesktop,
      ) {
    final plans = controller.currentPlans;

    if (isMobile) {
      return ListView.separated(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(
          16,
          0,
          16,
          40,
        ),
        itemCount: plans.length,
        separatorBuilder: (_, __) {
          return const SizedBox(height: 18);
        },
        itemBuilder: (context, index) {
          return _buildCard(
            context,
            plans[index],
          );
        },
      );
    }

    final int columns = isTablet ? 2 : 3;

    return GridView.builder(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(
        24,
        0,
        24,
        40,
      ),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: columns,
        crossAxisSpacing: 20,
        mainAxisSpacing: 20,
        childAspectRatio: isTablet ? .78 : .72,
      ),
      itemCount: plans.length,
      itemBuilder: (context, index) {
        return _buildCard(
          context,
          plans[index],
        );
      },
    );
  }

  // ---------------------------------------------------------------------------
  // SUBSCRIPTION CARD
  // ---------------------------------------------------------------------------

  Widget _buildCard(
      BuildContext context,
      SubscriptionPlan plan,
      ) {
    return SubscriptionCard(
      plan: plan,
    );
  }

  // ---------------------------------------------------------------------------
  // LOADING
  // ---------------------------------------------------------------------------

  Widget _buildLoading() {
    return const Center(
      child: CircularProgressIndicator(
        color: primary,
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // EMPTY
  // ---------------------------------------------------------------------------

  Widget _buildEmpty() {
    return ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      children: const [
        SizedBox(
          height: 180,
        ),
        Center(
          child: Column(
            children: [
              Icon(
                Icons.card_membership_outlined,
                color: Colors.white38,
                size: 60,
              ),
              SizedBox(height: 16),
              Text(
                'No Plans Available',
                style: TextStyle(
                  color: Colors.white70,
                  fontSize: 17,
                  fontWeight: FontWeight.w600,
                ),
              ),
              SizedBox(height: 6),
              Text(
                'Please check again later.',
                style: TextStyle(
                  color: Colors.white38,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ---------------------------------------------------------------------------
  // ERROR
  // ---------------------------------------------------------------------------

  Widget _buildError() {
    return ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      children: [
        const SizedBox(
          height: 140,
        ),
        Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                const Icon(
                  Icons.error_outline,
                  color: Colors.redAccent,
                  size: 50,
                ),

                const SizedBox(height: 16),

                Obx(
                      () => Text(
                    controller.errorMessage.value,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: Colors.white70,
                      fontSize: 14,
                    ),
                  ),
                ),

                const SizedBox(height: 20),

                ElevatedButton(
                  onPressed: controller.loadPlans,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: primary,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 28,
                      vertical: 12,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(24),
                    ),
                  ),
                  child: const Text(
                    'Retry',
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}