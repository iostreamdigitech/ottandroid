import 'package:flutter/material.dart';

import '../../widgets/coming_soon_scaffold.dart';

class TvShowsPage extends StatelessWidget {
  const TvShowsPage({super.key});

  @override
  Widget build(BuildContext context) {
    // TODO: Replace with API call - fetch TV shows catalog
    return const ComingSoonScaffold(title: "TV Shows");
  }
}
