import 'package:flutter/material.dart';

import '../../enum/MenuItemType.dart';
import '../../widgets/app_shell.dart';
import '../../widgets/coming_soon_scaffold.dart';

class MyListPage extends StatelessWidget {
  const MyListPage({super.key});

  @override
  Widget build(BuildContext context) {
    // TODO: Replace with API call - fetch user's saved watchlist
    return const AppShell(
      activeMenu: MenuItemType.myList,
      child: ComingSoonScaffold(title: "My List"),
    );
  }
}
