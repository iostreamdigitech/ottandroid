import 'package:flutter/material.dart';

import '../../enum/MenuItemType.dart';
import '../../widgets/app_shell.dart';
import '../../widgets/coming_soon_scaffold.dart';

class MoviesPage extends StatelessWidget {
  const MoviesPage({super.key});

  @override
  Widget build(BuildContext context) {
    // TODO: Replace with API call - fetch full movies catalog
    return const AppShell(
      activeMenu: MenuItemType.movies,
      child: ComingSoonScaffold(title: "Movies"),
    );
  }
}
