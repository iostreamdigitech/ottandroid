import 'package:flutter/material.dart';

import '../../widgets/coming_soon_scaffold.dart';

class AboutPage extends StatelessWidget {
  const AboutPage({super.key});

  @override
  Widget build(BuildContext context) {
    // TODO: Replace with API call - fetch app/about content
    return const ComingSoonScaffold(title: "About");
  }
}
