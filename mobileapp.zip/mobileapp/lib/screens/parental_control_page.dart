import 'package:flutter/material.dart';

class ParentalControlPage extends StatefulWidget {
  const ParentalControlPage({super.key});

  @override
  State<ParentalControlPage> createState() =>
      _ParentalControlPageState();
}

class _ParentalControlPageState
    extends State<ParentalControlPage> {

  bool kidsMode = false;
  bool requirePin = true;
  String ageRating = "13+";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xff020B23),

      appBar: AppBar(
        title: const Text("Parental Controls"),
        backgroundColor: const Color(0xff020B23),
      ),

      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [

          Container(
            padding: const EdgeInsets.all(15),
            decoration: BoxDecoration(
              color: const Color(0xff141E38),
              borderRadius: BorderRadius.circular(15),
            ),
            child: Column(
              children: [

                SwitchListTile(
                  title: const Text(
                    "Kids Mode",
                    style:
                    TextStyle(color: Colors.white),
                  ),
                  value: kidsMode,
                  onChanged: (value) {
                    setState(() {
                      kidsMode = value;
                    });
                  },
                ),

                SwitchListTile(
                  title: const Text(
                    "Require PIN For Adult Content",
                    style:
                    TextStyle(color: Colors.white),
                  ),
                  value: requirePin,
                  onChanged: (value) {
                    setState(() {
                      requirePin = value;
                    });
                  },
                ),
              ],
            ),
          ),

          const SizedBox(height: 20),

          Card(
            color: const Color(0xff141E38),
            child: ListTile(
              title: const Text(
                "Content Rating",
                style: TextStyle(color: Colors.white),
              ),
              trailing: DropdownButton<String>(
                value: ageRating,
                dropdownColor: const Color(0xff141E38),
                items: const [
                  DropdownMenuItem(
                    value: "7+",
                    child: Text("7+"),
                  ),
                  DropdownMenuItem(
                    value: "13+",
                    child: Text("13+"),
                  ),
                  DropdownMenuItem(
                    value: "16+",
                    child: Text("16+"),
                  ),
                  DropdownMenuItem(
                    value: "18+",
                    child: Text("18+"),
                  ),
                ],
                onChanged: (value) {
                  setState(() {
                    ageRating = value!;
                  });
                },
              ),
            ),
          ),

          const SizedBox(height: 20),

          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              minimumSize:
              const Size(double.infinity, 55),
            ),
            icon: const Icon(Icons.lock),
            label: const Text("Change PIN"),
            onPressed: () {
              showDialog(
                context: context,
                builder: (context) {
                  return AlertDialog(
                    title: const Text("Change PIN"),
                    content: const TextField(
                      keyboardType:
                      TextInputType.number,
                      obscureText: true,
                      decoration: InputDecoration(
                        labelText: "New PIN",
                      ),
                    ),
                    actions: [
                      TextButton(
                        onPressed: () =>
                            Navigator.pop(context),
                        child: const Text("Cancel"),
                      ),
                      ElevatedButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        child: const Text("Save"),
                      ),
                    ],
                  );
                },
              );
            },
          ),
        ],
      ),
    );
  }
}