import 'package:flutter/material.dart';

import '../core/utils/device_utils.dart';
import '../widgets/app_drawer.dart';

class DownloadsPage extends StatefulWidget {
  const DownloadsPage({super.key});

  @override
  State<DownloadsPage> createState() => _DownloadsPageState();
}

class _DownloadsPageState extends State<DownloadsPage> {
  final List<Map<String, dynamic>> downloads = [
    {
      "title": "Aavesham",
      "type": "Movie",
      "size": "1.8 GB",
      "progress": 1.0,
      "image": "https://picsum.photos/300/450?1",
      "status": "Completed"
    },
    {
      "title": "Kannur Squad",
      "type": "Movie",
      "size": "1.5 GB",
      "progress": 0.65,
      "image": "https://picsum.photos/300/450?2",
      "status": "Downloading"
    },
    {
      "title": "The Boys S04E01",
      "type": "Episode",
      "size": "750 MB",
      "progress": 0.30,
      "image": "https://picsum.photos/300/450?3",
      "status": "Paused"
    }
  ];

  String selectedQuality = "High";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xff020B23),

      drawer: DeviceUtils.isDesktop(context) ? const AppDrawer() : null,

      appBar: AppBar(
        backgroundColor: const Color(0xff020B23),
        elevation: 0,
        title: const Text(
          "Downloads",
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () {},
          )
        ],
      ),

      body: Column(
        children: [

          /// STORAGE CARD
          Container(
            margin: const EdgeInsets.all(15),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xff141E38),
              borderRadius: BorderRadius.circular(15),
            ),
            child: Column(
              children: [
                const Row(
                  children: [
                    Icon(
                      Icons.sd_storage,
                      color: Colors.red,
                    ),
                    SizedBox(width: 10),
                    Text(
                      "Storage Usage",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 20),

                LinearProgressIndicator(
                  value: 0.65,
                  minHeight: 10,
                  borderRadius:
                  BorderRadius.circular(10),
                ),

                const SizedBox(height: 10),

                const Row(
                  mainAxisAlignment:
                  MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "13 GB Used",
                      style:
                      TextStyle(color: Colors.white),
                    ),
                    Text(
                      "20 GB Total",
                      style:
                      TextStyle(color: Colors.white),
                    ),
                  ],
                )
              ],
            ),
          ),

          /// QUALITY SETTINGS
          Padding(
            padding:
            const EdgeInsets.symmetric(horizontal: 15),
            child: Row(
              children: [
                const Text(
                  "Download Quality",
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Spacer(),

                DropdownButton<String>(
                  value: selectedQuality,
                  dropdownColor:
                  const Color(0xff141E38),
                  style:
                  const TextStyle(color: Colors.white),
                  items: const [
                    DropdownMenuItem(
                      value: "Low",
                      child: Text("Low"),
                    ),
                    DropdownMenuItem(
                      value: "Medium",
                      child: Text("Medium"),
                    ),
                    DropdownMenuItem(
                      value: "High",
                      child: Text("High"),
                    ),
                    DropdownMenuItem(
                      value: "Ultra HD",
                      child: Text("Ultra HD"),
                    ),
                  ],
                  onChanged: (value) {
                    setState(() {
                      selectedQuality = value!;
                    });
                  },
                ),
              ],
            ),
          ),

          const SizedBox(height: 10),

          Expanded(
            child: ListView.builder(
              itemCount: downloads.length,
              itemBuilder: (context, index) {
                final item = downloads[index];

                return Card(
                  color: const Color(0xff141E38),
                  margin: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 8,
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(10),
                    child: Row(
                      children: [

                        /// POSTER
                        ClipRRect(
                          borderRadius:
                          BorderRadius.circular(10),
                          child: Image.network(
                            item["image"],
                            width: 90,
                            height: 120,
                            fit: BoxFit.cover,
                          ),
                        ),

                        const SizedBox(width: 12),

                        Expanded(
                          child: Column(
                            crossAxisAlignment:
                            CrossAxisAlignment.start,
                            children: [

                              Text(
                                item["title"],
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight:
                                  FontWeight.bold,
                                  fontSize: 16,
                                ),
                              ),

                              const SizedBox(height: 5),

                              Text(
                                item["type"],
                                style: const TextStyle(
                                  color: Colors.grey,
                                ),
                              ),

                              const SizedBox(height: 5),

                              Text(
                                item["size"],
                                style: const TextStyle(
                                  color: Colors.grey,
                                ),
                              ),

                              const SizedBox(height: 10),

                              LinearProgressIndicator(
                                value: item["progress"],
                              ),

                              const SizedBox(height: 5),

                              Text(
                                item["status"],
                                style: TextStyle(
                                  color: item["status"] ==
                                      "Completed"
                                      ? Colors.green
                                      : Colors.orange,
                                ),
                              ),

                              const SizedBox(height: 8),

                              Row(
                                children: [

                                  IconButton(
                                    icon: const Icon(
                                      Icons.play_arrow,
                                      color: Colors.white,
                                    ),
                                    onPressed: () {},
                                  ),

                                  IconButton(
                                    icon: const Icon(
                                      Icons.pause,
                                      color: Colors.white,
                                    ),
                                    onPressed: () {},
                                  ),

                                  IconButton(
                                    icon: const Icon(
                                      Icons.delete,
                                      color: Colors.red,
                                    ),
                                    onPressed: () {
                                      setState(() {
                                        downloads.removeAt(
                                            index);
                                      });
                                    },
                                  ),
                                ],
                              )
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}