import 'package:flutter/material.dart';

import '../enum/MenuItemType.dart';
import '../widgets/app_shell.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  bool autoplay = true;
  bool notifications = true;
  bool wifiOnlyDownload = true;
  bool biometricLogin = false;
  bool subtitles = true;
  bool dataSaver = false;

  String videoQuality = 'Auto';
  String subtitleLanguage = 'English';

  @override
  Widget build(BuildContext context) {
    return AppShell(
      activeMenu: MenuItemType.settings,
      child: _SettingsContent(
        autoplay: autoplay,
        notifications: notifications,
        wifiOnlyDownload: wifiOnlyDownload,
        biometricLogin: biometricLogin,
        subtitles: subtitles,
        dataSaver: dataSaver,
        videoQuality: videoQuality,
        subtitleLanguage: subtitleLanguage,
        onAutoplayChanged: (value) {
          setState(() => autoplay = value);
        },
        onNotificationsChanged: (value) {
          setState(() => notifications = value);
        },
        onWifiOnlyChanged: (value) {
          setState(() => wifiOnlyDownload = value);
        },
        onBiometricChanged: (value) {
          setState(() => biometricLogin = value);
        },
        onSubtitlesChanged: (value) {
          setState(() => subtitles = value);
        },
        onDataSaverChanged: (value) {
          setState(() => dataSaver = value);
        },
        onVideoQualityChanged: (value) {
          setState(() => videoQuality = value);
        },
        onSubtitleLanguageChanged: (value) {
          setState(() => subtitleLanguage = value);
        },
      ),
    );
  }
}

// ===============================================================
// SETTINGS CONTENT
// ===============================================================

class _SettingsContent extends StatelessWidget {
  final bool autoplay;
  final bool notifications;
  final bool wifiOnlyDownload;
  final bool biometricLogin;
  final bool subtitles;
  final bool dataSaver;

  final String videoQuality;
  final String subtitleLanguage;

  final ValueChanged<bool> onAutoplayChanged;
  final ValueChanged<bool> onNotificationsChanged;
  final ValueChanged<bool> onWifiOnlyChanged;
  final ValueChanged<bool> onBiometricChanged;
  final ValueChanged<bool> onSubtitlesChanged;
  final ValueChanged<bool> onDataSaverChanged;

  final ValueChanged<String> onVideoQualityChanged;
  final ValueChanged<String> onSubtitleLanguageChanged;

  const _SettingsContent({
    required this.autoplay,
    required this.notifications,
    required this.wifiOnlyDownload,
    required this.biometricLogin,
    required this.subtitles,
    required this.dataSaver,
    required this.videoQuality,
    required this.subtitleLanguage,
    required this.onAutoplayChanged,
    required this.onNotificationsChanged,
    required this.onWifiOnlyChanged,
    required this.onBiometricChanged,
    required this.onSubtitlesChanged,
    required this.onDataSaverChanged,
    required this.onVideoQualityChanged,
    required this.onSubtitleLanguageChanged,
  });

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final width = constraints.maxWidth;

        if (width >= 1200) {
          return _DesktopSettings(
            autoplay: autoplay,
            notifications: notifications,
            wifiOnlyDownload: wifiOnlyDownload,
            biometricLogin: biometricLogin,
            subtitles: subtitles,
            dataSaver: dataSaver,
            videoQuality: videoQuality,
            subtitleLanguage: subtitleLanguage,
            onAutoplayChanged: onAutoplayChanged,
            onNotificationsChanged: onNotificationsChanged,
            onWifiOnlyChanged: onWifiOnlyChanged,
            onBiometricChanged: onBiometricChanged,
            onSubtitlesChanged: onSubtitlesChanged,
            onDataSaverChanged: onDataSaverChanged,
            onVideoQualityChanged: onVideoQualityChanged,
            onSubtitleLanguageChanged:
            onSubtitleLanguageChanged,
          );
        }

        if (width >= 700) {
          return _TabletSettings(
            autoplay: autoplay,
            notifications: notifications,
            wifiOnlyDownload: wifiOnlyDownload,
            biometricLogin: biometricLogin,
            subtitles: subtitles,
            dataSaver: dataSaver,
            videoQuality: videoQuality,
            subtitleLanguage: subtitleLanguage,
            onAutoplayChanged: onAutoplayChanged,
            onNotificationsChanged: onNotificationsChanged,
            onWifiOnlyChanged: onWifiOnlyChanged,
            onBiometricChanged: onBiometricChanged,
            onSubtitlesChanged: onSubtitlesChanged,
            onDataSaverChanged: onDataSaverChanged,
            onVideoQualityChanged: onVideoQualityChanged,
            onSubtitleLanguageChanged:
            onSubtitleLanguageChanged,
          );
        }

        return _MobileSettings(
          autoplay: autoplay,
          notifications: notifications,
          wifiOnlyDownload: wifiOnlyDownload,
          biometricLogin: biometricLogin,
          subtitles: subtitles,
          dataSaver: dataSaver,
          videoQuality: videoQuality,
          subtitleLanguage: subtitleLanguage,
          onAutoplayChanged: onAutoplayChanged,
          onNotificationsChanged: onNotificationsChanged,
          onWifiOnlyChanged: onWifiOnlyChanged,
          onBiometricChanged: onBiometricChanged,
          onSubtitlesChanged: onSubtitlesChanged,
          onDataSaverChanged: onDataSaverChanged,
          onVideoQualityChanged: onVideoQualityChanged,
          onSubtitleLanguageChanged:
          onSubtitleLanguageChanged,
        );
      },
    );
  }
}

// ===============================================================
// DESKTOP
// ===============================================================

class _DesktopSettings extends StatefulWidget {
  final bool autoplay;
  final bool notifications;
  final bool wifiOnlyDownload;
  final bool biometricLogin;
  final bool subtitles;
  final bool dataSaver;

  final String videoQuality;
  final String subtitleLanguage;

  final ValueChanged<bool> onAutoplayChanged;
  final ValueChanged<bool> onNotificationsChanged;
  final ValueChanged<bool> onWifiOnlyChanged;
  final ValueChanged<bool> onBiometricChanged;
  final ValueChanged<bool> onSubtitlesChanged;
  final ValueChanged<bool> onDataSaverChanged;

  final ValueChanged<String> onVideoQualityChanged;
  final ValueChanged<String> onSubtitleLanguageChanged;

  const _DesktopSettings({
    required this.autoplay,
    required this.notifications,
    required this.wifiOnlyDownload,
    required this.biometricLogin,
    required this.subtitles,
    required this.dataSaver,
    required this.videoQuality,
    required this.subtitleLanguage,
    required this.onAutoplayChanged,
    required this.onNotificationsChanged,
    required this.onWifiOnlyChanged,
    required this.onBiometricChanged,
    required this.onSubtitlesChanged,
    required this.onDataSaverChanged,
    required this.onVideoQualityChanged,
    required this.onSubtitleLanguageChanged,
  });

  @override
  State<_DesktopSettings> createState() =>
      _DesktopSettingsState();
}

class _DesktopSettingsState
    extends State<_DesktopSettings> {
  final ScrollController _scrollController =
  ScrollController();

  final GlobalKey playbackKey = GlobalKey();
  final GlobalKey downloadsKey = GlobalKey();
  final GlobalKey notificationsKey = GlobalKey();
  final GlobalKey securityKey = GlobalKey();
  final GlobalKey accountKey = GlobalKey();

  int selectedIndex = 0;

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  void _scrollToSection(
      GlobalKey key,
      int index,
      ) {
    final targetContext = key.currentContext;

    if (targetContext == null) {
      return;
    }

    setState(() {
      selectedIndex = index;
    });

    Scrollable.ensureVisible(
      targetContext,
      duration: const Duration(
        milliseconds: 500,
      ),
      curve: Curves.easeInOutCubic,
      alignment: 0.05,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xff020B23),
      body: SafeArea(
        child: Row(
          crossAxisAlignment:
          CrossAxisAlignment.start,
          children: [
            const SizedBox(width: 32),

            SizedBox(
              width: 220,
              child: _SettingsSidebar(
                selectedIndex: selectedIndex,
                onPlaybackTap: () {
                  _scrollToSection(
                    playbackKey,
                    0,
                  );
                },
                onDownloadsTap: () {
                  _scrollToSection(
                    downloadsKey,
                    1,
                  );
                },
                onNotificationsTap: () {
                  _scrollToSection(
                    notificationsKey,
                    2,
                  );
                },
                onSecurityTap: () {
                  _scrollToSection(
                    securityKey,
                    3,
                  );
                },
                onAccountTap: () {
                  _scrollToSection(
                    accountKey,
                    4,
                  );
                },
              ),
            ),

            const SizedBox(width: 32),

            Expanded(
              child: _SettingsBody(
                playbackKey: playbackKey,
                downloadsKey: downloadsKey,
                notificationsKey:
                notificationsKey,
                securityKey: securityKey,
                accountKey: accountKey,

                autoplay: widget.autoplay,
                notifications:
                widget.notifications,
                wifiOnlyDownload:
                widget.wifiOnlyDownload,
                biometricLogin:
                widget.biometricLogin,
                subtitles: widget.subtitles,
                dataSaver: widget.dataSaver,

                videoQuality:
                widget.videoQuality,
                subtitleLanguage:
                widget.subtitleLanguage,

                onAutoplayChanged:
                widget.onAutoplayChanged,
                onNotificationsChanged:
                widget.onNotificationsChanged,
                onWifiOnlyChanged:
                widget.onWifiOnlyChanged,
                onBiometricChanged:
                widget.onBiometricChanged,
                onSubtitlesChanged:
                widget.onSubtitlesChanged,
                onDataSaverChanged:
                widget.onDataSaverChanged,
                onVideoQualityChanged:
                widget.onVideoQualityChanged,
                onSubtitleLanguageChanged:
                widget
                    .onSubtitleLanguageChanged,
              ),
            ),

            const SizedBox(width: 40),
          ],
        ),
      ),
    );
  }
}

// ===============================================================
// TABLET
// ===============================================================

class _TabletSettings extends StatelessWidget {
  final bool autoplay;
  final bool notifications;
  final bool wifiOnlyDownload;
  final bool biometricLogin;
  final bool subtitles;
  final bool dataSaver;

  final String videoQuality;
  final String subtitleLanguage;

  final ValueChanged<bool> onAutoplayChanged;
  final ValueChanged<bool> onNotificationsChanged;
  final ValueChanged<bool> onWifiOnlyChanged;
  final ValueChanged<bool> onBiometricChanged;
  final ValueChanged<bool> onSubtitlesChanged;
  final ValueChanged<bool> onDataSaverChanged;

  final ValueChanged<String> onVideoQualityChanged;
  final ValueChanged<String> onSubtitleLanguageChanged;

  const _TabletSettings({
    required this.autoplay,
    required this.notifications,
    required this.wifiOnlyDownload,
    required this.biometricLogin,
    required this.subtitles,
    required this.dataSaver,
    required this.videoQuality,
    required this.subtitleLanguage,
    required this.onAutoplayChanged,
    required this.onNotificationsChanged,
    required this.onWifiOnlyChanged,
    required this.onBiometricChanged,
    required this.onSubtitlesChanged,
    required this.onDataSaverChanged,
    required this.onVideoQualityChanged,
    required this.onSubtitleLanguageChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xff020B23),
      body: SafeArea(
        child: _SettingsBody(
          autoplay: autoplay,
          notifications: notifications,
          wifiOnlyDownload: wifiOnlyDownload,
          biometricLogin: biometricLogin,
          subtitles: subtitles,
          dataSaver: dataSaver,
          videoQuality: videoQuality,
          subtitleLanguage: subtitleLanguage,
          onAutoplayChanged: onAutoplayChanged,
          onNotificationsChanged:
          onNotificationsChanged,
          onWifiOnlyChanged:
          onWifiOnlyChanged,
          onBiometricChanged:
          onBiometricChanged,
          onSubtitlesChanged:
          onSubtitlesChanged,
          onDataSaverChanged:
          onDataSaverChanged,
          onVideoQualityChanged:
          onVideoQualityChanged,
          onSubtitleLanguageChanged:
          onSubtitleLanguageChanged,
        ),
      ),
    );
  }
}

// ===============================================================
// MOBILE
// ===============================================================

class _MobileSettings extends StatelessWidget {
  final bool autoplay;
  final bool notifications;
  final bool wifiOnlyDownload;
  final bool biometricLogin;
  final bool subtitles;
  final bool dataSaver;

  final String videoQuality;
  final String subtitleLanguage;

  final ValueChanged<bool> onAutoplayChanged;
  final ValueChanged<bool> onNotificationsChanged;
  final ValueChanged<bool> onWifiOnlyChanged;
  final ValueChanged<bool> onBiometricChanged;
  final ValueChanged<bool> onSubtitlesChanged;
  final ValueChanged<bool> onDataSaverChanged;

  final ValueChanged<String> onVideoQualityChanged;
  final ValueChanged<String> onSubtitleLanguageChanged;

  const _MobileSettings({
    required this.autoplay,
    required this.notifications,
    required this.wifiOnlyDownload,
    required this.biometricLogin,
    required this.subtitles,
    required this.dataSaver,
    required this.videoQuality,
    required this.subtitleLanguage,
    required this.onAutoplayChanged,
    required this.onNotificationsChanged,
    required this.onWifiOnlyChanged,
    required this.onBiometricChanged,
    required this.onSubtitlesChanged,
    required this.onDataSaverChanged,
    required this.onVideoQualityChanged,
    required this.onSubtitleLanguageChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xff020B23),
      appBar: AppBar(
        backgroundColor: const Color(0xff020B23),
        elevation: 0,
        title: const Text(
          'Settings',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: _SettingsBody(
        autoplay: autoplay,
        notifications: notifications,
        wifiOnlyDownload: wifiOnlyDownload,
        biometricLogin: biometricLogin,
        subtitles: subtitles,
        dataSaver: dataSaver,
        videoQuality: videoQuality,
        subtitleLanguage: subtitleLanguage,
        onAutoplayChanged: onAutoplayChanged,
        onNotificationsChanged:
        onNotificationsChanged,
        onWifiOnlyChanged:
        onWifiOnlyChanged,
        onBiometricChanged:
        onBiometricChanged,
        onSubtitlesChanged:
        onSubtitlesChanged,
        onDataSaverChanged:
        onDataSaverChanged,
        onVideoQualityChanged:
        onVideoQualityChanged,
        onSubtitleLanguageChanged:
        onSubtitleLanguageChanged,
      ),
    );
  }
}

// ===============================================================
// MAIN BODY
// ===============================================================

class _SettingsBody extends StatelessWidget {
  final GlobalKey? playbackKey;
  final GlobalKey? downloadsKey;
  final GlobalKey? notificationsKey;
  final GlobalKey? securityKey;
  final GlobalKey? accountKey;

  final bool autoplay;
  final bool notifications;
  final bool wifiOnlyDownload;
  final bool biometricLogin;
  final bool subtitles;
  final bool dataSaver;

  final String videoQuality;
  final String subtitleLanguage;

  final ValueChanged<bool> onAutoplayChanged;
  final ValueChanged<bool> onNotificationsChanged;
  final ValueChanged<bool> onWifiOnlyChanged;
  final ValueChanged<bool> onBiometricChanged;
  final ValueChanged<bool> onSubtitlesChanged;
  final ValueChanged<bool> onDataSaverChanged;

  final ValueChanged<String> onVideoQualityChanged;
  final ValueChanged<String> onSubtitleLanguageChanged;

  const _SettingsBody({
    this.playbackKey,
    this.downloadsKey,
    this.notificationsKey,
    this.securityKey,
    this.accountKey,
    required this.autoplay,
    required this.notifications,
    required this.wifiOnlyDownload,
    required this.biometricLogin,
    required this.subtitles,
    required this.dataSaver,
    required this.videoQuality,
    required this.subtitleLanguage,
    required this.onAutoplayChanged,
    required this.onNotificationsChanged,
    required this.onWifiOnlyChanged,
    required this.onBiometricChanged,
    required this.onSubtitlesChanged,
    required this.onDataSaverChanged,
    required this.onVideoQualityChanged,
    required this.onSubtitleLanguageChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Scrollbar(
      child: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(
          vertical: 32,
          horizontal: 8,
        ),
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(
              maxWidth: 1100,
            ),
            child: Column(
              crossAxisAlignment:
              CrossAxisAlignment.start,
              children: [
                const _PageHeader(),

                const SizedBox(height: 35),

                // =================================================
                // PLAYBACK
                // =================================================

                _SettingsSection(
                  key: playbackKey,
                  title: 'Playback',
                  subtitle:
                  'Control how your content plays',
                  icon:
                  Icons.play_circle_outline_rounded,
                  children: [
                    _SwitchSetting(
                      icon:
                      Icons.skip_next_rounded,
                      title:
                      'Autoplay Next Episode',
                      subtitle:
                      'Automatically play the next episode',
                      value: autoplay,
                      onChanged:
                      onAutoplayChanged,
                    ),

                    _SwitchSetting(
                      icon: Icons
                          .closed_caption_outlined,
                      title: 'Subtitles',
                      subtitle:
                      'Show subtitles while watching',
                      value: subtitles,
                      onChanged:
                      onSubtitlesChanged,
                    ),

                    _DropdownSetting(
                      icon:
                      Icons.high_quality_outlined,
                      title: 'Video Quality',
                      subtitle:
                      'Choose your preferred streaming quality',
                      value: videoQuality,
                      items: const [
                        'Auto',
                        '480P',
                        '720P',
                        '1080P',
                        '4K',
                      ],
                      onChanged:
                      onVideoQualityChanged,
                    ),

                    _DropdownSetting(
                      icon:
                      Icons.translate_rounded,
                      title:
                      'Subtitle Language',
                      subtitle:
                      'Preferred subtitle language',
                      value: subtitleLanguage,
                      items: const [
                        'English',
                        'Tamil',
                        'Hindi',
                        'Malayalam',
                        'Telugu',
                      ],
                      onChanged:
                      onSubtitleLanguageChanged,
                    ),
                  ],
                ),

                const SizedBox(height: 24),

                // =================================================
                // DOWNLOADS
                // =================================================

                _SettingsSection(
                  key: downloadsKey,
                  title: 'Downloads',
                  subtitle:
                  'Manage offline viewing preferences',
                  icon:
                  Icons.download_outlined,
                  children: [
                    _SwitchSetting(
                      icon: Icons.wifi_rounded,
                      title:
                      'Wi-Fi Only Downloads',
                      subtitle:
                      'Download content only over Wi-Fi',
                      value:
                      wifiOnlyDownload,
                      onChanged:
                      onWifiOnlyChanged,
                    ),

                    _SwitchSetting(
                      icon: Icons
                          .data_saver_on_outlined,
                      title: 'Data Saver',
                      subtitle:
                      'Reduce network usage while streaming',
                      value: dataSaver,
                      onChanged:
                      onDataSaverChanged,
                    ),
                  ],
                ),

                const SizedBox(height: 24),

                // =================================================
                // NOTIFICATIONS
                // =================================================

                _SettingsSection(
                  key: notificationsKey,
                  title: 'Notifications',
                  subtitle:
                  'Choose what notifications you receive',
                  icon: Icons
                      .notifications_none_rounded,
                  children: [
                    _SwitchSetting(
                      icon: Icons
                          .notifications_active_outlined,
                      title:
                      'Push Notifications',
                      subtitle:
                      'New releases, recommendations and updates',
                      value: notifications,
                      onChanged:
                      onNotificationsChanged,
                    ),
                  ],
                ),

                const SizedBox(height: 24),

                // =================================================
                // SECURITY
                // =================================================

                _SettingsSection(
                  key: securityKey,
                  title: 'Security',
                  subtitle:
                  'Protect your account and devices',
                  icon:
                  Icons.security_outlined,
                  children: [
                    _SwitchSetting(
                      icon:
                      Icons.fingerprint_rounded,
                      title:
                      'Biometric Login',
                      subtitle:
                      'Use fingerprint or face authentication',
                      value: biometricLogin,
                      onChanged:
                      onBiometricChanged,
                    ),

                    _ActionSetting(
                      icon:
                      Icons.devices_outlined,
                      title: 'Manage Devices',
                      subtitle:
                      'View and manage signed-in devices',
                      trailing: Icons
                          .chevron_right_rounded,
                      onTap: () {},
                    ),

                    _ActionSetting(
                      icon:
                      Icons.password_outlined,
                      title: 'Change Password',
                      subtitle:
                      'Update your account password',
                      trailing: Icons
                          .chevron_right_rounded,
                      onTap: () {},
                    ),
                  ],
                ),

                const SizedBox(height: 24),

                // =================================================
                // ACCOUNT
                // =================================================

                _SettingsSection(
                  key: accountKey,
                  title: 'Account',
                  subtitle:
                  'Manage your account preferences',
                  icon:
                  Icons.person_outline_rounded,
                  children: [
                    _ActionSetting(
                      icon:
                      Icons.person_outline,
                      title: 'Edit Profile',
                      subtitle:
                      'Update your name, email and mobile',
                      trailing: Icons
                          .chevron_right_rounded,
                      onTap: () {},
                    ),

                    _ActionSetting(
                      icon:
                      Icons.language_rounded,
                      title: 'Language',
                      subtitle: 'English',
                      trailing: Icons
                          .chevron_right_rounded,
                      onTap: () {},
                    ),
                  ],
                ),

                const SizedBox(height: 30),

                const _DangerZone(),

                const SizedBox(height: 40),

                const Center(
                  child: Text(
                    'OTTOne',
                    style: TextStyle(
                      color: Colors.white24,
                      fontSize: 12,
                      fontWeight:
                      FontWeight.w600,
                    ),
                  ),
                ),

                const SizedBox(height: 10),

                const Center(
                  child: Text(
                    'Settings are saved automatically',
                    style: TextStyle(
                      color: Colors.white24,
                      fontSize: 11,
                    ),
                  ),
                ),

                const SizedBox(height: 30),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ===============================================================
// PAGE HEADER
// ===============================================================

class _PageHeader extends StatelessWidget {
  const _PageHeader();

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 52,
          height: 52,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [
                Color(0xffE50914),
                Color(0xff8E24AA),
              ],
            ),
            borderRadius:
            BorderRadius.circular(16),
          ),
          child: const Icon(
            Icons.settings_rounded,
            color: Colors.white,
            size: 27,
          ),
        ),

        const SizedBox(width: 16),

        const Expanded(
          child: Column(
            crossAxisAlignment:
            CrossAxisAlignment.start,
            children: [
              Text(
                'Settings',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  letterSpacing: -.5,
                ),
              ),
              SizedBox(height: 4),
              Text(
                'Customize your OTT experience',
                style: TextStyle(
                  color: Colors.white54,
                  fontSize: 14,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

// ===============================================================
// SIDEBAR
// ===============================================================

class _SettingsSidebar extends StatelessWidget {
  final int selectedIndex;

  final VoidCallback onPlaybackTap;
  final VoidCallback onDownloadsTap;
  final VoidCallback onNotificationsTap;
  final VoidCallback onSecurityTap;
  final VoidCallback onAccountTap;

  const _SettingsSidebar({
    required this.selectedIndex,
    required this.onPlaybackTap,
    required this.onDownloadsTap,
    required this.onNotificationsTap,
    required this.onSecurityTap,
    required this.onAccountTap,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment:
      CrossAxisAlignment.start,
      children: [
        const Text(
          'SETTINGS',
          style: TextStyle(
            color: Colors.white38,
            fontSize: 11,
            fontWeight: FontWeight.bold,
            letterSpacing: 1.5,
          ),
        ),

        const SizedBox(height: 18),

        _SidebarItem(
          icon: Icons.play_circle_outline,
          title: 'Playback',
          selected: selectedIndex == 0,
          onTap: onPlaybackTap,
        ),

        _SidebarItem(
          icon: Icons.download_outlined,
          title: 'Downloads',
          selected: selectedIndex == 1,
          onTap: onDownloadsTap,
        ),

        _SidebarItem(
          icon: Icons.notifications_none,
          title: 'Notifications',
          selected: selectedIndex == 2,
          onTap: onNotificationsTap,
        ),

        _SidebarItem(
          icon: Icons.security_outlined,
          title: 'Security',
          selected: selectedIndex == 3,
          onTap: onSecurityTap,
        ),

        _SidebarItem(
          icon: Icons.person_outline,
          title: 'Account',
          selected: selectedIndex == 4,
          onTap: onAccountTap,
        ),
      ],
    );
  }
}

// ===============================================================
// SIDEBAR ITEM
// ===============================================================

class _SidebarItem extends StatelessWidget {
  final IconData icon;
  final String title;
  final bool selected;
  final VoidCallback? onTap;

  const _SidebarItem({
    required this.icon,
    required this.title,
    this.selected = false,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration:
      const Duration(milliseconds: 200),
      margin:
      const EdgeInsets.only(bottom: 6),
      decoration: BoxDecoration(
        color: selected
            ? const Color(0xffE50914)
            .withOpacity(.12)
            : Colors.transparent,
        borderRadius:
        BorderRadius.circular(12),
        border: selected
            ? Border.all(
          color: const Color(0xffE50914)
              .withOpacity(.18),
        )
            : null,
      ),
      child: ListTile(
        dense: true,
        minVerticalPadding: 8,
        contentPadding:
        const EdgeInsets.symmetric(
          horizontal: 12,
        ),
        leading: Icon(
          icon,
          color: selected
              ? const Color(0xffE50914)
              : Colors.white54,
          size: 20,
        ),
        title: Text(
          title,
          style: TextStyle(
            color: selected
                ? Colors.white
                : Colors.white60,
            fontSize: 13,
            fontWeight: selected
                ? FontWeight.w600
                : FontWeight.normal,
          ),
        ),
        onTap: onTap,
      ),
    );
  }
}

// ===============================================================
// SECTION
// ===============================================================

class _SettingsSection extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final List<Widget> children;

  const _SettingsSection({
    super.key,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.children,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xff0B1736),
        borderRadius:
        BorderRadius.circular(20),
        border: Border.all(
          color: Colors.white.withOpacity(.06),
        ),
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(
              20,
              20,
              20,
              14,
            ),
            child: Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: Colors.white
                        .withOpacity(.06),
                    borderRadius:
                    BorderRadius.circular(12),
                  ),
                  child: Icon(
                    icon,
                    color: Colors.white70,
                    size: 20,
                  ),
                ),

                const SizedBox(width: 12),

                Expanded(
                  child: Column(
                    crossAxisAlignment:
                    CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight:
                          FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        subtitle,
                        style: const TextStyle(
                          color: Colors.white38,
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          const Divider(
            height: 1,
            color: Colors.white10,
          ),

          ..._withDividers(children),
        ],
      ),
    );
  }

  List<Widget> _withDividers(
      List<Widget> children,
      ) {
    final result = <Widget>[];

    for (var i = 0;
    i < children.length;
    i++) {
      result.add(children[i]);

      if (i != children.length - 1) {
        result.add(
          const Divider(
            height: 1,
            indent: 72,
            color: Colors.white10,
          ),
        );
      }
    }

    return result;
  }
}

// ===============================================================
// SWITCH SETTING
// ===============================================================

class _SwitchSetting extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final bool value;
  final ValueChanged<bool> onChanged;

  const _SwitchSetting({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.value,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius:
      BorderRadius.circular(14),
      onTap: () => onChanged(!value),
      child: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: 20,
          vertical: 16,
        ),
        child: Row(
          children: [
            Icon(
              icon,
              color: Colors.white54,
              size: 21,
            ),

            const SizedBox(width: 16),

            Expanded(
              child: Column(
                crossAxisAlignment:
                CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      fontWeight:
                      FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    style: const TextStyle(
                      color: Colors.white38,
                      fontSize: 11,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(width: 12),

            Switch.adaptive(
              value: value,
              onChanged: onChanged,
              activeColor: Colors.white,
              activeTrackColor:
              const Color(0xffE50914),
              inactiveThumbColor:
              Colors.white54,
              inactiveTrackColor:
              Colors.white12,
            ),
          ],
        ),
      ),
    );
  }
}

// ===============================================================
// DROPDOWN
// ===============================================================

class _DropdownSetting extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final String value;
  final List<String> items;
  final ValueChanged<String> onChanged;

  const _DropdownSetting({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.value,
    required this.items,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: 20,
        vertical: 14,
      ),
      child: Row(
        children: [
          Icon(
            icon,
            color: Colors.white54,
            size: 21,
          ),

          const SizedBox(width: 16),

          Expanded(
            child: Column(
              crossAxisAlignment:
              CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight:
                    FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: const TextStyle(
                    color: Colors.white38,
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(width: 12),

          Container(
            padding:
            const EdgeInsets.symmetric(
              horizontal: 4,
            ),
            decoration: BoxDecoration(
              color:
              Colors.white.withOpacity(.05),
              borderRadius:
              BorderRadius.circular(10),
            ),
            child:
            DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                value: value,
                dropdownColor:
                const Color(0xff141E38),
                borderRadius:
                BorderRadius.circular(12),
                icon: const Icon(
                  Icons
                      .keyboard_arrow_down_rounded,
                  color: Colors.white54,
                  size: 18,
                ),
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                ),
                items: items.map((item) {
                  return DropdownMenuItem(
                    value: item,
                    child: Padding(
                      padding:
                      const EdgeInsets
                          .symmetric(
                        horizontal: 8,
                      ),
                      child: Text(item),
                    ),
                  );
                }).toList(),
                onChanged: (value) {
                  if (value != null) {
                    onChanged(value);
                  }
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ===============================================================
// ACTION SETTING
// ===============================================================

class _ActionSetting extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final IconData trailing;
  final VoidCallback onTap;

  const _ActionSetting({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.trailing,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: 20,
          vertical: 17,
        ),
        child: Row(
          children: [
            Icon(
              icon,
              color: Colors.white54,
              size: 21,
            ),

            const SizedBox(width: 16),

            Expanded(
              child: Column(
                crossAxisAlignment:
                CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      fontWeight:
                      FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    style: const TextStyle(
                      color: Colors.white38,
                      fontSize: 11,
                    ),
                  ),
                ],
              ),
            ),

            Icon(
              trailing,
              color: Colors.white30,
              size: 20,
            ),
          ],
        ),
      ),
    );
  }
}

// ===============================================================
// DANGER ZONE
// ===============================================================

class _DangerZone extends StatelessWidget {
  const _DangerZone();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.red.withOpacity(.04),
        borderRadius:
        BorderRadius.circular(20),
        border: Border.all(
          color: Colors.red.withOpacity(.12),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color:
              Colors.red.withOpacity(.08),
              borderRadius:
              BorderRadius.circular(12),
            ),
            child: const Icon(
              Icons.warning_amber_rounded,
              color: Colors.redAccent,
            ),
          ),

          const SizedBox(width: 14),

          const Expanded(
            child: Column(
              crossAxisAlignment:
              CrossAxisAlignment.start,
              children: [
                Text(
                  'Account Actions',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight:
                    FontWeight.bold,
                    fontSize: 14,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  'Sign out from all devices or manage your account.',
                  style: TextStyle(
                    color: Colors.white38,
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          ),

          OutlinedButton(
            style: OutlinedButton.styleFrom(
              foregroundColor:
              Colors.redAccent,
              side: BorderSide(
                color:
                Colors.red.withOpacity(.35),
              ),
              padding:
              const EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 12,
              ),
            ),
            onPressed: () {},
            child: const Text(
              'Sign Out All',
            ),
          ),
        ],
      ),
    );
  }
}