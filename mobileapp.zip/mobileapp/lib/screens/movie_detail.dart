import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../enum/MenuItemType.dart';
import '../features/home/models/movie.dart';
import '../player/controllers/playback_controller.dart';
import '../player/models/payment_state.dart';
import '../widgets/app_shell.dart';
import '../widgets/movie_desktop_layout.dart';
import '../widgets/movie_mobile_layout.dart';
import '../widgets/movie_tablet_layout.dart';
import '../widgets/payment_status_overlay.dart';

class MovieDetailPage extends StatelessWidget {
  final Movie movie;

  const MovieDetailPage({
    super.key,
    required this.movie,
  });

  static const double tabletBreakpoint = 768;
  static const double desktopBreakpoint = 1200;

  @override
  Widget build(BuildContext context) {
    final PlaybackController playback = PlaybackController.instance;

    return AppShell(
      activeMenu: MenuItemType.movies,
      child: Obx(
        () => PopScope(
          // A rental must not be abandoned halfway through the gateway or the
          // verification call.
          canPop: !playback.isChecking.value &&
              !playback.payments.paymentStatus.value.isInProgress,
          child: Stack(
            children: [
              _buildScaffold(context, playback),

              // Rentals run through the same payment surface as subscriptions.
              PaymentStatusOverlay(
                engine: playback.payments,
                onContinue: () => playback.continueAfterRental(
                  context: context,
                  movie: movie,
                ),
                onRetry: playback.payments.reset,
              ),

              if (playback.isChecking.value) _checkingAccess(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildScaffold(
    BuildContext context,
    PlaybackController playback,
  ) {
    void onPlay() {
      playback.play(context: context, movie: movie);
    }

    return Scaffold(
      backgroundColor: const Color(0xff050A18),
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            final width = constraints.maxWidth;

            if (width >= desktopBreakpoint) {
              return MovieDesktopLayout(
                movie: movie,
                onPlay: onPlay,
              );
            }

            if (width >= tabletBreakpoint) {
              return MovieTabletLayout(
                movie: movie,
                onPlay: onPlay,
              );
            }

            return MovieMobileLayout(
              movie: movie,
              onPlay: onPlay,
            );
          },
        ),
      ),
    );
  }

  /// Placeholder while the backend decides whether this title can play.
  ///
  /// Matches the payment surface so the two never look like different apps
  /// when a check runs straight into a rental.
  Widget _checkingAccess() {
    return Positioned.fill(
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Container(
          color: const Color(0xff020B23).withOpacity(.88),
          child: const Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                SizedBox(
                  height: 54,
                  width: 54,
                  child: CircularProgressIndicator(
                    strokeWidth: 3,
                    valueColor: AlwaysStoppedAnimation(Color(0xff7A3CFF)),
                    backgroundColor: Color(0x337A3CFF),
                  ),
                ),

                SizedBox(height: 24),

                Text(
                  'Checking Access',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 19,
                    fontWeight: FontWeight.w800,
                  ),
                ),

                SizedBox(height: 8),

                Text(
                  'Please wait...',
                  style: TextStyle(
                    color: Colors.white70,
                    fontSize: 14,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
