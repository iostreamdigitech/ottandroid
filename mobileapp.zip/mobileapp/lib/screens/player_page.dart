import 'package:flutter/material.dart';

import '../core/widgets/ott_video_player.dart';

/// Thin screen shell around the existing [OTTVideoPlayer] widget.
class PlayerPage extends StatelessWidget {
  final String videoUrl;
  final String title;

  const PlayerPage({
    super.key,
    required this.videoUrl,
    required this.title,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
        title: Text(title, style: const TextStyle(color: Colors.white)),
      ),
      body: Center(
        child: OTTVideoPlayer(
          videoUrl: videoUrl,
          videoId: title,
        ),
      ),
    );
  }
}
