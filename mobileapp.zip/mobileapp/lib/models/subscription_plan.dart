import 'package:flutter/foundation.dart';

class Pricing {
  final int id;
  final int entityId;
  final String entityType;

  final double amount;
  final double? discountedAmount;

  final String currencyCode;
  final String countryIsoCode;

  final String androidProductId;
  final String iosProductId;
  final String iosSubscriptionGroupId;

  final double? taxPercentage;

  final String? priceName;
  final bool active;

  final DateTime? effectiveFrom;
  final DateTime? effectiveTo;

  final DateTime? createdAt;
  final DateTime? updatedAt;

  final int? inAppPurchaseAmount;

  Pricing({
    required this.id,
    required this.entityId,
    required this.entityType,
    required this.amount,
    required this.discountedAmount,
    required this.currencyCode,
    required this.countryIsoCode,
    required this.androidProductId,
    required this.iosProductId,
    required this.iosSubscriptionGroupId,
    required this.taxPercentage,
    required this.priceName,
    required this.active,
    required this.effectiveFrom,
    required this.effectiveTo,
    required this.createdAt,
    required this.updatedAt,
    required this.inAppPurchaseAmount,
  });

  factory Pricing.fromJson(Map<String, dynamic> json) {
    return Pricing(
      id: json['id'] ?? 0,
      entityId: json['entityId'] ?? 0,
      entityType: json['entityType'] ?? '',

      amount: (json['amount'] ?? 0).toDouble(),

      discountedAmount: json['discountedAmount'] != null
          ? (json['discountedAmount']).toDouble()
          : null,

      currencyCode: json['currencyCode'] ?? '',
      countryIsoCode: json['countryIsoCode'] ?? '',

      androidProductId: json['androidProductId'] ?? '',
      iosProductId: json['iosProductId'] ?? '',
      iosSubscriptionGroupId:
      json['iosSubscriptionGroupId'] ?? '',

      taxPercentage: json['taxPercentage'] != null
          ? (json['taxPercentage']).toDouble()
          : null,

      priceName: json['priceName'],

      active: json['active'] ?? false,

      effectiveFrom: json['effectiveFrom'] != null
          ? DateTime.tryParse(json['effectiveFrom'])
          : null,

      effectiveTo: json['effectiveTo'] != null
          ? DateTime.tryParse(json['effectiveTo'])
          : null,

      createdAt: json['createdAt'] != null
          ? DateTime.tryParse(json['createdAt'])
          : null,

      updatedAt: json['updatedAt'] != null
          ? DateTime.tryParse(json['updatedAt'])
          : null,

      inAppPurchaseAmount:
      json['inAppPurchaseAmount'] != null
          ? (json['inAppPurchaseAmount'] as num).toInt()
          : null,
    );
  }

  /// Android / Web
  double get androidWebAmount {
    return amount;
  }

  /// iOS
  double get iosAmount {
    return (inAppPurchaseAmount ?? amount).toDouble();
  }

  /// Automatically select price based on platform.
  double get platformAmount {
    if (defaultTargetPlatform == TargetPlatform.iOS) {
      return iosAmount;
    }

    // Android + Web + Desktop
    return androidWebAmount;
  }
}


class SubscriptionPlan {
  final int id;
  final String planName;
  final String planCode;

  final String planType;

  final int validityDays;
  final int maxDevices;
  final int maxScreens;

  final String videoQuality;
  final String audioQuality;

  final bool accessAllContent;
  final bool watchOnTvLaptop;
  final bool adsFree;
  final bool downloadAllowed;
  final bool featuredPlan;
  final bool adsEnabled;
  final bool liveChannelEnabled;

  final String description;
  final String status;
  final int displayOrder;
  final String image;

  final List<String> features;

  /// M = Monthly
  /// Y = Yearly
  final String type;

  final DateTime? createdAt;
  final DateTime? updatedAt;

  final Pricing? pricing;

  SubscriptionPlan({
    required this.id,
    required this.planName,
    required this.planCode,
    required this.planType,
    required this.validityDays,
    required this.maxDevices,
    required this.maxScreens,
    required this.videoQuality,
    required this.audioQuality,
    required this.accessAllContent,
    required this.watchOnTvLaptop,
    required this.adsFree,
    required this.downloadAllowed,
    required this.featuredPlan,
    required this.adsEnabled,
    required this.liveChannelEnabled,
    required this.description,
    required this.status,
    required this.displayOrder,
    required this.image,
    required this.features,
    required this.type,
    required this.createdAt,
    required this.updatedAt,
    required this.pricing,
  });

  factory SubscriptionPlan.fromJson(
      Map<String, dynamic> json,
      ) {
    return SubscriptionPlan(
      id: json['id'] ?? 0,

      planName: json['planName'] ?? '',
      planCode: json['planCode'] ?? '',

      planType: json['planType'] ?? '',

      validityDays: json['validityDays'] ?? 0,
      maxDevices: json['maxDevices'] ?? 0,
      maxScreens: json['maxScreens'] ?? 0,

      videoQuality: json['videoQuality'] ?? '',
      audioQuality: json['audioQuality'] ?? '',

      accessAllContent:
      json['accessAllContent'] ?? false,

      watchOnTvLaptop:
      json['watchOnTvLaptop'] ?? false,

      adsFree:
      json['adsFree'] ?? false,

      downloadAllowed:
      json['downloadAllowed'] ?? false,

      featuredPlan:
      json['featuredPlan'] ?? false,

      adsEnabled:
      json['adsEnabled'] ?? false,

      liveChannelEnabled:
      json['liveChannelEnabled'] ?? false,

      description:
      json['description'] ?? '',

      status:
      json['status'] ?? '',

      displayOrder:
      json['displayOrder'] ?? 0,

      image:
      json['image'] ?? '',

      features: json['features'] != null
          ? List<String>.from(json['features'])
          : [],

      type:
      json['type'] ?? '',

      createdAt: json['createdAt'] != null
          ? DateTime.tryParse(json['createdAt'])
          : null,

      updatedAt: json['updatedAt'] != null
          ? DateTime.tryParse(json['updatedAt'])
          : null,

      pricing: json['pricing'] != null
          ? Pricing.fromJson(
        json['pricing'] as Map<String, dynamic>,
      )
          : null,
    );
  }

  bool get isMonthly {
    return type.toUpperCase() == 'M';
  }

  bool get isYearly {
    return type.toUpperCase() == 'Y';
  }

  /// Final price to display in UI.
  double get price {
    return pricing?.platformAmount ?? 0;
  }

  /// Android/Web price
  double get androidWebPrice {
    return pricing?.amount ?? 0;
  }

  /// iOS price
  double get iosPrice {
    return pricing?.iosAmount ?? 0;
  }

  String get currency {
    return pricing?.currencyCode ?? 'INR';
  }
}