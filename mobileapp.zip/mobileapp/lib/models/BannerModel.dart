class BannerModel {
  final int id;
  final String title;
  final String subtitle;
  final String description;
  final String bannerType;
  final String placement;
  final String clickAction;
  final String? referenceId;
  final String? externalUrl;
  final int priority;
  final String mobileBannerUrl;
  final String webBannerUrl;
  final String tvBannerUrl;
  final bool active;

  BannerModel({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.description,
    required this.bannerType,
    required this.placement,
    required this.clickAction,
    this.referenceId,
    this.externalUrl,
    required this.priority,
    required this.mobileBannerUrl,
    required this.webBannerUrl,
    required this.tvBannerUrl,
    required this.active,
  });

  factory BannerModel.fromJson(Map<String, dynamic> json) {
    return BannerModel(
      id: json["id"],
      title: json["title"] ?? "",
      subtitle: json["subtitle"] ?? "",
      description: json["description"] ?? "",
      bannerType: json["bannerType"] ?? "",
      placement: json["placement"] ?? "",
      clickAction: json["clickAction"] ?? "",
      referenceId: json["referenceId"],
      externalUrl: json["externalUrl"],
      priority: json["priority"] ?? 0,
      mobileBannerUrl: json["mobileBannerUrl"] ?? "",
      webBannerUrl: json["desktopImageUrl"] ?? "",
      tvBannerUrl: json["tvBannerUrl"] ?? "",
      active: json["active"] ?? false,
    );
  }
}