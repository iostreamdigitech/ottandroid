import '../core/utils/json_parse.dart';

/// Response of the verify-transaction API.
class VerifyTransactionResponse {
  final bool success;

  /// Settlement status, e.g. SUCCESS, CAPTURED, PENDING, FAILED.
  final String status;

  final String message;

  final String transactionId;
  final String orderId;
  final String paymentId;

  /// Subscription details.
  final String planName;
  final String subscriptionStatus;
  final String startDate;
  final String endDate;

  /// Razorpay/backend payment status.
  final String paymentStatus;

  const VerifyTransactionResponse({
    required this.success,
    required this.status,
    required this.message,
    required this.transactionId,
    required this.orderId,
    required this.paymentId,
    required this.planName,
    required this.subscriptionStatus,
    required this.startDate,
    required this.endDate,
    required this.paymentStatus,
  });

  static const Set<String> _settledStatuses = {
    'SUCCESS',
    'SUCCEEDED',
    'PAID',
    'CAPTURED',
    'COMPLETED',
    'VERIFIED',
    'ACTIVE',
  };

  factory VerifyTransactionResponse.fromJson(
      Map<String, dynamic> json,
      ) {
    final Map<String, dynamic> root =
        JsonParse.object(json['data']) ?? json;

    final Map<String, dynamic> subscription =
        JsonParse.object(
          JsonParse.pick(root, const [
            'subscription',
            'userSubscription',
            'activeSubscription',
          ]),
        ) ??
            const {};

    final String status = JsonParse.text(
      JsonParse.pick(root, const [
        'status',
        'paymentStatus',
        'transactionStatus',
      ]),
    ).toUpperCase();

    final String paymentStatus = JsonParse.text(
      JsonParse.pick(root, const [
        'paymentStatus',
        'payment_status',
        'status',
      ]),
    ).toUpperCase();

    return VerifyTransactionResponse(
      success: JsonParse.boolean(
        JsonParse.pick(
          json,
          const ['success', 'verified'],
        ) ??
            JsonParse.pick(
              root,
              const ['success', 'verified'],
            ),
      ),

      status: status,

      message: JsonParse.text(
        JsonParse.pick(
          json,
          const ['message', 'error'],
        ) ??
            JsonParse.pick(
              root,
              const ['message', 'error'],
            ),
      ),

      transactionId: JsonParse.text(
        JsonParse.pick(
          root,
          const ['transactionId', 'txnId'],
        ),
      ),

      orderId: JsonParse.text(
        JsonParse.pick(
          root,
          const [
            'orderId',
            'razorpayOrderId',
          ],
        ),
      ),

      paymentId: JsonParse.text(
        JsonParse.pick(
          root,
          const [
            'paymentId',
            'razorpayPaymentId',
          ],
        ),
      ),

      planName: JsonParse.text(
        JsonParse.pick(
          subscription,
          const ['planName', 'name'],
        ) ??
            JsonParse.pick(
              root,
              const ['planName'],
            ),
      ),

      subscriptionStatus: JsonParse.text(
        JsonParse.pick(
          subscription,
          const ['status'],
        ),
      ),

      startDate: JsonParse.text(
        JsonParse.pick(
          subscription,
          const [
            'startDate',
            'validFrom',
          ],
        ),
      ),

      endDate: JsonParse.text(
        JsonParse.pick(
          subscription,
          const [
            'endDate',
            'validTill',
            'expiryDate',
          ],
        ),
      ),

      paymentStatus: paymentStatus,
    );
  }

  bool get isVerified {
    if (!success) {
      return false;
    }

    if (status.isEmpty) {
      return true;
    }

    return _settledStatuses.contains(status);
  }

  bool get hasSubscriptionDetails =>
      planName.isNotEmpty || endDate.isNotEmpty;
}