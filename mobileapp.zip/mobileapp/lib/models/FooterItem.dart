import 'dart:ui';

class FooterItem {
  final String title;
  final VoidCallback? onTap;

  const FooterItem({
    required this.title,
    this.onTap,
  });
}