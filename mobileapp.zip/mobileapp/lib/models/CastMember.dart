class CastMember {
  final String name;
  final String role;
  final String image;

  CastMember({
    required this.name,
    required this.role,
    required this.image,
  });
}