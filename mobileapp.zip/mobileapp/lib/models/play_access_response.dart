import '../core/utils/json_parse.dart';

/// What the backend says has to happen before a title can play.
enum PlayAccessType {
  /// Already entitled - just play.
  ready,

  /// Needs an active subscription.
  subscription,

  /// Needs a one-off rental purchase for this title.
  rent,

  /// Anything we do not recognise. Treated as "cannot play", never as ready.
  unknown,
}

/// Response of the play-access API.
///
/// Entitlement is a server decision. `playReady` is the only thing that opens
/// the player, and the URL only ever arrives from here - it is never inferred
/// from the catalogue payload.
class PlayAccessResponse {
  /// True when the user may watch right now.
  final bool playReady;

  /// Playable URL. Only populated when [playReady] is true.
  final String videoUrl;

  /// What to buy when [playReady] is false.
  final PlayAccessType type;

  /// Rental price, for display on the confirmation. The backend still prices
  /// the order itself - this is never sent back.
  final double amount;

  final String currency;

  /// Backend explanation, shown when access is refused for a reason the user
  /// cannot buy their way out of.
  final String message;

  const PlayAccessResponse({
    required this.playReady,
    required this.videoUrl,
    required this.type,
    required this.amount,
    required this.currency,
    required this.message,
  });

  factory PlayAccessResponse.fromJson(Map<String, dynamic> json) {
    // The payload may be flat or wrapped in the usual `data` envelope.
    final Map<String, dynamic> root =
        JsonParse.object(json['data']) ?? json;

    final bool ready = JsonParse.boolean(
      JsonParse.pick(root, const [
        'playReady',
        'play_ready',
        'canPlay',
        'entitled',
      ]),
    );

    return PlayAccessResponse(
      playReady: ready,

      videoUrl: JsonParse.text(
        JsonParse.pick(root, const [
          'videoUrl',
          'playUrl',
          'playbackUrl',
          'streamUrl',
          'url',
        ]),
      ),

      type: _parseType(
        JsonParse.text(
          JsonParse.pick(root, const [
            'type',
            'accessType',
            'purchaseType',
            'monetizationType',
          ]),
        ),
        ready: ready,
      ),

      amount: JsonParse.decimal(
        JsonParse.pick(root, const [
          'amount',
          'price',
          'rentAmount',
          'rentalAmount',
        ]),
      ),

      currency: JsonParse.text(
        JsonParse.pick(root, const ['currency', 'currencyCode']),
        fallback: 'INR',
      ),

      message: JsonParse.text(
        JsonParse.pick(json, const ['message', 'error']) ??
            JsonParse.pick(root, const ['message', 'error']),
      ),
    );
  }

  /// Ready to hand to the player.
  ///
  /// A `playReady` with no URL is a backend bug, not permission to play - the
  /// caller has to surface it rather than open an empty player.
  bool get isPlayable => playReady && videoUrl.isNotEmpty;

  static PlayAccessType _parseType(
    String raw, {
    required bool ready,
  }) {
    switch (raw.toUpperCase()) {
      case 'SUBSCRIPTION':
      case 'SVOD':
        return PlayAccessType.subscription;

      case 'RENT':
      case 'RENTAL':
      case 'TVOD':
        return PlayAccessType.rent;

      case 'FREE':
      case 'AVOD':
      case 'READY':
      case 'PURCHASED':
        return PlayAccessType.ready;
    }

    // No type at all is fine when access was granted; otherwise we genuinely
    // do not know what to ask the user for.
    return ready ? PlayAccessType.ready : PlayAccessType.unknown;
  }
}
