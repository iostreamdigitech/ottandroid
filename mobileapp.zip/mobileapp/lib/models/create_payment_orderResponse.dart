import '../core/utils/json_parse.dart';

/// Response of the create-order API.
///
/// The backend owns the payable amount and creates the Razorpay order on our
/// behalf - the client never computes a price and never talks to Razorpay's
/// order API directly. Everything here is read back from the server and handed
/// straight to the Razorpay checkout sheet.
class CreatePaymentOrderResponse {
  /// Our purchase order (backend primary key).
  final int purchaseOrderId;

  /// Our payment transaction row (backend primary key).
  final int paymentTransactionId;

  /// Our human-facing order reference.
  final String orderId;

  /// Our human-facing transaction reference, shown on the result screen.
  final String transactionId;

  /// Razorpay's order id (`order_xxxxxxxx`) - this is what the checkout sheet
  /// needs, and it is NOT the same value as [orderId].
  final String razorpayOrderId;

  /// Razorpay publishable key id for the account the order was created in.
  ///
  /// Empty when the backend does not return one, in which case the caller
  /// falls back to `AppConfigService.razorpayKeyId`.
  final String razorpayKeyId;

  /// Payable amount in major units (e.g. 499.00 rupees) - display only.
  final double amount;

  /// Payable amount in the smallest currency unit (e.g. 49900 paise), which is
  /// the only form Razorpay accepts.
  final int amountInMinorUnits;

  final String currency;
  final int subscriptionPlanId;
  final String status;

  /// Checkout prefill, supplied by the backend from the authenticated user so
  /// the client does not have to load the profile just to open a payment.
  final String customerName;
  final String customerEmail;
  final String customerPhone;

  /// Backend message, surfaced when the order could not be created.
  final String message;

  const CreatePaymentOrderResponse({
    required this.purchaseOrderId,
    required this.paymentTransactionId,
    required this.orderId,
    required this.transactionId,
    required this.razorpayOrderId,
    required this.razorpayKeyId,
    required this.amount,
    required this.amountInMinorUnits,
    required this.currency,
    required this.subscriptionPlanId,
    required this.status,
    required this.customerName,
    required this.customerEmail,
    required this.customerPhone,
    required this.message,
  });

  factory CreatePaymentOrderResponse.fromJson(
    Map<String, dynamic> json,
  ) {
    final double amount = JsonParse.decimal(
      JsonParse.pick(json, const [
        'amount',
        'payableAmount',
        'totalAmount',
      ]),
    );

    return CreatePaymentOrderResponse(
      purchaseOrderId: JsonParse.integer(json['purchaseOrderId']),
      paymentTransactionId:
          JsonParse.integer(json['paymentTransactionId']),

      orderId: JsonParse.text(json['orderId']),

      transactionId: JsonParse.text(
        JsonParse.pick(json, const ['transactionId', 'txnId']),
      ),

      razorpayOrderId: JsonParse.text(
        JsonParse.pick(json, const [
          'razorpayOrderId',
          'razorpay_order_id',
          'gatewayOrderId',
        ]),
      ),

      razorpayKeyId: JsonParse.text(
        JsonParse.pick(json, const [
          'razorpayKeyId',
          'razorpay_key_id',
          'keyId',
          'key',
        ]),
      ),

      amount: amount,
      amountInMinorUnits: _resolveMinorUnits(json, amount),

      currency: JsonParse.text(json['currency'], fallback: 'INR'),

      status: JsonParse.text(json['status']),

      subscriptionPlanId: JsonParse.integer(
        JsonParse.pick(json, const ['subscriptionPlanId', 'planId']),
      ),

      customerName: JsonParse.text(
        JsonParse.pick(json, const [
          'customerName',
          'name',
          'fullName',
        ]),
      ),
      customerEmail: JsonParse.text(
        JsonParse.pick(json, const ['customerEmail', 'email']),
      ),
      customerPhone: JsonParse.text(
        JsonParse.pick(json, const [
          'customerPhone',
          'contact',
          'mobileNumber',
          'phone',
        ]),
      ),

      message: JsonParse.text(
        JsonParse.pick(json, const [
          'message',
          'error',
          'description',
        ]),
      ),
    );
  }

  /// An order is only usable if Razorpay can actually be opened with it.
  bool get isUsable =>
      razorpayOrderId.isNotEmpty && amountInMinorUnits > 0;

  /// Razorpay only accepts the smallest currency unit.
  ///
  /// Prefer an explicit minor-unit field from the backend. Only when none is
  /// present do we derive it from `amount`, which assumes `amount` is
  /// expressed in major units (499.00 -> 49900).
  static int _resolveMinorUnits(
    Map<String, dynamic> json,
    double amount,
  ) {
    final explicit = JsonParse.pick(json, const [
      'amountInPaise',
      'amountInMinorUnits',
      'amountMinor',
      'amountInSmallestUnit',
    ]);

    if (explicit != null) {
      return JsonParse.integer(explicit);
    }

    return (amount * 100).round();
  }
}
