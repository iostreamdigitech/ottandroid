import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/services.dart';

import 'analytics/services/analytics_manager.dart';


import 'features/splash/splash_screen.dart';
import 'firebase_options.dart';
import 'observer/analytics_navigator_observer.dart';


Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  print("App Start: ${DateTime.now()}");
  await SystemChrome.setEnabledSystemUIMode(
    SystemUiMode.immersiveSticky,
  );
  await initializeFirebase();
  // Initialize Firebase
  await Firebase.initializeApp();

  // Initialize Analytics
  await AnalyticsManager.instance.initialize();

  runApp(const MyApp());
}
Future<void> initializeFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
  } else {
    await Firebase.initializeApp();
  }
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,

      navigatorObservers: [
        AnalyticsNavigatorObserver(),
      ],

      home: const SplashScreen(),
    );
  }
}