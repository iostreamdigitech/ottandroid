import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

class DeviceUtils {
  DeviceUtils._();

  static double width(BuildContext context) =>
      MediaQuery.of(context).size.width;

  static double height(BuildContext context) =>
      MediaQuery.of(context).size.height;

  static bool isMobile(BuildContext context) =>
      width(context) < 700;

  static bool isTablet(BuildContext context) =>
      width(context) >= 700 && width(context) < 1100;

  static bool isDesktop(BuildContext context) =>
      width(context) >= 1100;

  /// Android TV / Smart TV Layout
  static bool isTV(BuildContext context) =>
      width(context) >= 1600;

  static bool isWeb() => kIsWeb;
  static double titleSize(BuildContext context) {
    if (isTV(context)) return 36;
    if (isDesktop(context)) return 32;
    if (isTablet(context)) return 28;
    return 24;
  }
  static bool isLandscape(BuildContext context) =>
      MediaQuery.of(context).orientation ==
          Orientation.landscape;

  static double horizontalPadding(BuildContext context) {
    if (isTV(context)) return 64;
    if (isDesktop(context)) return 48;
    if (isTablet(context)) return 32;
    return 16;
  }

  static int liveChannelGrid(BuildContext context){

    if(isTV(context))
      return 6;


    if(isDesktop(context))
      return 5;


    if(isTablet(context))
      return 3;


    return 2;

  }

  static double cardRadius(BuildContext context) {
    if (isTV(context)) return 28;
    if (isDesktop(context)) return 24;
    return 18;
  }

  static double titleFont(BuildContext context) {
    if (isTV(context)) return 36;
    if (isDesktop(context)) return 30;
    if (isTablet(context)) return 26;
    return 22;
  }

  static double bodyFont(BuildContext context) {
    if (isTV(context)) return 22;
    if (isDesktop(context)) return 18;
    if (isTablet(context)) return 16;
    return 14;
  }

  static int gridCount(BuildContext context) {
    if (isTV(context)) return 5;
    if (isDesktop(context)) return 4;
    if (isTablet(context)) return 2;
    return 1;
  }
}