import 'package:flutter/foundation.dart';

class AppLogger {
  static void log(String message) {
    if (kDebugMode) {
      debugPrint("🟢 OTT LOG: $message");
    }
  }

  static void error(String message) {
    if (kDebugMode) {
      debugPrint("🔴 OTT ERROR: $message");
    }
  }

  static void warn(String message) {
    if (kDebugMode) {
      debugPrint("🟠 OTT WARN: $message");
    }
  }
}