/// Defensive JSON readers for payment payloads.
///
/// A payment must never crash on an unexpected or missing field - it has to
/// fail with a message the user can act on - so every read here is total.
class JsonParse {
  JsonParse._();

  /// Returns the first non-null value among [keys].
  ///
  /// Field naming differs across payment endpoints; rather than guessing a
  /// single spelling and failing a real payment, accept the common ones.
  static dynamic pick(
    Map<String, dynamic> json,
    List<String> keys,
  ) {
    for (final key in keys) {
      final value = json[key];
      if (value != null) {
        return value;
      }
    }
    return null;
  }

  static String text(
    dynamic value, {
    String fallback = '',
  }) {
    if (value == null) {
      return fallback;
    }

    final text = value.toString().trim();

    if (text.isEmpty || text == 'null') {
      return fallback;
    }

    return text;
  }

  static int integer(dynamic value) {
    if (value is int) {
      return value;
    }

    if (value is num) {
      return value.toInt();
    }

    return int.tryParse(value?.toString() ?? '') ?? 0;
  }

  static double decimal(dynamic value) {
    if (value is num) {
      return value.toDouble();
    }

    return double.tryParse(value?.toString() ?? '') ?? 0;
  }

  static bool boolean(dynamic value) {
    if (value is bool) {
      return value;
    }

    final text = value?.toString().toLowerCase().trim();

    return text == 'true' || text == '1';
  }

  /// Returns [value] as a string-keyed map, or `null` when it is not one.
  static Map<String, dynamic>? object(dynamic value) {
    if (value is Map<String, dynamic>) {
      return value;
    }

    if (value is Map) {
      return value.map(
        (key, dynamic v) => MapEntry(key.toString(), v),
      );
    }

    return null;
  }
}
