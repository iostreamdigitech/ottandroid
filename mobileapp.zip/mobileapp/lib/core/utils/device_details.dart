import 'dart:io' show Platform;
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/foundation.dart';

class DeviceDetails {
  final String deviceId;
  final String deviceType;
  final String deviceName;

  DeviceDetails({
    required this.deviceId,
    required this.deviceType,
    required this.deviceName,
  });

  Map<String, dynamic> toJson() => {
    "deviceId": deviceId,
    "deviceType": deviceType,
    "deviceName": deviceName,
  };
}

class DeviceHelper {
  static Future<DeviceDetails> getDeviceDetails() async {
    final deviceInfo = DeviceInfoPlugin();

    if (kIsWeb) {
      final web = await deviceInfo.webBrowserInfo;
      return DeviceDetails(
        deviceId: web.userAgent ?? "web",
        deviceType: "WEB",
        deviceName: web.browserName.name,
      );
    }

    if (Platform.isAndroid) {
      final android = await deviceInfo.androidInfo;
      return DeviceDetails(
        deviceId: android.id,
        deviceType: "ANDROID",
        deviceName: "${android.manufacturer} ${android.model}",
      );
    }

    if (Platform.isIOS) {
      final ios = await deviceInfo.iosInfo;
      return DeviceDetails(
        deviceId: ios.identifierForVendor ?? "",
        deviceType: "IOS",
        deviceName: ios.utsname.machine,
      );
    }

    if (Platform.isWindows) {
      final windows = await deviceInfo.windowsInfo;
      return DeviceDetails(
        deviceId: windows.deviceId,
        deviceType: "WINDOWS",
        deviceName: windows.computerName,
      );
    }

    if (Platform.isMacOS) {
      final mac = await deviceInfo.macOsInfo;
      return DeviceDetails(
        deviceId: mac.systemGUID ?? "",
        deviceType: "MACOS",
        deviceName: mac.model,
      );
    }

    if (Platform.isLinux) {
      final linux = await deviceInfo.linuxInfo;
      return DeviceDetails(
        deviceId: linux.machineId ?? "",
        deviceType: "LINUX",
        deviceName: linux.prettyName,
      );
    }

    return DeviceDetails(
      deviceId: "unknown",
      deviceType: "UNKNOWN",
      deviceName: "Unknown Device",
    );
  }
}