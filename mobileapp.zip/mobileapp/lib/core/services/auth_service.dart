class AuthService {
  static String? token;

  static bool get isLoggedIn => token != null;

  static void login(String userToken) {
    token = userToken;
  }

  static void logout() {
    token = null;
  }
}