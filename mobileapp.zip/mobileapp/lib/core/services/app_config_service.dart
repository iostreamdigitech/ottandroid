class AppConfigService {
  static const String appName = "OTT Platform";
  static const String version = "1.0.0";

  static const bool isProduction = false;

  // Feature flags (OTT control system)
  static const bool enableLiveTv = true;
  static const bool enableDownloads = true;

  // ---------------------------------------------------------------------------
  // Razorpay
  // ---------------------------------------------------------------------------

  /// Razorpay *publishable* key id.
  ///
  /// Supplied at build time, never committed:
  ///
  ///   flutter run --dart-define=RAZORPAY_KEY_ID=rzp_test_xxxxxxxxxxxx
  ///
  /// Used only as a fallback - the key id returned by the create-order
  /// response takes priority, so the backend stays in control of which
  /// Razorpay account a payment lands in.
  ///
  /// The Razorpay key *secret* must never be shipped in the app. Signature
  /// verification happens server side, in the verify-transaction API.
  static const String razorpayKeyId =
      String.fromEnvironment('RAZORPAY_KEY_ID');

  /// Merchant name shown on the Razorpay checkout sheet.
  static const String razorpayMerchantName = "OTTONE";

  /// Checkout accent colour - matches the subscription gradient.
  static const String razorpayThemeColor = "#7A3CFF";

  /// How long Razorpay keeps the checkout sheet open, in seconds.
  static const int razorpayCheckoutTimeoutSeconds = 300;
}
