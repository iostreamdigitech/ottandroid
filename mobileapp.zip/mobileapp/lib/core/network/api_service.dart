import 'api_client.dart';
import '../constants/api_constants.dart';

class ApiService {
  // GET Movies
  static Future getMovies() async {
    final response = await ApiClient.dio.get(ApiConstants.movies);
    return response.data;
  }

  // GET Live TV
  static Future getLiveTv() async {
    final response = await ApiClient.dio.get(ApiConstants.liveTv);
    return response.data;
  }

  // LOGIN
  static Future login(String email, String password) async {
    final response = await ApiClient.dio.post(
      ApiConstants.login,
      data: {
        "email": email,
        "password": password,
      },
    );
    return response.data;
  }
}