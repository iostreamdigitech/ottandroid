class AppStrings {
  static const String appName = "OTT Platform";
  static const String home = "Home";
  static const String movies = "Movies";
  static const String liveTv = "Live TV";
  static const String sports = "Sports";
  static const String profile = "Profile";
}