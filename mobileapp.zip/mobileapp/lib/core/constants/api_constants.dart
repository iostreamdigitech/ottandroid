class ApiConstants {
  static const String baseUrl = "https://apiottone.ottone.in/api-gateway";

  // Endpoints
  static const String movies = "/movies";
  static const String liveTv = "/live-tv";
  static const String sports = "/sports";
  static const String login = "/auth/login";
  static const String profile = "/user/profile";

  // ---------------------------------------------------------------------------
  // Payments / Subscriptions (payService)
  //
  // Every path below is served by the gateway and must be called through
  // ApiService.instance.dio so the bearer token, HMAC headers and payload
  // encryption are applied.
  // ---------------------------------------------------------------------------

  /// Subscription plan catalogue.
  static const String subscriptionPlans =
      "/payService/api/subscription-plans/all";

  /// Creates the purchase order + Razorpay order on the backend.
  ///
  /// Used for both subscriptions and single-title rentals - only the request
  /// body differs. The backend owns the payable amount; the client just names
  /// what it wants to buy. See [CreatePaymentOrderResponse].
  static const String createPaymentOrder =
      "/payService//api/v1/payment/createOrder";

  /// Verifies the Razorpay signature and settles the transaction.
  ///
  /// This is the only source of truth for "the subscription is active".
  static const String verifyPaymentTransaction =
      "/payService//api/v1/payment/verify";

  /// Currently active subscription for the signed-in user.
  static const String activeSubscription =
      "/payService/api/payments/subscriptions/user/me/active";

  // ---------------------------------------------------------------------------
  // Playback entitlement (contentservice)
  // ---------------------------------------------------------------------------

  /// Asks the backend whether this user may play this title right now.
  ///
  /// The answer carries the playable URL when access is granted, and otherwise
  /// says what has to be bought first. The client never decides this itself.
  static String contentPlayAccess(int contentId) =>
      "/contentservice/api/v1/content/$contentId/play";
}
