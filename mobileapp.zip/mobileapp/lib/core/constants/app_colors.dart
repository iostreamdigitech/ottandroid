import 'package:flutter/material.dart';

class AppColors {
  static const bg = Color(0xff020B23);
  static const card = Color(0xff0F1733);
  static const chip = Color(0xff121B37);

  static const primary = Color(0xffFF3D54);

  static const text = Colors.white;
  static const text2 = Colors.white70;
  static const background = Color(0xff020B23);

  static const secondary = Colors.white;
  static const grey = Colors.grey;
}