import 'package:chewie/chewie.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';

class OTTVideoPlayer extends StatefulWidget {
  final String videoUrl;     // HLS master.m3u8
  final String videoId;

  // Skip intro config (from
  // backend)
  final int introStart;
  final int introEnd;

  const OTTVideoPlayer({
    super.key,
    required this.videoUrl,
    required this.videoId,
    this.introStart = 0,
    this.introEnd = 0,
  });

  @override
  State<OTTVideoPlayer> createState() => _OTTVideoPlayerState();
}

class _OTTVideoPlayerState extends State<OTTVideoPlayer> {
  VideoPlayerController? _controller;
  ChewieController? _chewieController;

  bool _loading = true;
  bool _showSkipIntro = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _initPlayer();
  }

  Future<void> _initPlayer() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final savedPosition = prefs.getInt("resume_${widget.videoId}") ?? 0;

      _controller = VideoPlayerController.networkUrl(
        Uri.parse(widget.videoUrl),
        formatHint: VideoFormat.hls,
      );

      await _controller!.initialize();

      // Resume playback
      if (savedPosition > 0) {
        await _controller!.seekTo(Duration(seconds: savedPosition));
      }

      _chewieController = ChewieController(
        videoPlayerController: _controller!,
        autoPlay: true,
        looping: false,
        allowFullScreen: true,
        allowPlaybackSpeedChanging: true,
        showControls: true,
        materialProgressColors: ChewieProgressColors(
          playedColor: Colors.red,
          handleColor: Colors.red,
          bufferedColor: Colors.grey,
          backgroundColor: Colors.white24,
        ),
      );

      _controller!.addListener(_playerListener);

      if (mounted) {
        setState(() => _loading = false);
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _error = e.toString();
          _loading = false;
        });
      }
    }
  }

  void _playerListener() async {
    if (_controller == null || !_controller!.value.isInitialized) return;

    final position = _controller!.value.position.inSeconds;

    // Save resume position every few seconds
    if (position % 5 == 0) {
      final prefs = await SharedPreferences.getInstance();
      prefs.setInt("resume_${widget.videoId}", position);
    }

    // Skip intro logic
    if (widget.introEnd > 0) {
      if (position >= widget.introStart && position <= widget.introEnd) {
        if (!_showSkipIntro) {
          setState(() => _showSkipIntro = true);
        }
      } else {
        if (_showSkipIntro) {
          setState(() => _showSkipIntro = false);
        }
      }
    }
  }

  void _skipIntro() {
    _controller?.seekTo(Duration(seconds: widget.introEnd));
    setState(() => _showSkipIntro = false);
  }

  @override
  void dispose() {
    _controller?.removeListener(_playerListener);
    _controller?.dispose();
    _chewieController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (_error != null) {
      return Center(
        child: Text(
          "Error loading video\n$_error",
          textAlign: TextAlign.center,
          style: const TextStyle(color: Colors.red),
        ),
      );
    }

    return Stack(
      children: [
        // VIDEO
        AspectRatio(
          aspectRatio: _controller!.value.aspectRatio,
          child: Chewie(controller: _chewieController!),
        ),

        // SKIP INTRO BUTTON
        if (_showSkipIntro)
          Positioned(
            bottom: 80,
            right: 16,
            child: ElevatedButton.icon(
              onPressed: _skipIntro,
              icon: const Icon(Icons.skip_next),
              label: const Text("Skip Intro"),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.black87,
              ),
            ),
          ),

        // BUFFERING INDICATOR
        if (_controller!.value.isBuffering)
          const Center(
            child: CircularProgressIndicator(),
          ),
      ],
    );
  }
}