import 'package:flutter/material.dart';

class MovieCard extends StatelessWidget {
  final String title;

  const MovieCard({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 120,
      margin: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: Colors.grey.shade900,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Center(
        child: Text(title),
      ),
    );
  }
}