import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';

class SearchResultModel {
  final String id;
  final String title;
  final String contentType;

  final String? originalTitle;
  final String? shortDescription;
  final String? poster;
  final String? banner;
  final String? thumbnail;
  final String? language;
  final String? rating;
  final String? duration;
  final int? releaseYear;
  final String? quality;
  final String? slug;
  final bool? premium;
  final bool? downloadable;
  final bool? drmEnabled;
  final bool? hdrEnabled;
  final double? watchProgress;

  final List<MediaAssetModel> mediaAssets;

  const SearchResultModel({
    required this.id,
    required this.title,
    required this.contentType,
    this.originalTitle,
    this.shortDescription,
    this.poster,
    this.banner,
    this.thumbnail,
    this.language,
    this.rating,
    this.duration,
    this.releaseYear,
    this.quality,
    this.slug,
    this.premium,
    this.downloadable,
    this.drmEnabled,
    this.hdrEnabled,
    this.watchProgress,
    this.mediaAssets = const [],
  });

  factory SearchResultModel.fromJson(
      Map<String, dynamic> json) {
    final rawMediaAssets = json['mediaAssets'];

    return SearchResultModel(
      id: (json['id'] ?? '').toString(),
      title: (json['title'] ?? '').toString(),
      originalTitle: json['originalTitle']?.toString(),
      shortDescription:
      json['shortDescription']?.toString(),
      poster: json['poster']?.toString(),
      banner: json['banner']?.toString(),
      thumbnail: json['thumbnail']?.toString(),
      contentType:
      (json['contentType'] ?? '').toString(),
      language: json['language']?.toString(),
      rating: json['rating']?.toString(),
      duration: json['duration']?.toString(),
      releaseYear:
      _toInt(json['releaseYear']),
      quality: json['quality']?.toString(),
      slug: json['slug']?.toString(),
      premium: json['premium'],
      downloadable: json['downloadable'],
      drmEnabled: json['drmEnabled'],
      hdrEnabled: json['hdrEnabled'],
      watchProgress:
      _toDouble(json['watchProgress']),
      mediaAssets: rawMediaAssets is List
          ? rawMediaAssets
          .whereType<Map>()
          .map(
            (item) =>
            MediaAssetModel.fromJson(
              Map<String, dynamic>.from(item),
            ),
      )
          .toList()
          : const [],
    );
  }

  // --------------------------------------------------
  // DEVICE PLATFORM
  // --------------------------------------------------

  String get devicePlatform {

    // Flutter Web
    if (kIsWeb) {
      return 'WEB';
    }

    // Android / iOS
    switch (defaultTargetPlatform) {

      case TargetPlatform.android:
      case TargetPlatform.iOS:
        return 'MOBILE';

      case TargetPlatform.macOS:
      case TargetPlatform.windows:
      case TargetPlatform.linux:
        return 'WEB';

      case TargetPlatform.fuchsia:
        return 'MOBILE';
    }
  }

  // --------------------------------------------------
  // GET ASSET
  // --------------------------------------------------

  String? getAssetUrl({
    required String assetType,
    String? platform,
  }) {

    final targetPlatform =
        platform ?? devicePlatform;

    // 1. Exact device/platform match
    final exactMatch = mediaAssets.where(
          (asset) =>
      asset.assetType.toUpperCase() ==
          assetType.toUpperCase() &&
          asset.platform.toUpperCase() ==
              targetPlatform.toUpperCase(),
    );

    if (exactMatch.isNotEmpty) {
      return exactMatch.first.filePath;
    }

    // 2. Fallback to WEB
    final webMatch = mediaAssets.where(
          (asset) =>
      asset.assetType.toUpperCase() ==
          assetType.toUpperCase() &&
          asset.platform.toUpperCase() == 'WEB',
    );

    if (webMatch.isNotEmpty) {
      return webMatch.first.filePath;
    }

    // 3. Fallback to MOBILE
    final mobileMatch = mediaAssets.where(
          (asset) =>
      asset.assetType.toUpperCase() ==
          assetType.toUpperCase() &&
          asset.platform.toUpperCase() == 'MOBILE',
    );

    if (mobileMatch.isNotEmpty) {
      return mobileMatch.first.filePath;
    }

    // 4. No asset
    return null;
  }

  // --------------------------------------------------
  // POSTER
  // --------------------------------------------------

  String? get posterUrl {
    return getAssetUrl(
      assetType: 'POSTER',
    );
  }

  // --------------------------------------------------
  // BANNER
  // --------------------------------------------------

  String? get bannerUrl {
    return getAssetUrl(
      assetType: 'BANNER',
    );
  }

  // --------------------------------------------------
  // THUMBNAIL
  // --------------------------------------------------

  String? get thumbnailUrl {
    return getAssetUrl(
      assetType: 'THUMBNAIL',
    );
  }

  // --------------------------------------------------
  // JSON
  // --------------------------------------------------

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'originalTitle': originalTitle,
      'shortDescription': shortDescription,
      'poster': poster,
      'banner': banner,
      'thumbnail': thumbnail,
      'contentType': contentType,
      'language': language,
      'rating': rating,
      'duration': duration,
      'releaseYear': releaseYear,
      'quality': quality,
      'slug': slug,
      'premium': premium,
      'downloadable': downloadable,
      'drmEnabled': drmEnabled,
      'hdrEnabled': hdrEnabled,
      'watchProgress': watchProgress,
      'mediaAssets':
      mediaAssets.map((e) => e.toJson()).toList(),
    };
  }

  static int? _toInt(dynamic value) {
    if (value == null) return null;

    if (value is int) return value;

    return int.tryParse(value.toString());
  }

  static double? _toDouble(dynamic value) {
    if (value == null) return null;

    if (value is double) return value;

    if (value is int) {
      return value.toDouble();
    }

    return double.tryParse(value.toString());
  }
}


class MediaAssetModel {
  final String id;
  final String assetType;
  final String platform;
  final String? fileName;
  final String? filePath;
  final int? fileSize;

  const MediaAssetModel({
    required this.id,
    required this.assetType,
    required this.platform,
    this.fileName,
    this.filePath,
    this.fileSize,
  });

  factory MediaAssetModel.fromJson(
      Map<String, dynamic> json) {

    return MediaAssetModel(
      id: (json['id'] ?? '').toString(),
      assetType:
      (json['assetType'] ?? '').toString(),
      platform:
      (json['platform'] ?? '').toString(),
      fileName:
      json['fileName']?.toString(),
      filePath:
      json['filePath']?.toString(),
      fileSize:
      json['fileSize'] is int
          ? json['fileSize']
          : int.tryParse(
        json['fileSize']?.toString() ?? '',
      ),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'assetType': assetType,
      'platform': platform,
      'fileName': fileName,
      'filePath': filePath,
      'fileSize': fileSize,
    };
  }
}