import 'search_result_model.dart';

class SearchResponseModel {
  final String keyword;
  final int page;
  final int size;
  final int totalElements;
  final int totalPages;
  final bool hasNext;
  final List<SearchResultModel> contents;

  const SearchResponseModel({
    required this.keyword,
    required this.page,
    required this.size,
    required this.totalElements,
    required this.totalPages,
    required this.hasNext,
    required this.contents,
  });

  factory SearchResponseModel.fromJson(Map<String, dynamic> json) {
    final dynamic data = json['data'];

    final Map<String, dynamic> payload =
    data is Map<String, dynamic>
        ? data
        : data is Map
        ? Map<String, dynamic>.from(data)
        : json;

    final rawContents = payload['contents'];

    return SearchResponseModel(
      keyword: (payload['keyword'] ?? '').toString(),
      page: _toInt(payload['page']),
      size: _toInt(payload['size']),
      totalElements: _toInt(payload['totalElements']),
      totalPages: _toInt(payload['totalPages']),
      hasNext: payload['hasNext'] == true,
      contents: rawContents is List
          ? rawContents
          .whereType<Map>()
          .map(
            (item) => SearchResultModel.fromJson(
          Map<String, dynamic>.from(item),
        ),
      )
          .toList()
          : <SearchResultModel>[],
    );
  }

  static int _toInt(dynamic value) {
    if (value is int) {
      return value;
    }

    return int.tryParse(
      value?.toString() ?? '',
    ) ??
        0;
  }
}