import 'package:flutter/material.dart';

class SearchCategoryModel {
  final String code;
  final String name;
  final IconData icon;

  const SearchCategoryModel({
    required this.code,
    required this.name,
    required this.icon,
  });

  factory SearchCategoryModel.fromJson(Map<String, dynamic> json) {
    final code =
    (json['code'] ?? json['categoryCode'] ?? '').toString().toUpperCase();

    return SearchCategoryModel(
      code: code,
      name: (json['name'] ?? code).toString(),
      icon: _iconForCode(code),
    );
  }

  static IconData _iconForCode(String code) {
    switch (code) {
      case 'MOVIE':
      case 'MOVIES':
        return Icons.movie_creation_outlined;

      case 'SERIES':
      case 'WEB_SERIES':
        return Icons.live_tv_outlined;

      case 'LIVE_TV':
      case 'LIVE':
        return Icons.tv_outlined;

      case 'SPORTS':
        return Icons.sports_cricket_outlined;

      default:
        return Icons.category_outlined;
    }
  }
}