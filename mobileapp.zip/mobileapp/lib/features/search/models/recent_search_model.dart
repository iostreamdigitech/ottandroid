class RecentSearchModel {
  final String? id;
  final String keyword;

  const RecentSearchModel({
    this.id,
    required this.keyword,
  });

  factory RecentSearchModel.fromJson(Map<String, dynamic> json) {
    return RecentSearchModel(
      id: json['id']?.toString(),
      keyword: (json['keyword'] ?? '').toString(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      if (id != null) 'id': id,
      'keyword': keyword,
    };
  }
}