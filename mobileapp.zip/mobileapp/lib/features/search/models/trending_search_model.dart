class TrendingSearchModel {
  final String keyword;

  const TrendingSearchModel({
    required this.keyword,
  });

  factory TrendingSearchModel.fromJson(dynamic json) {
    if (json is String) {
      return TrendingSearchModel(keyword: json);
    }

    if (json is Map) {
      return TrendingSearchModel(
        keyword: (json['keyword'] ?? json['name'] ?? '').toString(),
      );
    }

    return const TrendingSearchModel(keyword: '');
  }
}