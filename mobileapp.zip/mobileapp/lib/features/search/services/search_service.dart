import 'package:dio/dio.dart';

import '../../../api/api_service.dart';
import '../models/recent_search_model.dart';
import '../models/search_category_model.dart';
import '../models/search_response_model.dart';
import '../models/trending_search_model.dart';

class SearchService {
  SearchService._();

  static final SearchService instance = SearchService._();

  final Dio _dio = ApiService.instance.dio;

  // ============================================================
  // SEARCH
  // ============================================================

  Future<SearchResponseModel> search({
    required String query,
    String category = 'ALL',
    int page = 0,
    int size = 20,
  }) async {
    final response = await _dio.get(
      '/contentservice/api/v1/search',
      queryParameters: {
        'q': query,
        'category': category,
        'page': page,
        'size': size,
      },
    );

    _validateResponse(response);

    return SearchResponseModel.fromJson(
      Map<String, dynamic>.from(response.data),
    );
  }

  // ============================================================
  // TRENDING
  // ============================================================

  Future<List<TrendingSearchModel>> getTrending({
    int limit = 10,
  }) async {
    final response = await _dio.get(
      '/contentservice/api/v1/search/trending',
      queryParameters: {
        'limit': limit,
      },
    );

    _validateResponse(response);

    final body = Map<String, dynamic>.from(response.data);

    final data = body['data'];

    final dynamic items =
    data is Map ? data['items'] : data;

    if (items is! List) {
      return [];
    }

    return items
        .map(
          (item) => TrendingSearchModel.fromJson(item),
    )
        .where(
          (item) => item.keyword.trim().isNotEmpty,
    )
        .toList();
  }

  // ============================================================
  // CATEGORIES
  // ============================================================

  Future<List<SearchCategoryModel>> getCategories() async {
    final response = await _dio.get(
      '/contentservice/api/v1/search/categories',
    );

    _validateResponse(response);

    final body = Map<String, dynamic>.from(response.data);

    final data = body['data'];

    if (data is! List) {
      return [];
    }

    return data
        .whereType<Map>()
        .map(
          (item) => SearchCategoryModel.fromJson(
        Map<String, dynamic>.from(item),
      ),
    )
        .where(
          (item) => item.code.isNotEmpty,
    )
        .toList();
  }

  // ============================================================
  // RECENT SEARCHES
  // ============================================================

  Future<List<String>> getRecentSearches() async {
    final response = await _dio.get(
      '/contentservice/api/v1/search/recent',
    );

    final data = response.data;

    if (data is List) {
      return data
          .map((e) => e.toString())
          .toList();
    }

    return [];
  }

  // ============================================================
  // SAVE RECENT SEARCH
  // ============================================================

  Future<void> saveRecentSearch(
      String keyword,
      ) async {
    await _dio.post(
      '/contentservice/api/v1/search/recent',
      data: {
        'keyword': keyword,
      },
    );
  }

  // ============================================================
  // DELETE ONE RECENT SEARCH
  // ============================================================

  Future<void> deleteRecentSearch(
      String id,
      ) async {
    await _dio.delete(
      '/contentservice/api/v1/search/recent/$id',
    );
  }

  // ============================================================
  // CLEAR ALL RECENT SEARCHES
  // ============================================================

  Future<void> clearRecentSearches() async {
    await _dio.delete(
      '/contentservice/api/v1/search/recent',
    );
  }

  // ============================================================
  // RESPONSE VALIDATION
  // ============================================================

  void _validateResponse(Response response) {
    if (response.statusCode == null ||
        response.statusCode! < 200 ||
        response.statusCode! >= 300) {
      String message = 'Request failed';

      if (response.data is Map) {
        message =
            response.data['message']?.toString() ??
                message;
      }

      throw Exception(message);
    }
  }
}