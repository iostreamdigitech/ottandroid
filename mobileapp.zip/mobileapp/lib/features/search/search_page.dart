import 'dart:async';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/utils/device_utils.dart';
import '../../enum/MenuItemType.dart';
import '../../widgets/app_drawer.dart';
import '../../widgets/app_shell.dart';
import '../home/page/base_screen.dart';

import 'models/recent_search_model.dart';
import 'models/search_category_model.dart';
import 'models/search_result_model.dart';
import 'models/trending_search_model.dart';
import 'services/search_service.dart';

class SearchPage extends StatefulWidget {
  const SearchPage({super.key});

  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage>
    with SingleTickerProviderStateMixin {
  // ============================================================
  // CONTROLLERS
  // ============================================================

  late TabController _tabController;

  final TextEditingController _searchController =
  TextEditingController();

  final FocusNode _searchFocusNode =
  FocusNode();

  Timer? _debounce;

  // ============================================================
  // DATA
  // ============================================================

  List<SearchResultModel> _results = [];

  List<TrendingSearchModel> _trending = [];

  List<RecentSearchModel> _recent = [];

  List<SearchCategoryModel> _categories = [];

  // ============================================================
  // STATE
  // ============================================================

  bool _isLoading = false;
  bool _isLoadingTrending = false;
  bool _isLoadingRecent = false;
  bool _isLoadingCategories = false;

  String? _errorMessage;

  String _activeQuery = '';

  int _currentPage = 0;

  int _totalElements = 0;

  bool _hasNextPage = false;

  bool _showSuggestions = false;

  // ============================================================
  // DEFAULT CATEGORIES
  // ============================================================

  final List<SearchCategoryModel> _defaultCategories = const [
    SearchCategoryModel(
      code: 'ALL',
      name: 'All',
      icon: Icons.apps_rounded,
    ),
    SearchCategoryModel(
      code: 'MOVIE',
      name: 'Movies',
      icon: Icons.movie_creation_outlined,
    ),
    SearchCategoryModel(
      code: 'SERIES',
      name: 'Series',
      icon: Icons.live_tv_outlined,
    ),
    SearchCategoryModel(
      code: 'LIVE_TV',
      name: 'Live TV',
      icon: Icons.tv_outlined,
    ),
    SearchCategoryModel(
      code: 'SPORTS',
      name: 'Sports',
      icon: Icons.sports_cricket_outlined,
    ),
  ];

  // ============================================================
  // INIT
  // ============================================================

  @override
  void initState() {
    super.initState();

    _tabController = TabController(
      length: 5,
      vsync: this,
    );

    _tabController.addListener(
      _onTabChanged,
    );

    _loadInitialData();
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(BuildContext context) {
    return AppShell(
      activeMenu: MenuItemType.search,
      child: _buildScaffold(),
    );
  }

  Widget _buildScaffold() {
    final isDesktop =
    DeviceUtils.isDesktop(context);

    return Scaffold(
      backgroundColor:
      const Color(0xff020817),

      drawer:
      isDesktop
          ? const AppDrawer()
          : null,

      appBar: _buildAppBar(),

      body: SafeArea(
        child:
        isDesktop
            ? _buildDesktop()
            : _buildMobile(),
      ),
    );
  }

  // ============================================================
  // APP BAR
  // ============================================================

  PreferredSizeWidget _buildAppBar() {
    final isDesktop =
    DeviceUtils.isDesktop(context);

    final isTV =
    DeviceUtils.isTV(context);

    return AppBar(
      backgroundColor:
      const Color(0xff020817),

      elevation: 0,

      leading:
      (isDesktop || isTV)
          ? IconButton(
        icon: const Icon(
          Icons.arrow_back_ios_new_rounded,
          color: Colors.white,
        ),
        onPressed: () {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder:
                  (_) =>
              const BaseScreen(),
            ),
          );
        },
      )
          : null,

      titleSpacing:
      (isDesktop || isTV)
          ? 0
          : 16,

      title: const Text(
        'Search',
        style: TextStyle(
          color: Colors.white,
          fontSize: 26,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }

  // ============================================================
  // DESKTOP
  // ============================================================

  Widget _buildDesktop() {
    return Row(
      children: [
        SizedBox(
          width: 340,
          child: _buildDesktopSidebar(),
        ),

        Container(
          width: 1,
          color: Colors.white.withOpacity(.06),
        ),

        Expanded(
          child: _buildMainContent(),
        ),
      ],
    );
  }

  Widget _buildDesktopSidebar() {
    return Container(
      color: const Color(0xff061126),
      child: Column(
        children: [
          _buildSearchBar(),

          const SizedBox(height: 12),

          _buildSidebarTitle(
            'Trending Searches',
            Icons.local_fire_department_rounded,
          ),

          _buildTrendingList(),

          const SizedBox(height: 12),

          _buildSidebarTitle(
            'Recent Searches',
            Icons.history_rounded,
            action:
            _recent.isNotEmpty
                ? TextButton(
              onPressed:
              _clearRecent,
              child: const Text(
                'Clear',
                style: TextStyle(
                  color: Colors.redAccent,
                ),
              ),
            )
                : null,
          ),

          Expanded(
            child: _buildRecentList(),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // MOBILE
  // ============================================================

  Widget _buildMobile() {
    return Column(
      children: [
        _buildSearchBar(),

        _buildTrendingHorizontal(),

        _buildCategoryTabs(),

        Expanded(
          child: _buildMainContent(),
        ),
      ],
    );
  }

  // ============================================================
  // MAIN CONTENT
  // ============================================================

  Widget _buildMainContent() {
    return Column(
      children: [
        if (DeviceUtils.isDesktop(context))
          _buildCategoryTabs(),

        Expanded(
          child: _buildSearchBody(),
        ),
      ],
    );
  }

  // ============================================================
  // SEARCH BAR
  // ============================================================

  Widget _buildSearchBar() {
    final isTV =
    DeviceUtils.isTV(context);

    return Padding(
      padding: EdgeInsets.fromLTRB(
        DeviceUtils.horizontalPadding(context),
        isTV ? 24 : 16,
        DeviceUtils.horizontalPadding(context),
        12,
      ),
      child: Container(
        height: isTV ? 72 : 60,
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [
              Color(0xff182746),
              Color(0xff101a31),
            ],
          ),
          borderRadius:
          BorderRadius.circular(
            isTV ? 38 : 30,
          ),
          border: Border.all(
            color: Colors.white.withOpacity(.10),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(.20),
              blurRadius: 20,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: TextField(
          controller: _searchController,
          focusNode: _searchFocusNode,
          style: TextStyle(
            color: Colors.white,
            fontSize: isTV ? 21 : 16,
            fontWeight: FontWeight.w500,
          ),
          textInputAction:
          TextInputAction.search,
          onTap: () {
            setState(() {
              _showSuggestions = true;
            });
          },
          onChanged: _onSearchChanged,
          onSubmitted: (value) {
            final query =
            value.trim();

            if (query.isNotEmpty) {
              _performSearch(
                query,
                saveRecent: true,
              );
            }
          },
          decoration: InputDecoration(
            border: InputBorder.none,

            hintText:
            'Search movies, series, live TV, sports...',

            hintStyle: TextStyle(
              color: Colors.white38,
              fontSize: isTV ? 20 : 15,
            ),

            prefixIcon: Icon(
              Icons.search_rounded,
              color: Colors.white70,
              size: isTV ? 32 : 25,
            ),

            suffixIcon: Row(
              mainAxisSize:
              MainAxisSize.min,
              children: [
                if (_searchController
                    .text
                    .isNotEmpty)
                  IconButton(
                    icon: Icon(
                      Icons.close_rounded,
                      color:
                      Colors.white60,
                      size:
                      isTV ? 28 : 22,
                    ),
                    onPressed:
                    _clearSearch,
                  ),

                IconButton(
                  icon: Icon(
                    Icons.mic_none_rounded,
                    color:
                    Colors.white70,
                    size:
                    isTV ? 30 : 23,
                  ),
                  onPressed: () {
                    // TODO:
                    // Implement voice search.
                  },
                ),
              ],
            ),

            contentPadding:
            const EdgeInsets.symmetric(
              vertical: 18,
            ),
          ),
        ),
      ),
    );
  }

  // ============================================================
  // SEARCH INPUT
  // ============================================================

  void _onSearchChanged(
      String value,
      ) {
    setState(() {
      _showSuggestions =
          value.trim().isNotEmpty;
    });

    _debounce?.cancel();

    final query =
    value.trim();

    if (query.isEmpty) {
      setState(() {
        _results.clear();
        _activeQuery = '';
        _errorMessage = null;
      });

      return;
    }

    _debounce = Timer(
      const Duration(
        milliseconds: 450,
      ),
          () {
        _performSearch(query);
      },
    );
  }

  // ============================================================
  // TRENDING
  // ============================================================

  Widget _buildTrendingHorizontal() {
    if (_trending.isEmpty &&
        !_isLoadingTrending) {
      return const SizedBox.shrink();
    }

    return SizedBox(
      height: 58,
      child: ListView.separated(
        padding: EdgeInsets.symmetric(
          horizontal:
          DeviceUtils.horizontalPadding(
            context,
          ),
        ),
        scrollDirection:
        Axis.horizontal,
        itemCount:
        _trending.length,
        separatorBuilder:
            (_, __) =>
        const SizedBox(width: 10),
        itemBuilder:
            (_, index) =>
            _buildTrendingChip(
              _trending[index],
            ),
      ),
    );
  }

  Widget _buildTrendingList() {
    if (_isLoadingTrending) {
      return const Padding(
        padding: EdgeInsets.all(20),
        child: Center(
          child:
          CircularProgressIndicator(
            strokeWidth: 2,
            color: Colors.redAccent,
          ),
        ),
      );
    }

    if (_trending.isEmpty) {
      return const Padding(
        padding: EdgeInsets.all(20),
        child: Text(
          'No trending searches',
          style: TextStyle(
            color: Colors.white38,
          ),
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: 16,
      ),
      child: Wrap(
        spacing: 8,
        runSpacing: 8,
        children:
        _trending
            .map(
          _buildTrendingChip,
        )
            .toList(),
      ),
    );
  }

  Widget _buildTrendingChip(
      TrendingSearchModel item,
      ) {
    return InkWell(
      borderRadius:
      BorderRadius.circular(25),
      onTap: () {
        _searchController.text =
            item.keyword;

        _searchController.selection =
            TextSelection.fromPosition(
              TextPosition(
                offset:
                _searchController.text.length,
              ),
            );

        _performSearch(
          item.keyword,
          saveRecent: true,
        );
      },
      child: Container(
        padding:
        const EdgeInsets.symmetric(
          horizontal: 15,
          vertical: 10,
        ),
        decoration: BoxDecoration(
          color:
          const Color(0xff111d38),
          borderRadius:
          BorderRadius.circular(25),
          border: Border.all(
            color:
            Colors.white.withOpacity(.08),
          ),
        ),
        child: Row(
          mainAxisSize:
          MainAxisSize.min,
          children: [
            const Icon(
              Icons.local_fire_department_rounded,
              color: Colors.orangeAccent,
              size: 17,
            ),

            const SizedBox(width: 7),

            Text(
              item.keyword,
              style:
              const TextStyle(
                color: Colors.white,
                fontSize: 14,
                fontWeight:
                FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // CATEGORY TABS
  // ============================================================

  Widget _buildCategoryTabs() {
    final categories =
    _categories.isNotEmpty
        ? _categories
        : _defaultCategories;

    return SizedBox(
      height: 62,
      child: ListView.separated(
        padding: EdgeInsets.symmetric(
          horizontal:
          DeviceUtils.horizontalPadding(
            context,
          ),
        ),
        scrollDirection:
        Axis.horizontal,
        itemCount:
        categories.length,
        separatorBuilder:
            (_, __) =>
        const SizedBox(width: 10),
        itemBuilder:
            (context, index) {
          final selected =
              _tabController.index ==
                  index;

          return InkWell(
            borderRadius:
            BorderRadius.circular(30),
            onTap: () {
              _tabController.animateTo(
                index,
              );
            },
            child: AnimatedContainer(
              duration:
              const Duration(
                milliseconds: 220,
              ),
              padding:
              const EdgeInsets.symmetric(
                horizontal: 20,
                vertical: 11,
              ),
              decoration:
              BoxDecoration(
                gradient:
                selected
                    ? const LinearGradient(
                  colors: [
                    Color(0xffE50914),
                    Color(0xffB20710),
                  ],
                )
                    : null,
                color:
                selected
                    ? null
                    : const Color(
                  0xff111d38,
                ),
                borderRadius:
                BorderRadius.circular(
                  30,
                ),
                border: Border.all(
                  color:
                  selected
                      ? Colors.redAccent
                      : Colors.white
                      .withOpacity(.08),
                ),
              ),
              child: Row(
                mainAxisSize:
                MainAxisSize.min,
                children: [
                  Icon(
                    categories[index].icon,
                    color: Colors.white,
                    size: 18,
                  ),

                  const SizedBox(width: 8),

                  Text(
                    categories[index].name,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight:
                      selected
                          ? FontWeight.w800
                          : FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  // ============================================================
  // SEARCH BODY
  // ============================================================

  Widget _buildSearchBody() {
    return GestureDetector(
      onTap: () {
        if (_showSuggestions) {
          setState(() {
            _showSuggestions = false;
          });
        }
      },
      child: Stack(
        children: [
          _buildResultsBody(),

          if (_showSuggestions &&
              _searchController
                  .text
                  .trim()
                  .isNotEmpty)
            _buildSuggestionOverlay(),
        ],
      ),
    );
  }

  Widget _buildResultsBody() {
    if (_isLoading) {
      return _buildLoadingGrid();
    }

    if (_errorMessage != null) {
      return _buildErrorState();
    }

    if (_activeQuery.isEmpty) {
      return _buildInitialState();
    }

    if (_results.isEmpty) {
      return _buildNoResults();
    }

    return NotificationListener<
        ScrollNotification>(
      onNotification: (notification) {
        if (notification
        is ScrollEndNotification &&
            notification.metrics.pixels >=
                notification.metrics.maxScrollExtent -
                    300) {
          _loadNextPage();
        }

        return false;
      },
      child: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: _buildResultsHeader(),
          ),

          SliverPadding(
            padding:
            EdgeInsets.symmetric(
              horizontal:
              DeviceUtils.horizontalPadding(
                context,
              ),
              vertical: 8,
            ),
            sliver: SliverGrid(
              delegate:
              SliverChildBuilderDelegate(
                    (context, index) {
                  return _buildResultCard(
                    _results[index],
                  );
                },
                childCount:
                _results.length,
              ),
              gridDelegate:
              SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount:
                DeviceUtils.gridCount(
                  context,
                ),
                crossAxisSpacing: 14,
                mainAxisSpacing: 18,
                childAspectRatio:
                _gridAspectRatio(),
              ),
            ),
          ),

          if (_hasNextPage)
            const SliverToBoxAdapter(
              child: Padding(
                padding:
                EdgeInsets.all(24),
                child: Center(
                  child:
                  CircularProgressIndicator(
                    color:
                    Colors.redAccent,
                    strokeWidth: 2,
                  ),
                ),
              ),
            ),

          const SliverToBoxAdapter(
            child:
            SizedBox(height: 30),
          ),
        ],
      ),
    );
  }

  double _gridAspectRatio() {
    if (DeviceUtils.isTV(context)) {
      return .62;
    }

    if (DeviceUtils.isDesktop(context)) {
      return .68;
    }

    return .63;
  }

  // ============================================================
  // RESULTS HEADER
  // ============================================================

  Widget _buildResultsHeader() {
    return Padding(
      padding:
      EdgeInsets.fromLTRB(
        DeviceUtils.horizontalPadding(
          context,
        ),
        18,
        DeviceUtils.horizontalPadding(
          context,
        ),
        10,
      ),
      child: Row(
        children: [
          const Icon(
            Icons.search_rounded,
            color: Colors.white54,
            size: 21,
          ),

          const SizedBox(width: 8),

          Expanded(
            child: RichText(
              text: TextSpan(
                children: [
                  const TextSpan(
                    text:
                    'Results for ',
                    style: TextStyle(
                      color: Colors.white54,
                      fontSize: 16,
                    ),
                  ),
                  TextSpan(
                    text:
                    '"$_activeQuery"',
                    style:
                    const TextStyle(
                      color: Colors.white,
                      fontSize: 17,
                      fontWeight:
                      FontWeight.w800,
                    ),
                  ),
                ],
              ),
            ),
          ),

          if (_totalElements > 0)
            Text(
              '$_totalElements results',
              style:
              const TextStyle(
                color: Colors.white38,
                fontSize: 13,
              ),
            ),
        ],
      ),
    );
  }

  // ============================================================
  // RESULT CARD
  // ============================================================

  Widget _buildResultCard(
      SearchResultModel item,
      ) {
    final isTV =
    DeviceUtils.isTV(context);

    return InkWell(
      borderRadius:
      BorderRadius.circular(16),
      onTap: () {
        // TODO:
        // Navigate to content details page.
        //
        // Example:
        //
        // Navigator.push(
        //   context,
        //   MaterialPageRoute(
        //     builder: (_) => ContentDetailsPage(
        //       contentId: item.id,
        //     ),
        //   ),
        // );
      },
      child: Container(
        decoration: BoxDecoration(
          color:
          const Color(0xff101a31),
          borderRadius:
          BorderRadius.circular(16),
          border: Border.all(
            color:
            Colors.white.withOpacity(.07),
          ),
        ),
        clipBehavior:
        Clip.antiAlias,
        child: Column(
          crossAxisAlignment:
          CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Stack(
                children: [
                  Positioned.fill(
                    child:
                    _buildPoster(item),
                  ),



                  Positioned(
                    left: 10,
                    bottom: 10,
                    child:
                    _buildContentTypeBadge(
                      item.contentType,
                    ),
                  ),
                ],
              ),
            ),

            Padding(
              padding:
              const EdgeInsets.all(11),
              child: Column(
                crossAxisAlignment:
                CrossAxisAlignment.start,
                children: [
                  Text(
                    item.title.isEmpty
                        ? 'Untitled'
                        : item.title,
                    maxLines: 1,
                    overflow:
                    TextOverflow.ellipsis,
                    style:
                    TextStyle(
                      color: Colors.white,
                      fontSize:
                      isTV ? 18 : 15,
                      fontWeight:
                      FontWeight.w800,
                    ),
                  ),

                  const SizedBox(height: 6),

                  _buildMetadata(item),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPoster(SearchResultModel item) {
    final String platform;

    if (DeviceUtils.isTV(context)) {
      platform = 'TV';
    } else if (DeviceUtils.isDesktop(context)) {
      platform = 'WEB';
    } else {
      platform = 'MOBILE';
    }

    final String? imageUrl = item.getAssetUrl(
      assetType: 'POSTER',
      platform: platform,
    );

    if (imageUrl == null || imageUrl.isEmpty) {
      return _posterPlaceholder();
    }

    return Image.network(
      imageUrl,
      fit: BoxFit.cover,
      width: double.infinity,
      height: double.infinity,
      errorBuilder: (_, __, ___) {
        return _posterPlaceholder();
      },
      loadingBuilder: (
          context,
          child,
          progress,
          ) {
        if (progress == null) {
          return child;
        }

        return _posterPlaceholder(
          loading: true,
        );
      },
    );
  }
  Widget _posterPlaceholder({
    bool loading = false,
  }) {
    return Container(
      color: const Color(0xff17213a),
      child: Center(
        child:
        loading
            ? const SizedBox(
          width: 24,
          height: 24,
          child:
          CircularProgressIndicator(
            strokeWidth: 2,
            color:
            Colors.white38,
          ),
        )
            : const Icon(
          Icons.movie_outlined,
          color: Colors.white24,
          size: 42,
        ),
      ),
    );
  }


  Widget _buildContentTypeBadge(
      String type,
      ) {
    if (type.isEmpty) {
      return const SizedBox.shrink();
    }

    return Container(
      padding:
      const EdgeInsets.symmetric(
        horizontal: 8,
        vertical: 5,
      ),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(.72),
        borderRadius:
        BorderRadius.circular(6),
      ),
      child: Text(
        type.replaceAll('_', ' '),
        style: const TextStyle(
          color: Colors.white,
          fontSize: 9,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }

  Widget _buildMetadata(
      SearchResultModel item,
      ) {
    final values = <String>[
      if (item.releaseYear != null)
        item.releaseYear.toString(),

      if (item.rating != null &&
          item.rating!.isNotEmpty)
        item.rating!,

      if (item.language != null &&
          item.language!.isNotEmpty)
        item.language!,
    ];

    if (values.isEmpty) {
      return const SizedBox.shrink();
    }

    return Text(
      values.join(' • '),
      maxLines: 1,
      overflow:
      TextOverflow.ellipsis,
      style: TextStyle(
        color: Colors.white,
        fontSize: 12,
      ),
    );
  }

  // ============================================================
  // INITIAL STATE
  // ============================================================

  Widget _buildInitialState() {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(
        vertical: 60,
      ),
      child: Center(
        child: Column(
          children: [
            Container(
              width: 100,
              height: 100,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color:
                const Color(0xff101c36),
                border: Border.all(
                  color: Colors.white
                      .withOpacity(.06),
                ),
              ),
              child: const Icon(
                Icons.search_rounded,
                color: Colors.white24,
                size: 48,
              ),
            ),

            const SizedBox(height: 22),

            const Text(
              'Discover something great',
              style: TextStyle(
                color: Colors.white,
                fontSize: 21,
                fontWeight:
                FontWeight.w800,
              ),
            ),

            const SizedBox(height: 8),

            const Text(
              'Search for movies, series, live TV and sports',
              textAlign:
              TextAlign.center,
              style: TextStyle(
                color: Colors.white38,
                fontSize: 14,
              ),
            ),

            const SizedBox(height: 30),

            if (_recent.isNotEmpty)
              _buildRecentSection(),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // RECENT
  // ============================================================

  Widget _buildRecentSection() {
    return ConstrainedBox(
      constraints:
      const BoxConstraints(
        maxWidth: 700,
      ),
      child: Padding(
        padding:
        const EdgeInsets.symmetric(
          horizontal: 20,
        ),
        child: Column(
          crossAxisAlignment:
          CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(
                  Icons.history_rounded,
                  color: Colors.white54,
                  size: 20,
                ),

                const SizedBox(width: 8),

                const Expanded(
                  child: Text(
                    'Recent Searches',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 17,
                      fontWeight:
                      FontWeight.w700,
                    ),
                  ),
                ),

                TextButton(
                  onPressed:
                  _clearRecent,
                  child: const Text(
                    'Clear all',
                    style: TextStyle(
                      color:
                      Colors.redAccent,
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 8),

            ..._recent
                .take(5)
                .map(
              _buildRecentCard,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRecentList() {
    if (_isLoadingRecent) {
      return const Center(
        child:
        CircularProgressIndicator(
          strokeWidth: 2,
          color: Colors.redAccent,
        ),
      );
    }

    if (_recent.isEmpty) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(20),
          child: Text(
            'No recent searches',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white30,
            ),
          ),
        ),
      );
    }

    return ListView.separated(
      padding:
      const EdgeInsets.symmetric(
        horizontal: 16,
      ),
      itemCount: _recent.length,
      separatorBuilder:
          (_, __) =>
      const SizedBox(height: 8),
      itemBuilder:
          (_, index) =>
          _buildRecentCard(
            _recent[index],
          ),
    );
  }

  Widget _buildRecentCard(
      RecentSearchModel item,
      ) {
    return InkWell(
      borderRadius:
      BorderRadius.circular(12),
      onTap: () {
        _searchController.text =
            item.keyword;

        _performSearch(
          item.keyword,
          saveRecent: true,
        );
      },
      child: Container(
        padding:
        const EdgeInsets.symmetric(
          horizontal: 13,
          vertical: 11,
        ),
        decoration: BoxDecoration(
          color:
          const Color(0xff101a31),
          borderRadius:
          BorderRadius.circular(12),
          border: Border.all(
            color:
            Colors.white.withOpacity(.06),
          ),
        ),
        child: Row(
          children: [
            const Icon(
              Icons.history_rounded,
              color: Colors.white38,
              size: 19,
            ),

            const SizedBox(width: 12),

            Expanded(
              child: Text(
                item.keyword,
                maxLines: 1,
                overflow:
                TextOverflow.ellipsis,
                style:
                const TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight:
                  FontWeight.w500,
                ),
              ),
            ),

            IconButton(
              tooltip:
              'Search again',
              visualDensity:
              VisualDensity.compact,
              icon: const Icon(
                Icons.north_west_rounded,
                color: Colors.white38,
                size: 18,
              ),
              onPressed: () {
                _searchController.text =
                    item.keyword;

                _performSearch(
                  item.keyword,
                  saveRecent: true,
                );
              },
            ),

            IconButton(
              tooltip:
              'Remove',
              visualDensity:
              VisualDensity.compact,
              icon: const Icon(
                Icons.close_rounded,
                color: Colors.white24,
                size: 18,
              ),
              onPressed: () {
                _deleteRecent(item);
              },
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // SUGGESTIONS
  // ============================================================

  Widget _buildSuggestionOverlay() {
    final query =
    _searchController.text
        .trim()
        .toLowerCase();

    final suggestions =
    _trending
        .where(
          (item) => item.keyword
          .toLowerCase()
          .contains(query),
    )
        .take(5)
        .toList();

    if (suggestions.isEmpty) {
      return const SizedBox.shrink();
    }

    return Positioned(
      top: 4,
      left:
      DeviceUtils.horizontalPadding(
        context,
      ),
      right:
      DeviceUtils.horizontalPadding(
        context,
      ),
      child: Material(
        color: Colors.transparent,
        child: Container(
          decoration: BoxDecoration(
            color:
            const Color(0xff101a31),
            borderRadius:
            BorderRadius.circular(16),
            border: Border.all(
              color: Colors.white
                  .withOpacity(.08),
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black
                    .withOpacity(.35),
                blurRadius: 25,
              ),
            ],
          ),
          child: Column(
            children:
            suggestions
                .map(
                  (item) {
                return ListTile(
                  leading:
                  const Icon(
                    Icons.search_rounded,
                    color:
                    Colors.white38,
                  ),
                  title: Text(
                    item.keyword,
                    style:
                    const TextStyle(
                      color:
                      Colors.white,
                    ),
                  ),
                  onTap: () {
                    _searchController
                        .text =
                        item.keyword;

                    setState(() {
                      _showSuggestions =
                      false;
                    });

                    _performSearch(
                      item.keyword,
                      saveRecent:
                      true,
                    );
                  },
                );
              },
            )
                .toList(),
          ),
        ),
      ),
    );
  }

  // ============================================================
  // LOADING
  // ============================================================

  Widget _buildLoadingGrid() {
    return GridView.builder(
      padding: EdgeInsets.symmetric(
        horizontal:
        DeviceUtils.horizontalPadding(
          context,
        ),
        vertical: 20,
      ),
      itemCount: 10,
      gridDelegate:
      SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount:
        DeviceUtils.gridCount(
          context,
        ),
        crossAxisSpacing: 14,
        mainAxisSpacing: 18,
        childAspectRatio:
        _gridAspectRatio(),
      ),
      itemBuilder:
          (_, __) =>
          _buildSkeletonCard(),
    );
  }

  Widget _buildSkeletonCard() {
    return Container(
      decoration: BoxDecoration(
        color:
        const Color(0xff101a31),
        borderRadius:
        BorderRadius.circular(16),
      ),
      child: Column(
        children: [
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color:
                const Color(0xff17213a),
                borderRadius:
                BorderRadius.circular(16),
              ),
            ),
          ),

          Padding(
            padding:
            const EdgeInsets.all(11),
            child: Column(
              children: [
                Container(
                  height: 13,
                  decoration:
                  BoxDecoration(
                    color:
                    Colors.white
                        .withOpacity(.06),
                    borderRadius:
                    BorderRadius.circular(
                      5,
                    ),
                  ),
                ),

                const SizedBox(height: 8),

                Container(
                  height: 10,
                  width: 80,
                  alignment:
                  Alignment.centerLeft,
                  decoration:
                  BoxDecoration(
                    color:
                    Colors.white
                        .withOpacity(.04),
                    borderRadius:
                    BorderRadius.circular(
                      5,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // EMPTY
  // ============================================================

  Widget _buildNoResults() {
    return Center(
      child: Padding(
        padding:
        const EdgeInsets.all(30),
        child: Column(
          mainAxisSize:
          MainAxisSize.min,
          children: [
            const Icon(
              Icons.search_off_rounded,
              color: Colors.white24,
              size: 70,
            ),

            const SizedBox(height: 18),

            const Text(
              'No results found',
              style: TextStyle(
                color: Colors.white,
                fontSize: 21,
                fontWeight:
                FontWeight.w800,
              ),
            ),

            const SizedBox(height: 8),

            Text(
              'We could not find anything for "$_activeQuery"',
              textAlign:
              TextAlign.center,
              style: const TextStyle(
                color: Colors.white38,
                fontSize: 14,
              ),
            ),

            const SizedBox(height: 20),

            OutlinedButton.icon(
              onPressed: _clearSearch,
              icon: const Icon(
                Icons.refresh_rounded,
              ),
              label:
              const Text(
                'Try another search',
              ),
              style:
              OutlinedButton.styleFrom(
                foregroundColor:
                Colors.white,
                side: const BorderSide(
                  color: Colors.white24,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // ERROR
  // ============================================================

  Widget _buildErrorState() {
    return Center(
      child: Padding(
        padding:
        const EdgeInsets.all(30),
        child: Column(
          mainAxisSize:
          MainAxisSize.min,
          children: [
            const Icon(
              Icons.cloud_off_rounded,
              color: Colors.white24,
              size: 60,
            ),

            const SizedBox(height: 16),

            const Text(
              'Something went wrong',
              style: TextStyle(
                color: Colors.white,
                fontSize: 19,
                fontWeight:
                FontWeight.w700,
              ),
            ),

            const SizedBox(height: 8),

            Text(
              _errorMessage ??
                  'Unable to complete search',
              textAlign:
              TextAlign.center,
              style:
              const TextStyle(
                color: Colors.white38,
              ),
            ),

            const SizedBox(height: 20),

            ElevatedButton(
              onPressed: () {
                if (_activeQuery
                    .isNotEmpty) {
                  _performSearch(
                    _activeQuery,
                  );
                }
              },
              style:
              ElevatedButton.styleFrom(
                backgroundColor:
                Colors.redAccent,
                foregroundColor:
                Colors.white,
              ),
              child:
              const Text(
                'Retry',
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // SIDEBAR TITLE
  // ============================================================

  Widget _buildSidebarTitle(
      String title,
      IconData icon, {
        Widget? action,
      }) {
    return Padding(
      padding:
      const EdgeInsets.fromLTRB(
        16,
        12,
        12,
        10,
      ),
      child: Row(
        children: [
          Icon(
            icon,
            color: Colors.white54,
            size: 19,
          ),

          const SizedBox(width: 8),

          Expanded(
            child: Text(
              title,
              style:
              const TextStyle(
                color: Colors.white,
                fontSize: 15,
                fontWeight:
                FontWeight.w700,
              ),
            ),
          ),

          if (action != null)
            action,
        ],
      ),
    );
  }

  // ============================================================
  // API - INITIAL LOAD
  // ============================================================

  Future<void> _loadInitialData() async {
    setState(() {
      _categories =
      List<SearchCategoryModel>.from(
        _defaultCategories,
      );
    });

    await Future.wait([
      _loadTrending(),
      _loadRecent(),
      _loadCategories(),
    ]);
  }

  // ============================================================
  // API - TRENDING
  // ============================================================

  Future<void> _loadTrending() async {
    setState(() {
      _isLoadingTrending = true;
    });

    try {
      final values =
      await SearchService.instance
          .getTrending(
        limit: 10,
      );

      if (!mounted) return;

      setState(() {
        _trending = values;
      });
    } catch (_) {
      // Trending is optional.
    } finally {
      if (mounted) {
        setState(() {
          _isLoadingTrending =
          false;
        });
      }
    }
  }

  // ============================================================
  // API - RECENT
  // ============================================================

  Future<void> _loadRecent() async {
    setState(() {
      _isLoadingRecent = true;
    });

    try {
      final values =
      await SearchService.instance
          .getRecentSearches();

      if (!mounted) return;

      setState(() {
        _recent = values
            .take(10)
            .map(
              (keyword) => RecentSearchModel(
            keyword: keyword,
          ),
        )
            .toList();
      });

      await _saveLocalRecent(_recent);
    } catch (e) {
      debugPrint(
        'Recent search API error: $e',
      );

      await _loadLocalRecent();
    } finally {
      if (mounted) {
        setState(() {
          _isLoadingRecent = false;
        });
      }
    }
  }

  // ============================================================
  // API - CATEGORIES
  // ============================================================

  Future<void> _loadCategories() async {
    setState(() {
      _isLoadingCategories = true;
    });

    try {
      final values =
      await SearchService.instance
          .getCategories();

      if (!mounted) return;

      if (values.isNotEmpty) {
        final allExists =
        values.any(
              (item) =>
          item.code == 'ALL',
        );

        setState(() {
          _categories =
          allExists
              ? values
              : [
            _defaultCategories
                .first,
            ...values,
          ];
        });

        _resetTabController(
          _categories.length,
        );
      }
    } catch (_) {
      // Keep default categories.
    } finally {
      if (mounted) {
        setState(() {
          _isLoadingCategories =
          false;
        });
      }
    }
  }

  void _resetTabController(
      int length,
      ) {
    if (length == 0 ||
        length == _tabController.length) {
      return;
    }

    final oldIndex =
        _tabController.index;

    _tabController.removeListener(
      _onTabChanged,
    );

    _tabController.dispose();

    _tabController = TabController(
      length: length,
      vsync: this,
      initialIndex:
      oldIndex < length
          ? oldIndex
          : 0,
    );

    _tabController.addListener(
      _onTabChanged,
    );
  }

  // ============================================================
  // API - SEARCH
  // ============================================================

  Future<void> _performSearch(
      String query, {
        bool saveRecent = false,
      }) async {
    final keyword =
    query.trim();

    if (keyword.isEmpty) {
      return;
    }

    FocusScope.of(context).unfocus();

    setState(() {
      _showSuggestions = false;
      _isLoading = true;
      _errorMessage = null;
      _activeQuery = keyword;
      _currentPage = 0;
      _hasNextPage = false;
      _results.clear();
    });

    try {
      final response =
      await SearchService.instance
          .search(
        query: keyword,
        category: _categoryCode,
        page: 0,
        size: 20,
      );

      if (!mounted) return;

      setState(() {
        _results = response.contents;
        _currentPage =
            response.page;
        _totalElements =
            response.totalElements;
        _hasNextPage =
            response.hasNext;
      });

      if (saveRecent) {
        await _saveRecent(keyword);
      }
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _results.clear();
        _errorMessage =
            e.toString()
                .replaceFirst(
              'Exception: ',
              '',
            );
      });
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  // ============================================================
  // PAGINATION
  // ============================================================

  Future<void> _loadNextPage() async {
    if (_isLoading ||
        !_hasNextPage ||
        _activeQuery.trim().isEmpty) {
      return;
    }

    final nextPage = _currentPage + 1;

    setState(() {
      _isLoading = true;
    });

    try {
      final response =
      await SearchService.instance.search(
        query: _activeQuery,
        category: _categoryCode,
        page: nextPage,
        size: 20,
      );

      if (!mounted) return;

      setState(() {
        _results.addAll(response.contents);

        _currentPage = response.page;

        _totalElements = response.totalElements;

        _hasNextPage = response.hasNext;
      });
    } catch (e) {
      debugPrint(
        'Pagination error: $e',
      );
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  // ============================================================
  // RECENT SEARCH API
  // ============================================================

  Future<void> _saveRecent(
      String keyword,
      ) async {
    final normalized =
    keyword.trim();

    if (normalized.isEmpty) {
      return;
    }

    final existingIndex =
    _recent.indexWhere(
          (item) =>
      item.keyword.toLowerCase() ==
          normalized.toLowerCase(),
    );

    if (mounted) {
      setState(() {
        if (existingIndex >= 0) {
          _recent.removeAt(
            existingIndex,
          );
        }

        _recent.insert(
          0,
          RecentSearchModel(
            keyword: normalized,
          ),
        );

        if (_recent.length > 10) {
          _recent =
              _recent.take(10).toList();
        }
      });
    }

    await _saveLocalRecent(
      _recent,
    );

    try {
      await SearchService.instance
          .saveRecentSearch(
        normalized,
      );

      await _loadRecent();
    } catch (_) {
      // Local search remains available.
    }
  }

  Future<void> _deleteRecent(
      RecentSearchModel item,
      ) async {
    if (mounted) {
      setState(() {
        _recent.remove(item);
      });
    }

    await _saveLocalRecent(
      _recent,
    );

    if (item.id == null ||
        item.id!.isEmpty) {
      return;
    }

    try {
      await SearchService.instance
          .deleteRecentSearch(
        item.id!,
      );
    } catch (_) {
      // Local state already updated.
    }
  }

  Future<void> _clearRecent() async {
    setState(() {
      _recent.clear();
    });

    final prefs =
    await SharedPreferences
        .getInstance();

    await prefs.remove(
      'recent_searches',
    );

    try {
      await SearchService.instance
          .clearRecentSearches();
    } catch (_) {}
  }

  // ============================================================
  // LOCAL RECENT FALLBACK
  // ============================================================

  Future<void> _saveLocalRecent(
      List<RecentSearchModel> values,
      ) async {
    final prefs =
    await SharedPreferences
        .getInstance();

    await prefs.setStringList(
      'recent_searches',
      values
          .map(
            (item) => item.keyword,
      )
          .take(10)
          .toList(),
    );
  }

  Future<void> _loadLocalRecent() async {
    final prefs =
    await SharedPreferences
        .getInstance();

    final values =
        prefs.getStringList(
          'recent_searches',
        ) ??
            [];

    if (!mounted) return;

    setState(() {
      _recent =
          values
              .map(
                (keyword) =>
                RecentSearchModel(
                  keyword: keyword,
                ),
          )
              .take(10)
              .toList();
    });
  }

  // ============================================================
  // CATEGORY CODE
  // ============================================================

  String get _categoryCode {
    final categories =
    _categories.isNotEmpty
        ? _categories
        : _defaultCategories;

    final index =
        _tabController.index;

    if (index < 0 ||
        index >= categories.length) {
      return 'ALL';
    }

    return categories[index].code;
  }

  // ============================================================
  // TAB CHANGE
  // ============================================================

  void _onTabChanged() {
    if (_tabController
        .indexIsChanging) {
      return;
    }

    if (_activeQuery.isNotEmpty) {
      _performSearch(
        _activeQuery,
      );
    } else {
      setState(() {});
    }
  }

  // ============================================================
  // CLEAR SEARCH
  // ============================================================

  void _clearSearch() {
    _debounce?.cancel();

    _searchController.clear();

    setState(() {
      _activeQuery = '';
      _results.clear();
      _errorMessage = null;
      _showSuggestions = false;
      _totalElements = 0;
    });

    _searchFocusNode.requestFocus();
  }

  // ============================================================
  // DISPOSE
  // ============================================================

  @override
  void dispose() {
    _debounce?.cancel();

    _tabController.removeListener(
      _onTabChanged,
    );

    _tabController.dispose();

    _searchController.dispose();

    _searchFocusNode.dispose();

    super.dispose();
  }
}