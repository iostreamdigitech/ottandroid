import 'package:flutter/material.dart';

class FAQTile extends StatelessWidget {

  final String title;
  final String description;

  const FAQTile({
    super.key,
    required this.title,
    required this.description,
  });

  @override
  Widget build(BuildContext context) {

    return Card(

      margin: const EdgeInsets.only(bottom: 14),

      elevation: 1,

      child: ExpansionTile(

        iconColor: Colors.red,

        collapsedIconColor: Colors.grey,

        title: Text(
          title,
          style: const TextStyle(
            fontWeight: FontWeight.w600,
          ),
        ),

        children: [

          Padding(
            padding: const EdgeInsets.all(16),
            child: Text(description),
          )

        ],

      ),

    );
  }
}