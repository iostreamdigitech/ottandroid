import 'package:flutter/material.dart';

class HelpHeader extends StatelessWidget {

  const HelpHeader({super.key});

  @override
  Widget build(BuildContext context) {

    return Column(

      children: [

        Image.asset(
          "assets/logo.png",
          height: 90,
        ),

        const SizedBox(height: 25),

        const Text(
          "Help Center",
          style: TextStyle(
            fontSize: 34,
            fontWeight: FontWeight.bold,
          ),
        ),

        const SizedBox(height: 10),

        const Text(
          "Find answers to frequently asked questions",
          textAlign: TextAlign.center,
        ),

        const SizedBox(height: 40),

      ],

    );
  }
}