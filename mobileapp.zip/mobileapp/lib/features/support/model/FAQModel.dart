class FAQModel {
  final String title;
  final String description;

  FAQModel({
    required this.title,
    required this.description,
  });
}