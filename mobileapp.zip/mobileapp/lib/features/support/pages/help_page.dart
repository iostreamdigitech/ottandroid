import 'package:flutter/material.dart';

import '../model/FAQModel.dart';
import '../widgets/faq_tile.dart';
import '../widgets/help_header.dart';

class HelpPage extends StatelessWidget {

  const HelpPage({super.key});

  @override
  Widget build(BuildContext context) {
    final List<FAQModel> faqList = [

      FAQModel(
          title: "Account & Login",
          description:
          "Use your registered email or mobile number to sign in. If you forgot your password, tap Forgot Password."
      ),

      FAQModel(
          title: "Subscription",
          description:
          "You can subscribe monthly or yearly. Payments are automatically renewed."
      ),

      FAQModel(
          title: "Streaming Issues",
          description:
          "Check your internet connection. Restart the application and try again."
      ),

      FAQModel(
          title: "Supported Devices",
          description:
          "Android TV, Fire TV, Web Browser, Android, iPhone and Tablets."
      ),

      FAQModel(
          title: "Downloads",
          description:
          "Premium users can download content for offline viewing."
      ),

      FAQModel(
          title: "Parental Controls",
          description:
          "Enable PIN protection from Settings > Parental Control."
      ),

      FAQModel(
          title: "Contact Support",
          description:
          "Email: support@ott.com\nPhone: +91 9876543210"
      ),

    ];
    final width = MediaQuery.of(context).size.width;

    double contentWidth = width;

    if (width > 1500) {
      contentWidth = 900;
    } else if (width > 1000) {
      contentWidth = 850;
    } else if (width > 700) {
      contentWidth = 700;
    }

    return Scaffold(

      backgroundColor: const Color(0xff101010),

      appBar: AppBar(
        title: const Text("Help"),
      ),

      body: Center(

        child: SizedBox(

          width: contentWidth,

          child: ListView(

            padding: const EdgeInsets.all(30),

            children: [

              const HelpHeader(),

              ...faqList.map((faq) {

                return FAQTile(
                  title: faq.title,
                  description: faq.description,
                );

              }).toList(),

              const SizedBox(height: 40),

              const Center(
                child: Text(
                  "Version 1.0.0",
                  style: TextStyle(color: Colors.grey),
                ),
              ),

              const SizedBox(height: 20),

            ],

          ),

        ),

      ),

    );
  }
}