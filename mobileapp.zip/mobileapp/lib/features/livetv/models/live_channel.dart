class LiveChannel {

  final int id;
  final String channelName;
  final String channelNumber;
  final String category;
  final String language;
  final String logoUrl;
  final String bannerUrl;
  final String streamType;
  final String primaryUrl;
  final bool drmEnabled;
  final bool active;
  final bool featured;


  LiveChannel({
    required this.id,
    required this.channelName,
    required this.channelNumber,
    required this.category,
    required this.language,
    required this.logoUrl,
    required this.bannerUrl,
    required this.streamType,
    required this.primaryUrl,
    required this.drmEnabled,
    required this.active,
    required this.featured,
  });


  factory LiveChannel.fromJson(
      Map<String,dynamic> json){

    return LiveChannel(

      id: json["id"] ?? 0,

      channelName:
      json["channelName"] ?? "",

      channelNumber:
      json["channelNumber"] ?? "",

      category:
      json["category"] ?? "",

      language:
      json["language"] ?? "",

      logoUrl:
      json["logoUrl"] ?? "",

      bannerUrl:
      json["bannerUrl"] ?? "",

      streamType:
      json["streamType"] ?? "",

      primaryUrl:
      json["primaryUrl"] ?? "",

      drmEnabled:
      json["drmEnabled"] ?? false,

      active:
      json["active"] ?? false,

      featured:
      json["featured"] ?? false,

    );

  }


}