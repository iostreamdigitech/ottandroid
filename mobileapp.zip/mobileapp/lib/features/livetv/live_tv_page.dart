import 'package:flutter/material.dart';
import 'package:ottoneapp/features/home/page/base_screen.dart';
import 'package:ottoneapp/features/livetv/services/live_tv_service.dart';

import '../../core/utils/device_utils.dart';
import '../../enum/MenuItemType.dart';
import '../../widgets/app_drawer.dart';
import '../../widgets/app_shell.dart';
import 'models/live_channel.dart';

class LiveTvPage extends StatefulWidget {
  const LiveTvPage({super.key});

  @override
  State<LiveTvPage> createState() => _LiveTvPageState();
}

class _LiveTvPageState extends State<LiveTvPage> {
  int selectedCategory = 0;
  List<LiveChannel> channels=[];

  bool loading=true;

  String? error;

  final List<String> categories = [
    "All",
    "Entertainment",
    "News",
    "Sports",
    "Movies",
    "Kids",
    "Music",
  ];

  final LiveTvService service =
  LiveTvService();




  @override
  void initState(){

    super.initState();

    loadChannels();

  }


  Future<void> loadChannels() async{


    try{


      final data =
      await service.getChannels();


      setState((){

        channels=data;

        loading=false;

      });


    }
    catch(e){


      setState((){

        error=e.toString();

        loading=false;

      });


    }


  }
  @override
  Widget build(BuildContext context) {
    return AppShell(
      activeMenu: MenuItemType.liveTv,
      child: _buildScaffold(context),
    );
  }

  Widget _buildScaffold(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xff020B23),

      drawer: DeviceUtils.isDesktop(context) ? const AppDrawer() : null,

        appBar: AppBar(

          backgroundColor:
          const Color(0xff020B23),


          leading:

          (DeviceUtils.isDesktop(context)
              ||
              DeviceUtils.isTV(context))

              ?

          IconButton(

            icon:
            const Icon(
              Icons.arrow_back_ios_new,
              color:Colors.white,
            ),

            onPressed:(){

              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(
                  builder: (_) => const BaseScreen(),
                ),
                    (_) => false,
              );
// return BaseScreen

            },

          )

              :null,


          title:

          const Text(
            "Live TV",
            style:TextStyle(
                color:Colors.white,
                fontWeight:FontWeight.bold
            ),
          ),

        ),

      body:

      loading

          ?

      const Center(
        child:CircularProgressIndicator(),
      )


          :

      error!=null

          ?

      _centerMessage(
          "Unable to load channels"
      )


          :

      channels.isEmpty

          ?

      _centerMessage(
          "No Live Channels Available"
      )


          :

      _buildContent(),
    );
  }
  Widget _centerMessage(String text){

    return Center(

      child:

      Column(

        mainAxisAlignment:
        MainAxisAlignment.center,

        children:[


          const Icon(

            Icons.live_tv,

            color:Colors.white24,

            size:70,

          ),


          const SizedBox(height:15),


          Text(

            text,

            style:

            const TextStyle(

                color:Colors.white70,

                fontSize:20

            ),

          )


        ],

      ),

    );

  }
  Widget _buildContent(){


    return Column(

      children:[


        _buildCategory(),


        Expanded(

          child:

          GridView.builder(

            padding:
            EdgeInsets.all(
                DeviceUtils.horizontalPadding(context)
            ),


            itemCount:
            channels.length,


            gridDelegate:

            SliverGridDelegateWithFixedCrossAxisCount(

              crossAxisCount:
              DeviceUtils.liveChannelGrid(context),

              childAspectRatio:
              .80,

              crossAxisSpacing:15,

              mainAxisSpacing:15,

            ),



            itemBuilder:(context,index){

              return _channelCard(
                  channels[index]
              );

            },

          ),

        )


      ],

    );

  }

  Widget _buildCategory() {

    final bool isTV =
    DeviceUtils.isTV(context);

    final bool isDesktop =
    DeviceUtils.isDesktop(context);


    return SizedBox(

      height: isTV ? 70 : 55,


      child:

      isDesktop

          ?

      Wrap(

        spacing: 12,

        alignment:
        WrapAlignment.center,

        children:

        List.generate(
          categories.length,
              (index){

            return _categoryChip(
              categories[index],
              index,
              isTV,
            );

          },
        ),

      )


          :

      ListView.builder(

        padding: EdgeInsets.symmetric(

          horizontal:
          DeviceUtils.horizontalPadding(
              context),

        ),

        scrollDirection:
        Axis.horizontal,


        itemCount:
        categories.length,


        itemBuilder:
            (context,index){


          return _categoryChip(
            categories[index],
            index,
            isTV,
          );

        },

      ),

    );
  }

  Widget _categoryChip(
      String category,
      int index,
      bool isTV,
      ){

    final bool selected =
        selectedCategory == index;


    return GestureDetector(

      onTap: (){

        setState((){

          selectedCategory =
              index;

        });


        // TODO:
        // Filter API
        // loadChannels(category)

      },


      child:

      AnimatedContainer(

        duration:
        const Duration(
            milliseconds:250),


        margin:
        const EdgeInsets.only(
            right:12),


        padding:
        EdgeInsets.symmetric(

          horizontal:
          isTV ? 32 : 20,


          vertical:
          isTV ? 16 : 10,

        ),


        decoration:

        BoxDecoration(

          gradient:

          selected

              ?

          const LinearGradient(

            colors:[

              Color(0xffE50914),

              Color(0xffB20710),

            ],

          )


              :

          const LinearGradient(

            colors:[

              Color(0xff202B52),

              Color(0xff141E38),

            ],

          ),


          borderRadius:
          BorderRadius.circular(30),


          border:

          Border.all(

            color:

            selected

                ?

            Colors.redAccent

                :

            Colors.white12,

          ),


          boxShadow:

          selected

              ?

          [

            BoxShadow(

              color:
              Colors.red.withOpacity(.35),

              blurRadius:
              12,

            )

          ]

              :

          [],

        ),



        child:

        Row(

          mainAxisSize:
          MainAxisSize.min,


          children:[


            if(selected)

              Icon(

                Icons.check_circle,

                color:
                Colors.white,

                size:
                isTV ? 24 : 18,

              ),


            if(selected)

              const SizedBox(
                width:8,
              ),



            Text(

              category,


              style:

              TextStyle(

                color:
                Colors.white,


                fontSize:

                isTV
                    ? 22
                    : 15,


                fontWeight:

                selected

                    ?

                FontWeight.bold

                    :

                FontWeight.w500,

              ),

            ),

          ],

        ),

      ),

    );
  }
  Widget _channelCard(
      LiveChannel channel){


    return Container(

      decoration:

      BoxDecoration(

        color:
        const Color(0xff141E38),

        borderRadius:
        BorderRadius.circular(18),

      ),


      child:

      Column(

        children:[


          Expanded(

              child:

              Stack(

                children:[


                  ClipRRect(

                    borderRadius:
                    const BorderRadius.vertical(
                        top:Radius.circular(18)
                    ),

                    child:

                    Image.network(

                      channel.bannerUrl,

                      width:
                      double.infinity,

                      fit:
                      BoxFit.cover,

                    ),

                  ),



                  Positioned(

                    top:10,

                    left:10,

                    child:

                    Container(

                      padding:
                      const EdgeInsets.symmetric(
                          horizontal:10,
                          vertical:4
                      ),

                      decoration:

                      BoxDecoration(

                          color:Colors.red,

                          borderRadius:
                          BorderRadius.circular(10)

                      ),

                      child:

                      const Text(

                        "LIVE",

                        style:
                        TextStyle(
                            color:Colors.white,
                            fontWeight:FontWeight.bold
                        ),

                      ),

                    ),

                  )


                ],

              )

          ),



          Padding(

            padding:
            const EdgeInsets.all(12),


            child:

            Row(

              children:[


                CircleAvatar(

                  backgroundImage:
                  NetworkImage(
                      channel.logoUrl
                  ),

                ),


                const SizedBox(width:10),



                Expanded(

                  child:

                  Column(

                    crossAxisAlignment:
                    CrossAxisAlignment.start,

                    children:[


                      Text(

                        channel.channelName,

                        style:
                        const TextStyle(

                            color:Colors.white,

                            fontWeight:
                            FontWeight.bold

                        ),

                      ),


                      Text(

                        channel.language,

                        style:
                        const TextStyle(
                            color:Colors.white54
                        ),

                      )


                    ],

                  ),

                )


              ],

            ),

          )

        ],

      ),

    );

  }
}