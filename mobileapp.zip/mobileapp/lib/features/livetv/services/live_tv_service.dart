import '../models/live_channel.dart';


class LiveTvService {


  Future<List<LiveChannel>> getChannels() async {


    // TODO Replace with Dio/Retrofit API


    await Future.delayed(
        const Duration(seconds:1)
    );


    final response = {


      "success":true,


      "data":[

        {
          "id":1,
          "channelName":"Star Sports",
          "channelNumber":"101",
          "category":"Sports",
          "language":"English",
          "logoUrl":
          "https://picsum.photos/200",
          "bannerUrl":
          "https://picsum.photos/600/300",
          "streamType":"HLS",
          "primaryUrl":"sample.m3u8",
          "drmEnabled":false,
          "active":true,
          "featured":true
        },


        {
          "id":2,
          "channelName":"Asianet",
          "channelNumber":"102",
          "category":"Entertainment",
          "language":"Malayalam",
          "logoUrl":
          "https://picsum.photos/201",
          "bannerUrl":
          "https://picsum.photos/600/301",
          "streamType":"HLS",
          "primaryUrl":"sample.m3u8",
          "drmEnabled":false,
          "active":true,
          "featured":false
        }


      ]

    };


    return (response["data"] as List)
        .map(
            (e)=>
            LiveChannel.fromJson(e)
    )
        .toList();

  }

}