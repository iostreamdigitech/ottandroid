import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:ottoneapp/models/BannerModel.dart';

import '../models/Category.dart';
import '../models/movie.dart';
import '../repositories/movie_repository.dart';

class HomeController extends GetxController {
  final MovieRepository _repository;

  HomeController({MovieRepository? repository})
      : _repository = repository ?? MovieRepository();

  final RxBool isLoading = true.obs;
  final RxList<BannerModel> banners = <BannerModel>[].obs;
  final RxList<Movie> continueWatching = <Movie>[].obs;
  final RxList<Movie> trending = <Movie>[].obs;
  final RxList<Movie> newReleases = <Movie>[].obs;
  final RxList<String> genres = <String>[].obs;

  @override
  void onInit() {
    super.onInit();
    loadHome();
  }
  Future<List<Category>> getCategories() async{
    return _repository.getCategories();
  }

  Future<List<Movie>> getCategoryContent(String categoryId) {
    return _repository.getCategoryContent(categoryId);
  }
  Future<void> loadHome() async {
    isLoading.value = true;

    final results = await Future.wait([
      _repository.getBanners(),
      _repository.getContinueWatching(),
      _repository.getTrending(),
      _repository.getNewReleases(),
      _repository.getGenres(),
    ]);



    banners.assignAll(results[0] as List<BannerModel>);
    continueWatching.assignAll(results[1] as List<Movie>);
    trending.assignAll(results[2] as List<Movie>);
    newReleases.assignAll(results[3] as List<Movie>);
    genres.assignAll(results[4] as List<String>);
    debugPrint("Banner Count ss: ${banners.length}");

    isLoading.value = false;
  }
}
