
import 'package:ottoneapp/models/BannerModel.dart';


import '../../../services/movie_service.dart';
import '../models/movie.dart';
import '../models/Category.dart';

/// API-ready repository. Controllers should depend on this, never on
/// [MovieService] or [StubData] directly.
class MovieRepository {
  final MovieService _service;

  MovieRepository({MovieService? service}) : _service = service ?? MovieService();

  Future<List<Category>> getCategories() => _service.getCategories();
  Future<List<Movie>> getCategoryContent(String categoryId) {
    return _service.getCategoryContent(categoryId);
  }
  Future<List<BannerModel>> getBanners() => _service.fetchBanners();

  Future<List<Movie>> getContinueWatching() => _service.fetchContinueWatching();

  Future<List<Movie>> getTrending() => _service.fetchTrending();

  Future<List<Movie>> getNewReleases() => _service.fetchNewReleases();

  Future<List<String>> getGenres() => _service.fetchGenres();

  Future<List<Movie>> getMovies() => _service.fetchAllMovies();

  Future<Movie> getMovie(String id) => _service.fetchMovieById(id);
}
