import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class BackgroundDecoration extends StatelessWidget {
  const BackgroundDecoration();

  @override
  Widget build(BuildContext context) {
    return Positioned.fill(
      child: Stack(
        children: [

          /// Main Background
          Container(
            color: const Color(0xff020B23),
          ),

          /// Top Right Blue Glow
          Positioned(
            top: -180,
            right: -120,
            child: Container(
              width: 450,
              height: 450,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    const Color(0xff1D4ED8).withOpacity(.35),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),

          /// Left Purple Glow
          Positioned(
            left: -180,
            top: 250,
            child: Container(
              width: 420,
              height: 420,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    const Color(0xff6D4CFF).withOpacity(.18),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),

          /// Bottom Blue Glow
          Positioned(
            bottom: -220,
            right: -180,
            child: Container(
              width: 500,
              height: 500,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    const Color(0xff2563EB).withOpacity(.18),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}