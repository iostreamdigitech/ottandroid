class Movie {
  final int id;
  final String title;
  final String posterUrl;
  final String? bannerUrl;
  final String description;
  final String genre;
  final String year;
  final String duration;
  final double rating;
  final double? progress;
  final String videoUrl;

  const Movie({
    required this.id,
    required this.title,
    required this.posterUrl,
    this.bannerUrl,
    this.description = '',
    this.genre = '',
    this.year = '',
    this.duration = '',
    this.rating = 0.0,
    this.progress,
    required this.videoUrl,
  });

  // TODO: Replace with API call - map fields from the real backend movie response
  factory Movie.fromJson(Map<String, dynamic> json) {
    final List<dynamic> mediaAssets = json['mediaAssets'] ?? [];

    String? posterUrl;
    String? bannerUrl;

    for (final asset in mediaAssets) {
      switch (asset['assetType']) {
        case 'POSTER':
          posterUrl = asset['filePath'];
          break;
        case 'BANNER':
        case 'LANDSCAPE_BANNER':
          bannerUrl = asset['filePath'];
          break;
      }
    }

    return Movie(
      id: json['id'] as int,
      title: json['title'] ?? '',
      posterUrl: posterUrl ?? '',
      bannerUrl: bannerUrl,
      description: json['longDescription'] ?? '',
      genre: (json['genreNames'] as List?)?.join(', ') ?? '',
      year: json['releaseDate']?.toString().substring(0, 4) ?? '',
      duration: json['duration']?.toString() ?? '',
      rating: 0.0, // Your API returns "U", "UA", etc. Not numeric.
      progress: null,
      videoUrl: json['videoUrl'] ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'posterUrl': posterUrl,
      'bannerUrl': bannerUrl,
      'description': description,
      'genre': genre,
      'year': year,
      'duration': duration,
      'rating': rating,
      'progress': progress,
      'videoUrl': videoUrl,
    };
  }
}
