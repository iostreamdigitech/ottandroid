class Category {
  final int id;
  final String categoryName;
  final String categoryCode;
  final String description;
  final int parentCategoryId;
  final int displayOrder;
  final bool active;
  final String? regionCode;

  Category({
    required this.id,
    required this.categoryName,
    required this.categoryCode,
    required this.description,
    required this.parentCategoryId,
    required this.displayOrder,
    required this.active,
    this.regionCode,
  });

  factory Category.fromJson(Map<String, dynamic> json) {
    return Category(
      id: json["id"],
      categoryName: json["categoryName"] ?? "",
      categoryCode: json["categoryCode"] ?? "",
      description: json["description"] ?? "",
      parentCategoryId: json["parentCategoryId"] ?? 0,
      displayOrder: json["displayOrder"] ?? 0,
      active: json["active"] ?? false,
      regionCode: json["regionCode"],
    );
  }
}