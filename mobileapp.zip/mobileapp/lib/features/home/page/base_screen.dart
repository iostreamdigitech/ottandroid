import 'package:flutter/material.dart';
import 'package:ottoneapp/screens/downloads_page.dart';



import '../../../core/utils/device_utils.dart';
import '../../../enum/MenuItemType.dart';
import '../../../ui/ott_bottombar.dart';
import '../../../widgets/app_shell.dart';
import '../../livetv/live_tv_page.dart';
import '../../profile/page/profile_page.dart';
import '../../search/search_page.dart';
import 'ott_home_page.dart';

class BaseScreen extends StatefulWidget {
  const BaseScreen({super.key});

  @override
  State<BaseScreen> createState() => _BaseScreenState();
}

class _BaseScreenState extends State<BaseScreen> {

  int currentIndex = 0;

  final List<Widget> pages = [
    OTHomePage(),
    const SearchPage(),
    const LiveTvPage(),
    const DownloadsPage(),
    const ProfilePage(),
  ];

  @override
  Widget build(BuildContext context) {
    final bool isDesktop = DeviceUtils.isDesktop(context);

    return AppShell(
      activeMenu: MenuItemType.home,
      child: Scaffold(
        backgroundColor: const Color(0xff020B23),

        body: IndexedStack(
          index: currentIndex,
          children: pages,
        ),

        extendBody: true,

        bottomNavigationBar: isDesktop
            ? null
            : OTTBottomBar(
                currentIndex: currentIndex,
                onChanged: (index) {
                  setState(() {
                    currentIndex = index;
                  });
                },
              ),
      ),
    );
  }
}