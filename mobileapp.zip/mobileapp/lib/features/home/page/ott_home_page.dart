import 'package:flutter/foundation.dart' hide Category;
import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:get/get.dart';
import 'package:ottoneapp/features/home/models/movie.dart';
import 'package:ottoneapp/features/home/models/Category.dart';
import '../../../core/utils/app_navigator.dart';
import '../../../core/utils/device_utils.dart';
import '../../../screens/movie_detail.dart';

import '../../../widgets/app_drawer.dart';
import '../../../widgets/hero_banner.dart';
import '../../../widgets/movie_card_widget.dart';
import '../../../widgets/shimmer_placeholders.dart';
import '../../profile/page/profile_page.dart';
import '../../search/search_page.dart';
import '../controller/home_controller.dart';
import '../widgets/background_decoration.dart';

class OTHomePage extends StatelessWidget {
  OTHomePage({super.key});
  bool get isDesktop => kIsWeb;
  final HomeController controller = Get.put(HomeController());


  late bool isMobile =false;

  @override
  Widget build(BuildContext context) {



    final desktop = DeviceUtils.isDesktop(context);
    isMobile = MediaQuery.of(context).size.width < 600;
    final width = MediaQuery.of(context).size.width;

    final isTablet = width >= 600 && width < 1024;

    return Scaffold(
      backgroundColor: const Color(0xff020B23),
      drawer: desktop ? null : const AppDrawer(),
      appBar: desktop ? null : _buildAppBar(context),



        body: Stack(
          children: [

            if (!desktop) const BackgroundDecoration(),

            Positioned.fill(
              child: Obx(() {

                if (controller.isLoading.value) {
                  return _buildShimmer();
                }

                return _buildContent(context);

              }),
            ),
          ],
        ),
    );
  }

  Widget _buildShimmer() {
    return const SingleChildScrollView(
      child: Column(
        children: [
          ShimmerBannerCarousel(),
          SizedBox(height: 10),
          ShimmerMovieRow(),
          SizedBox(height: 10),
          ShimmerMovieRow(),
          SizedBox(height: 10),
          ShimmerGenreRow(),
          SizedBox(height: 10),
          ShimmerMovieRow(),
        ],
      ),
    );
  }
  Widget _buildCategoryRow(BuildContext context, Category category) {
    return FutureBuilder<List<Movie>>(
      future: controller.getCategoryContent(category.categoryCode),
      builder: (context, snapshot) {
        debugPrint("Category: ${category.categoryName}");
        debugPrint("State: ${snapshot.connectionState}");
        debugPrint("HasData: ${snapshot.hasData}");
        debugPrint("HasError: ${snapshot.hasError}");
        debugPrint("Error: ${snapshot.error}");
        final movies = snapshot.data ?? [];
        debugPrint(
            "Category: ${category.categoryName}, Movies: ${movies.length}");
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Padding(
            padding: EdgeInsets.symmetric(vertical: 16),
            child: ShimmerMovieRow(),
          );
        }

        if (snapshot.hasError) {
          return const SizedBox.shrink();
        }



        if (movies.isEmpty) {
          return const SizedBox.shrink();
        }

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            sectionTitle(category.categoryName),
            movieList(movies),
            const SizedBox(height: 24),
          ],
        );
      },
    );
  }

  Widget _buildGenreSection() {
    final genres = [
      "Action",
      "Drama",
      "Comedy",
      "Thriller",
      "Sci-Fi",
      "Romance",
      "Crime",
      "Adventure",
    ];

    return SizedBox(
      height: 55,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        scrollDirection: Axis.horizontal,
        itemCount: genres.length,
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (_, index) {
          return Container(
            padding: const EdgeInsets.symmetric(
              horizontal: 22,
              vertical: 12,
            ),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(30),
              color: Colors.white.withOpacity(.06),
              border: Border.all(
                color: Colors.white12,
              ),
            ),
            child: Center(
              child: Text(
                genres[index],
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          );
        },
      ),
    );
  }
  Widget _buildCategorySections() {
    return FutureBuilder<List<Category>>(
      future: controller.getCategories(),
      builder: (context, snapshot) {

        if (snapshot.connectionState != ConnectionState.done) {
          return const Column(
            children: [
              ShimmerMovieRow(),
              SizedBox(height: 20),
              ShimmerMovieRow(),
            ],
          );
        }

        if (snapshot.hasError) {
          return Center(
            child: Text(
              snapshot.error.toString(),
              style: const TextStyle(color: Colors.white),
            ),
          );
        }

        final categories = snapshot.data ?? [];

        return Column(
          children: categories.map((category) {
            return _buildCategoryRow(context,category);
          }).toList(),
        );
      },
    );
  }

  Widget _buildContent(BuildContext context) {

    return SingleChildScrollView(
        child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 1600),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [

          /// HERO BANNER
                  HeroBanner(
                    banners: controller.banners,
                  ),

                  const SizedBox(height: 30),

                  _buildGenreSection(),
                  const SizedBox(height: 30),
                  _buildCategorySections(),




                ],
              ),
            ),
        ),
    );
  }

  void _openDetail(BuildContext context, Movie movie) {
    AppNavigator.push(context, MovieDetailPage(movie: movie));
  }
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return AppBar(
      backgroundColor: const Color(0xff020B23),
      elevation: 0,
      toolbarHeight: 72,

      iconTheme: const IconThemeData(
        color: Colors.white,
        size: 28,
      ),

      titleSpacing: 0,

      title: Image.asset(
        "assets/splash_logo.png",
        height: 45,
        fit: BoxFit.contain,
      ),

      actions: [

        /// Cast
        IconButton(
          splashRadius: 22,
          icon: const Icon(
            Icons.cast_outlined,
            color: Colors.white,
            size: 26,
          ),
          onPressed: () {},
        ),

        /// Search
        IconButton(
          splashRadius: 22,
          icon: const Icon(
            Icons.search_rounded,
            color: Colors.white,
            size: 28,
          ),
          onPressed: () =>
              AppNavigator.push(context, const SearchPage()),
        ),

        /// Profile
        Padding(
          padding: const EdgeInsets.only(right: 16, left: 6),
          child: GestureDetector(
            onTap: () =>
                AppNavigator.push(context, const ProfilePage()),
            child: Stack(
              clipBehavior: Clip.none,
              children: [

                Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(.12),
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: Colors.white24,
                      width: 1,
                    ),
                  ),
                  child: const Icon(
                    Icons.person,
                    color: Colors.white70,
                    size: 24,
                  ),
                ),

                Positioned(
                  right: -1,
                  top: -1,
                  child: Container(
                    width: 11,
                    height: 11,
                    decoration: BoxDecoration(
                      color: Colors.redAccent,
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: const Color(0xff020B23),
                        width: 2,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
  Widget sectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(
          horizontal: 16, vertical: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 22,
              fontWeight: FontWeight.bold,
            ),
          ),
          const Text(
            "See All",
            style: TextStyle(
              color: Colors.white70,
            ),
          ),
        ],
      ),
    );
  }

  Widget movieList(List<Movie> items) {
    return SizedBox(
      height: 220,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: items.length,
        itemBuilder: (context, index) {
          final movie = items[index];
          return MovieCardWidget(
            movie: movie,
            onTap: () => _openDetail(context, movie),
          );
        },
      ),
    );
  }
}
