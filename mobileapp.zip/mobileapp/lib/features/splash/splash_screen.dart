import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:ottoneapp/auth/utils/auth_utils.dart';


import '../auth/page/login_screen.dart';
import '../home/page/base_screen.dart';




class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  static const FlutterSecureStorage _storage =
  FlutterSecureStorage();
  @override
  void initState() {
    super.initState();

    initializeApp();
  }

  Future<void> initializeApp() async {

    // Internet Check
    await Future.delayed(const Duration(seconds: 1));



    // Token Check
    bool isLoggedIn = AuthUtils.isLoggedIn(await _storage.read(key: "ott_token"));

    if (!mounted) return;

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) =>
        isLoggedIn
            ? const BaseScreen()
            : const LoginScreen(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xff121212),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(
              'assets/splash_logo.png',
              width: 180,
            ),
            const SizedBox(height: 30),
            const CircularProgressIndicator(),
          ],
        ),
      ),
    );
  }
}