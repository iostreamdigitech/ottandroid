import 'package:flutter/material.dart';


class LoginButton extends StatelessWidget {

  final bool loading;
  final VoidCallback onPressed;


  const LoginButton({

    super.key,

    required this.loading,

    required this.onPressed,

  });



  @override
  Widget build(BuildContext context) {


    return SizedBox(

      width: double.infinity,

      height: 52,


      child: AnimatedContainer(

        duration:
        const Duration(milliseconds:300),


        decoration: BoxDecoration(

          borderRadius:
          BorderRadius.circular(18),


          gradient: loading
              ? LinearGradient(
            colors: [
              Colors.grey.shade700,
              Colors.grey.shade600,
            ],
          )

              : const LinearGradient(

            begin:
            Alignment.topLeft,

            end:
            Alignment.bottomRight,

            colors: [

              Color(0xffE50914),

              Color(0xffB20710),

            ],

          ),

          boxShadow: loading
              ? []

              : [

            BoxShadow(

              color:
              Colors.redAccent
                  .withOpacity(.35),

              blurRadius:18,

              offset:
              const Offset(0,8),

            )

          ],


        ),


        child: ElevatedButton(

          onPressed:
          loading
              ? null
              : onPressed,


          style:
          ElevatedButton.styleFrom(

            backgroundColor:
            Colors.transparent,

            shadowColor:
            Colors.transparent,


            disabledBackgroundColor:
            Colors.transparent,


            shape:
            RoundedRectangleBorder(

              borderRadius:
              BorderRadius.circular(18),

            ),

          ),


          child:
          AnimatedSwitcher(

            duration:
            const Duration(
              milliseconds:250,
            ),


            child:
            loading

                ?

            const SizedBox(

              key:
              ValueKey(
                "loader",
              ),

              height:22,

              width:22,


              child:
              CircularProgressIndicator(

                strokeWidth:2.5,

                valueColor:
                AlwaysStoppedAnimation(
                  Colors.white,
                ),

              ),

            )


                :

            const Text(

              "LOGIN",

              key:
              ValueKey(
                "text",
              ),


              style:
              TextStyle(

                color:
                Colors.white,


                fontSize:
                16,


                fontWeight:
                FontWeight.w700,


                letterSpacing:
                1.2,

              ),

            ),

          ),

        ),

      ),

    );

  }

}