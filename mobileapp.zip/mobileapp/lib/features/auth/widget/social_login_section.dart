import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

import 'social_button.dart';


class SocialLoginSection extends StatelessWidget {


  final VoidCallback? onGoogle;

  final VoidCallback? onApple;

  final VoidCallback? onFacebook;


  const SocialLoginSection({

    super.key,

    this.onGoogle,

    this.onApple,

    this.onFacebook,

  });



  @override
  Widget build(BuildContext context) {


    final width =
        MediaQuery.of(context).size.width;


    final isMobile =
        width < 600;



    return Column(

      children: [


        const Text(

          "OR",

          style:
          TextStyle(

            color:
            Colors.white54,

            fontSize:13,

            fontWeight:
            FontWeight.w600,

          ),

        ),



        const SizedBox(
          height:18,
        ),




        if(isMobile)

          Row(

            children: [


              Expanded(child: SocialButton(

                title:
                "Google",

                icon:
                SvgPicture.asset(
                  "assets/google_svg.svg",
                  width: 24,
                  height: 24,
                ),

                onPressed:
                onGoogle ?? () {},

              )),



              const SizedBox(
                width:10,
              ),



              Expanded(child: SocialButton(

                title:
                "Apple",


                icon:
                SvgPicture.asset(
                "assets/apple.svg",
    width: 24,
    height: 24,
    ),

                onPressed:
                onApple ?? () {},

              )),



              const SizedBox(
                width:10,
              ),



              Expanded(child: SocialButton(

                title:
                "Facebook",

                icon:
                SvgPicture.asset(
                  "assets/fb_icon.svg",
                  width: 24,
                  height: 24,
                ),

                onPressed:
                onFacebook ?? () {},

              )),


            ],

          )



        else


          SizedBox(

            width:
            double.infinity,


            height:
            52,


            child:
            SocialButton(

              title:
              "Continue with Google",


              icon:
              SvgPicture.asset(
                "assets/google_svg.svg",
                width: 24,
                height: 24,
              ),


              onPressed:
              onGoogle ?? () {},

            ),

          ),



      ],

    );

  }

}