import 'dart:ui';

import 'package:flutter/material.dart';

import '../page/register_screen.dart';
import 'login_button.dart';
import 'remember_me.dart';
import 'social_login_section.dart';

class LoginCard extends StatefulWidget {
  final TextEditingController emailController;
  final TextEditingController passwordController;
  final GlobalKey<FormState> formKey;

  final String? Function(String?) emailValidator;
  final String? Function(String?) passwordValidator;

  final VoidCallback onLogin;
  final VoidCallback onGuestLogin;

  final bool isLoading;

  final bool rememberMe;
  final ValueChanged<bool?> onRememberChanged;

  final VoidCallback onForgotPassword;

  const LoginCard({
    super.key,
    required this.formKey,
    required this.emailController,
    required this.passwordController,
    required this.onLogin,
    required this.onGuestLogin,
    required this.isLoading,
    required this.rememberMe,
    required this.onRememberChanged,
    required this.onForgotPassword,
    required this.emailValidator,
    required this.passwordValidator,
  });

  @override
  State<LoginCard> createState() => _LoginCardState();
}

class _LoginCardState extends State<LoginCard> {
  bool obscurePassword = true;

  @override
  Widget build(BuildContext context) {
    final isMobile = MediaQuery.of(context).size.width < 600;

    return Center(
      child: Container(
        width: isMobile ? MediaQuery.of(context).size.width * .90 : 420,
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(.10),
          borderRadius: BorderRadius.circular(28),
          border: Border.all(
            color: Colors.white.withOpacity(.20),
          ),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(28),
          child: BackdropFilter(
            filter: ImageFilter.blur(
              sigmaX: 20,
              sigmaY: 20,
            ),
            child: Form(
              key: widget.formKey,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  /// Logo
                  SizedBox(
                    height: 70,
                    child: Image.asset(
                      "assets/splash_logo.png",
                      height: 70,
                    ),
                  ),

                  const SizedBox(height: 25),

                  /// Email
                  _inputField(
                    controller: widget.emailController,
                    hint: "Email / Mobile",
                    icon: Icons.person_outline,
                    validator: widget.emailValidator,
                    keyboardType: TextInputType.emailAddress,
                    autofillHints: const [
                      AutofillHints.username,
                      AutofillHints.email,
                    ],
                  ),

                  const SizedBox(height: 18),

                  /// Password
                  _inputField(
                    controller: widget.passwordController,
                    hint: "Password",
                    icon: Icons.lock_outline,
                    validator: widget.passwordValidator,
                    obscure: obscurePassword,
                    keyboardType: TextInputType.visiblePassword,
                    autofillHints: const [
                      AutofillHints.password,
                    ],
                    suffixIcon: IconButton(
                      icon: Icon(
                        obscurePassword
                            ? Icons.visibility_off_outlined
                            : Icons.visibility_outlined,
                        color: Colors.white70,
                      ),
                      onPressed: () {
                        setState(() {
                          obscurePassword = !obscurePassword;
                        });
                      },
                    ),
                  ),

                  const SizedBox(height: 15),

                  RememberMe(
                    value: widget.rememberMe,
                    onChanged: widget.onRememberChanged,
                    onForgotPassword: widget.onForgotPassword,
                  ),

                  const SizedBox(height: 25),

                  LoginButton(
                    loading: widget.isLoading,
                    onPressed: widget.onLogin,
                  ),

                  const SizedBox(height: 15),

                  const Divider(
                    color: Colors.white30,
                  ),

                  const SizedBox(height: 15),

                  const SocialLoginSection(),

                  const SizedBox(height: 25),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text(
                        "Don't have an account?",
                        style: TextStyle(
                          color: Colors.white70,
                        ),
                      ),
                      TextButton(
                        onPressed: () {
                          Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(
                              builder: (_) => const RegisterScreen(),
                            ),
                          );
                        },
                        child: const Text(
                          "Create Account",
                          style: TextStyle(
                            color: Color(0xFFFF1100),
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _inputField({
    required TextEditingController controller,
    required String hint,
    required IconData icon,
    String? Function(String?)? validator,
    bool obscure = false,
    TextInputType keyboardType = TextInputType.text,
    Iterable<String>? autofillHints,
    Widget? suffixIcon,
  }) {
    return TextFormField(
      controller: controller,
      validator: validator,
      obscureText: obscure,
      keyboardType: keyboardType,
      autofillHints: autofillHints,
      style: const TextStyle(
        color: Colors.white,
      ),
      decoration: InputDecoration(
        prefixIcon: Icon(
          icon,
          color: Colors.white70,
        ),
        suffixIcon: suffixIcon,
        hintText: hint,
        hintStyle: const TextStyle(
          color: Colors.white54,
        ),
        errorStyle: const TextStyle(
          color: Colors.redAccent,
        ),
        filled: true,
        fillColor: Colors.white.withOpacity(.08),
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 20,
          vertical: 18,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide(
            color: Colors.white.withOpacity(.10),
          ),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(
            color: Color(0xFFFF1100),
            width: 1.5,
          ),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(
            color: Colors.redAccent,
          ),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(
            color: Colors.redAccent,
            width: 1.5,
          ),
        ),
      ),
    );
  }
}