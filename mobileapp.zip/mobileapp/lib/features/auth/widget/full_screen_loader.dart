import 'dart:ui';

import 'package:flutter/material.dart';


class FullScreenLoader extends StatelessWidget {


  final bool visible;

  final String message;


  const FullScreenLoader({

    super.key,

    required this.visible,

    this.message = "Loading...",

  });



  @override
  Widget build(BuildContext context) {


    if (!visible) {

      return const SizedBox.shrink();

    }



    return Positioned.fill(


      child:
      BackdropFilter(


        filter:
        ImageFilter.blur(

          sigmaX:8,

          sigmaY:8,

        ),



        child:
        Container(


          color:
          Colors.black.withOpacity(.45),



          child:
          Center(



            child:
            Container(


              padding:
              const EdgeInsets.symmetric(

                horizontal:40,

                vertical:32,

              ),



              decoration:
              BoxDecoration(


                color:
                Colors.white.withOpacity(.12),



                borderRadius:
                BorderRadius.circular(24),



                border:
                Border.all(

                  color:
                  Colors.white.withOpacity(.25),

                ),



              ),



              child:
              ClipRRect(



                borderRadius:
                BorderRadius.circular(24),



                child:
                BackdropFilter(


                  filter:
                  ImageFilter.blur(

                    sigmaX:20,

                    sigmaY:20,

                  ),



                  child:
                  Column(


                    mainAxisSize:
                    MainAxisSize.min,



                    children: [



                      Container(


                        height:
                        55,


                        width:
                        55,



                        decoration:
                        const BoxDecoration(


                          shape:
                          BoxShape.circle,



                          gradient:
                          LinearGradient(


                            colors: [


                              Colors.redAccent,


                              Colors.deepPurple,


                            ],


                          ),


                        ),



                        child:
                        const Padding(


                          padding:
                          EdgeInsets.all(12),



                          child:
                          CircularProgressIndicator(


                            strokeWidth:
                            3,



                            valueColor:
                            AlwaysStoppedAnimation(

                              Colors.white,

                            ),


                          ),


                        ),



                      ),



                      const SizedBox(
                        height:20,
                      ),



                      Text(


                        message,


                        style:
                        const TextStyle(


                          color:
                          Colors.white,


                          fontSize:
                          16,


                          fontWeight:
                          FontWeight.w600,


                        ),


                      ),



                    ],


                  ),

                ),

              ),

            ),


          ),


        ),


      ),


    );

  }

}