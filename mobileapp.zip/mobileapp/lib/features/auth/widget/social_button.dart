import 'package:flutter/material.dart';


class SocialButton extends StatelessWidget {

  final String title;

  final Widget icon;

  final VoidCallback onPressed;

  final bool loading;


  const SocialButton({

    super.key,

    required this.title,

    required this.icon,

    required this.onPressed,

    this.loading = false,

  });



  @override
  Widget build(BuildContext context) {


    return AnimatedContainer(

        duration:
        const Duration(
          milliseconds:250,
        ),


        height:48,


        decoration:
        BoxDecoration(

          color:
          Colors.white.withOpacity(.10),


          borderRadius:
          BorderRadius.circular(14),


          border:
          Border.all(

            color:
            Colors.white.withOpacity(.20),

          ),

        ),


        child:
        Material(

          color:
          Colors.transparent,


          child:
          InkWell(

            borderRadius:
            BorderRadius.circular(14),


            onTap:
            loading
                ? null
                : onPressed,


            child:
            Center(

              child:
              AnimatedSwitcher(

                duration:
                const Duration(
                  milliseconds:200,
                ),


                child:

                loading

                    ?

                const SizedBox(

                  key:
                  ValueKey(
                    "loader",
                  ),

                  height:18,

                  width:18,


                  child:
                  CircularProgressIndicator(

                    strokeWidth:2,

                    valueColor:
                    AlwaysStoppedAnimation(
                      Colors.white,
                    ),

                  ),

                )


                    :

                Row(

                  key:
                  const ValueKey(
                    "content",
                  ),


                  mainAxisAlignment:
                  MainAxisAlignment.center,


                  children: [


                    SizedBox(

                      height:22,

                      width:22,

                      child: icon,

                    ),


                    const SizedBox(
                      width:8,
                    ),


                    Text(

                      title,


                      style:
                      const TextStyle(

                        color:
                        Colors.white,

                        fontSize:13,

                        fontWeight:
                        FontWeight.w600,

                      ),

                    ),

                  ],

                ),

              ),

            ),

          ),

        ),

    );

  }

}