import 'package:flutter/material.dart';


class RememberMe extends StatelessWidget {

  final bool value;

  final ValueChanged<bool?> onChanged;

  final VoidCallback onForgotPassword;


  const RememberMe({

    super.key,

    required this.value,

    required this.onChanged,

    required this.onForgotPassword,

  });



  @override
  Widget build(BuildContext context) {


    return Row(

      mainAxisAlignment:
      MainAxisAlignment.spaceBetween,


      children: [


        InkWell(

          onTap: () {

            onChanged(!value);

          },


          borderRadius:
          BorderRadius.circular(8),


          child: Row(

            children: [


              AnimatedContainer(

                duration:
                const Duration(
                  milliseconds:200,
                ),


                height:20,

                width:20,


                decoration:
                BoxDecoration(

                  color: value
                      ? Colors.redAccent
                      : Colors.transparent,


                  borderRadius:
                  BorderRadius.circular(5),


                  border: Border.all(

                    color:
                    value

                        ? Colors.redAccent

                        : Colors.white54,

                    width:1.5,

                  ),

                ),



                child:
                value

                    ?

                const Icon(

                  Icons.check,

                  size:15,

                  color:
                  Colors.white,

                )

                    :

                null,


              ),



              const SizedBox(
                width:8,
              ),



              const Text(

                "Remember Me",

                style:
                TextStyle(

                  color:
                  Colors.white70,

                  fontSize:14,

                ),

              ),


            ],

          ),

        ),





        GestureDetector(

          onTap:
          onForgotPassword,


          child:
          const Text(

            "Forgot Password?",


            style:
            TextStyle(

              color:
              Colors.redAccent,

              fontSize:14,


              fontWeight:
              FontWeight.w600,

            ),

          ),

        ),


      ],

    );

  }

}