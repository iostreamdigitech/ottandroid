import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class MpinSetupScreen extends StatefulWidget {
  const MpinSetupScreen({super.key});

  @override
  State<MpinSetupScreen> createState() => _MpinSetupScreenState();
}

class _MpinSetupScreenState extends State<MpinSetupScreen> {

  String pin = "";

  bool confirmMode = false;

  String firstPin = "";

  bool loading = false;

  void onNumberTap(String number) {

    HapticFeedback.lightImpact();

    if (pin.length == 4) return;

    setState(() {

      pin += number;

    });

    if (pin.length == 4) {

      Future.delayed(const Duration(milliseconds: 150), () async {

        if (!confirmMode) {

          firstPin = pin;

          pin = "";

          confirmMode = true;

          setState(() {});

        } else {
          if (firstPin == pin) {
            setState(() {
              loading = true;
            });

            try {
              // ==========================================
              // TODO:
              // Encrypt/Hash MPIN before sending
              //
              // final hashedPin = await SecurityUtil.hashPin(pin);
              //
              // await AuthService.saveMpin(
              //    mpin: hashedPin,
              // );
              //
              // Store local flag only
              // (Do NOT store plain MPIN)
              // ==========================================

              await Future.delayed(
                const Duration(seconds: 2),
              );

              if (!mounted) return;

              setState(() {
                loading = false;
              });

              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text(
                    "MPIN Created Successfully",
                  ),
                ),
              );

              // Navigate to Biometric Screen

              // Navigator.pushReplacement(
              //   context,
              //   MaterialPageRoute(
              //     builder: (_) =>
              //         const BiometricSetupScreen(),
              //   ),
              // );

              Navigator.pop(context);
            } catch (e) {
              setState(() {
                loading = false;
              });

              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(e.toString()),
                ),
              );
            }
          } else {
            HapticFeedback.heavyImpact();

            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                backgroundColor: Colors.red,
                content: Text(
                  "MPIN doesn't match",
                ),
              ),
            );

            setState(() {
              confirmMode = false;
              firstPin = "";
              pin = "";
            });
          }
        }

      });

    }

  }

  void deleteNumber() {

    if (pin.isEmpty) return;

    HapticFeedback.selectionClick();

    setState(() {

      pin = pin.substring(0, pin.length - 1);

    });

  }

  @override
  Widget build(BuildContext context) {

    final width = MediaQuery.of(context).size.width;

    final cardWidth = width > 450 ? 420.0 : width * .92;

    return Scaffold(

      body: Stack(

        children: [

          Positioned.fill(

            child: Image.asset(

              "assets/bg_login.png",

              fit: BoxFit.cover,

            ),

          ),

          Positioned.fill(

            child: Container(

              decoration: BoxDecoration(

                gradient: LinearGradient(

                  begin: Alignment.topCenter,

                  end: Alignment.bottomCenter,

                  colors: [

                    Colors.black.withOpacity(.30),

                    Colors.black.withOpacity(.70),

                    Colors.black.withOpacity(.95),

                  ],

                ),

              ),

            ),

          ),

          SafeArea(

            child: Center(

              child: ClipRRect(

                borderRadius: BorderRadius.circular(30),

                child: BackdropFilter(

                  filter: ImageFilter.blur(

                    sigmaX: 12,

                    sigmaY: 12,

                  ),

                  child: Container(

                    width: cardWidth,

                    padding: const EdgeInsets.all(25),

                    decoration: BoxDecoration(

                      color: Colors.black.withOpacity(.45),

                      borderRadius: BorderRadius.circular(30),

                      border: Border.all(

                        color: Colors.white12,

                      ),

                    ),

                    child: Column(

                      mainAxisSize: MainAxisSize.min,

                      children: [

                        Image.asset(

                          "assets/splash_logo.png",

                          height: 80,

                        ),

                        const SizedBox(height: 25),

                        Text(

                          confirmMode

                              ? "Confirm MPIN"

                              : "Create MPIN",

                          style: const TextStyle(

                            color: Colors.white,

                            fontSize: 28,

                            fontWeight: FontWeight.bold,

                          ),

                        ),

                        const SizedBox(height: 10),

                        Text(

                          confirmMode

                              ? "Re-enter your MPIN"

                              : "Enter a secure 4-digit MPIN",

                          style: const TextStyle(

                            color: Colors.white70,

                          ),

                        ),

                        const SizedBox(height: 40),

                        Row(

                          mainAxisAlignment:

                          MainAxisAlignment.center,

                          children: List.generate(

                            4,

                                (index) {

                              final filled =

                                  index < pin.length;

                              return AnimatedContainer(

                                duration:

                                const Duration(

                                    milliseconds: 200),

                                margin:

                                const EdgeInsets.all(10),

                                width: 20,

                                height: 20,

                                decoration: BoxDecoration(

                                  color: filled

                                      ? const Color(

                                      0xFFE50914)

                                      : Colors.white24,

                                  shape: BoxShape.circle,

                                ),

                              );

                            },

                          ),

                        ),

                        const SizedBox(height: 40),

                        buildKeypad(),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget buildKeypad() {

    return Column(

      children: [

        buildRow(["1", "2", "3"]),

        buildRow(["4", "5", "6"]),

        buildRow(["7", "8", "9"]),

        Row(

          mainAxisAlignment:

          MainAxisAlignment.spaceEvenly,

          children: [

            const SizedBox(width: 80),

            numberButton("0"),

            IconButton(

              onPressed: deleteNumber,

              icon: const Icon(

                Icons.backspace_outlined,

                color: Colors.white,

                size: 28,

              ),

            ),

          ],

        ),

      ],

    );

  }

  Widget buildRow(List<String> numbers) {

    return Padding(

      padding: const EdgeInsets.only(bottom: 15),

      child: Row(

        mainAxisAlignment:

        MainAxisAlignment.spaceEvenly,

        children:

        numbers.map(numberButton).toList(),

      ),

    );

  }

  Widget numberButton(String number) {

    return InkWell(

      borderRadius:

      BorderRadius.circular(50),

      onTap: () => onNumberTap(number),

      child: Container(

        width: 72,

        height: 72,

        decoration: BoxDecoration(

          color: Colors.white10,

          borderRadius:

          BorderRadius.circular(40),

        ),

        child: Center(

          child: Text(

            number,

            style: const TextStyle(

              color: Colors.white,

              fontSize: 28,

              fontWeight: FontWeight.bold,

            ),

          ),

        ),

      ),

    );

  }
}