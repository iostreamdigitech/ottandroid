import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:ottoneapp/features/auth/page/register_screen.dart';


import 'package:ottoneapp/widgets/custom_field.dart';

import '../../../api/auth_service.dart';
import '../../../auth/service/google_auth_service.dart';
import '../../../widgets/field_decoration.dart';
import '../../home/page/base_screen.dart';
import 'otp_verification_screen.dart';


class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginPage> {

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  final GoogleAuthService _googleAuthService =
  GoogleAuthService();

  final TextEditingController emailController =
  TextEditingController();

  final TextEditingController passwordController =
  TextEditingController();

  bool loading = false;
  bool obscurePassword = true;
  bool rememberMe = true;

  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  bool get isEmail {
    return emailController.text.contains("@");
  }

  String? validateEmailOrMobile(String? value) {
    if (value == null || value.trim().isEmpty) {
      return "Email or Mobile Number is required";
    }

    final input = value.trim();

    if (input.contains("@")) {
      final emailRegex = RegExp(
        r'^[\w\-.]+@([\w\-]+\.)+[\w\-]{2,4}$',
      );

      if (!emailRegex.hasMatch(input)) {
        return "Please enter a valid email";
      }
    } else {
      if (!RegExp(r'^[0-9]{10}$').hasMatch(input)) {
        return "Please enter a valid mobile number";
      }
    }

    return null;
  }

  String? validatePassword(String? value) {

    if (value == null || value.isEmpty) {
      return "Password is required";
    }

    if (value.length < 6) {
      return "Password must contain at least 6 characters";
    }

    return null;
  }

  void showMessage(
      String message, {
        bool success = false,
      }) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        behavior: SnackBarBehavior.floating,
        backgroundColor:
        success ? Colors.green : Colors.red,
        content: Text(message),
      ),
    );
  }

  Future<void> login() async {

    FocusScope.of(context).unfocus();

    if (!_formKey.currentState!.validate()) {
      return;
    }

    setState(() {
      loading = true;
    });

    try {

      final result =
      await AuthService.instance.login({
        "email": emailController.text.trim(),
        "password": passwordController.text,
      });

      if (!mounted) return;

      if (result["twoFaRequired"] == true) {

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => OtpVerificationScreen(
              userId: result["userId"],
              email: emailController.text.trim(),
              maskedEmail: result["maskedEmail"],
              maskedMobile: result["maskedMobile"],
              otpExpiresInSeconds:
              result["otpExpiresInSeconds"] ?? 600,
              purpose: "LOGIN",
            ),
          ),
        );
      } else if (result["token"] != null) {

        showMessage(
          "Login Successful",
          success: true,
        );

        Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(
            builder: (_) => const BaseScreen(),
          ),
              (route) => false,
        );
      } else {

        showMessage(
          result["message"] ??
              "Invalid email or password",
        );
      }
    } catch (e) {

      showMessage(e.toString());

    } finally {

      if (mounted) {
        setState(() {
          loading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {    final size = MediaQuery.of(context).size;

  final cardWidth =
  size.width > 450 ? 420.0 : size.width * .92;

  return Scaffold(
    body: Stack(
      children: [

        /// Background
        Positioned.fill(
          child: Image.asset(
            "assets/bg_login.png",
            fit: BoxFit.cover,
          ),
        ),

        /// Dark Overlay
        Positioned.fill(
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.black.withOpacity(.35),
                  Colors.black.withOpacity(.75),
                  Colors.black.withOpacity(.95),
                ],
              ),
            ),
          ),
        ),

        SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding:
              const EdgeInsets.all(12),
              child: Container(
                width: cardWidth,
                padding:
                const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color:
                  Colors.black.withOpacity(.55),
                  borderRadius:
                  BorderRadius.circular(28),
                  border: Border.all(
                    color: Colors.white
                        .withOpacity(.08),
                  ),
                ),

                child: Form(
                  key: _formKey,

                  child: Column(
                    mainAxisSize:
                    MainAxisSize.min,
                    children: [

                      const SizedBox(
                          height: 8),

                      Image.asset(
                        "assets/splash_logo.png",
                        height: 70,
                      ),

                      const SizedBox(
                          height: 20),

                      const Text(
                        "Sign in to continue",
                        style: TextStyle(
                          color:
                          Colors.white70,
                          fontSize: 15,
                        ),
                      ),

                      const SizedBox(
                          height: 25),

                      CustomField(
                        controller:
                        emailController,
                        hint:
                        "Email or Mobile Number",
                        icon: Icons
                            .person_outline,
                        validator:
                        validateEmailOrMobile,
                      ),

                      const SizedBox(
                          height: 16),

                      TextFormField(
                        controller:
                        passwordController,
                        obscureText:
                        obscurePassword,
                        validator:
                        validatePassword,
                        style:
                        const TextStyle(
                          color:
                          Colors.white,
                        ),
                        decoration:
                        fieldDecoration(
                          "Password",
                          Icons
                              .lock_outline,
                        ).copyWith(
                          suffixIcon:
                          IconButton(
                            onPressed: () {
                              setState(() {
                                obscurePassword =
                                !obscurePassword;
                              });
                            },
                            icon: Icon(
                              obscurePassword
                                  ? Icons
                                  .visibility_off
                                  : Icons
                                  .visibility,
                              color: Colors
                                  .white70,
                            ),
                          ),
                        ),
                      ),

                      const SizedBox(
                          height: 14),

                      Row(
                        children: [

                          Checkbox(
                            value:
                            rememberMe,
                            activeColor:
                            const Color(
                                0xFFFF1100),
                            onChanged:
                                (value) {
                              setState(() {
                                rememberMe =
                                    value ??
                                        false;
                              });
                            },
                          ),

                          const Text(
                            "Remember Me",
                            style:
                            TextStyle(
                              color: Colors
                                  .white,
                            ),
                          ),

                          const Spacer(),

                          TextButton(
                            onPressed: () {},

                            child:
                            const Text(
                              "Forgot Password?",
                              style:
                              TextStyle(
                                color: Color(
                                    0xFFFF1100),
                              ),
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(
                          height: 20),

                      SizedBox(
                        width:
                        double.infinity,
                        height: 58,

                        child:
                        DecoratedBox(
                          decoration:
                          BoxDecoration(
                            borderRadius:
                            BorderRadius
                                .circular(
                                16),
                            gradient:
                            const LinearGradient(
                              colors: [
                                Color(
                                    0xFFFF1100),
                                Color(
                                    0xFFFF1100),
                              ],
                            ),
                          ),

                          child:
                          ElevatedButton(
                            onPressed:
                            loading
                                ? null
                                : login,

                            style:
                            ElevatedButton
                                .styleFrom(
                              backgroundColor:
                              Colors
                                  .transparent,
                              shadowColor:
                              Colors
                                  .transparent,
                            ),

                            child:
                            loading
                                ? const SizedBox(
                              width:
                              24,
                              height:
                              24,
                              child:
                              CircularProgressIndicator(
                                strokeWidth:
                                2.5,
                                valueColor:
                                AlwaysStoppedAnimation(
                                  Colors
                                      .white,
                                ),
                              ),
                            )
                                : const Text(
                              "LOGIN",
                              style:
                              TextStyle(
                                color:
                                Colors.white,
                                fontSize:
                                18,
                              ),
                            ),
                          ),
                        ),
                      ),

                      const SizedBox(
                          height: 12),

                      TextButton(
                        onPressed: () {
                          Navigator.pushAndRemoveUntil(
                            context,
                            MaterialPageRoute(
                              builder: (_) =>
                              const BaseScreen(),
                            ),
                                (route) =>
                            false,
                          );
                        },
                        child:
                        const Text(
                          "Continue as Guest",
                          style:
                          TextStyle(
                            color: Colors
                                .white70,
                          ),
                        ),
                      ),

                      const SizedBox(
                          height: 20),

                      Row(
                        children: const [

                          Expanded(
                            child:
                            Divider(),
                          ),

                          Padding(
                            padding:
                            EdgeInsets.symmetric(
                                horizontal:
                                10),
                            child: Text(
                              "OR",
                              style:
                              TextStyle(
                                color: Colors
                                    .white70,
                              ),
                            ),
                          ),

                          Expanded(
                            child:
                            Divider(),
                          ),
                        ],
                      ),

                      const SizedBox(
                          height: 20),
                      Row(
                        children: [

                          Expanded(
                            child: socialIconButton(
                              icon: Icons.g_mobiledata,
                              color: Colors.white,
                              iconColor: Colors.red,
                              onTap: () async {

                                try {

                                  setState(() {
                                    loading = true;
                                  });

                                  final user =
                                  await _googleAuthService.login();

                                  if (user != null) {

                                    await AuthService.instance.socialLogin(
                                      provider: "GOOGLE",
                                      idToken: user.idToken!,
                                      accessToken: user.accessToken,
                                    );

                                    if (!mounted) return;

                                    Navigator.pushAndRemoveUntil(
                                      context,
                                      MaterialPageRoute(
                                        builder: (_) =>
                                        const BaseScreen(),
                                      ),
                                          (route) => false,
                                    );
                                  }

                                } catch (e) {

                                  showMessage(
                                    "Google Sign In Failed\n$e",
                                  );

                                } finally {

                                  if (mounted) {
                                    setState(() {
                                      loading = false;
                                    });
                                  }
                                }
                              },
                            ),
                          ),

                          const SizedBox(width: 12),

                          Expanded(
                            child: socialIconButton(
                              icon: Icons.apple,
                              color: Colors.white,
                              iconColor: Colors.black,
                              onTap: () {

                                showMessage(
                                  "Apple Login Coming Soon",
                                );

                              },
                            ),
                          ),

                          const SizedBox(width: 12),

                          Expanded(
                            child: socialIconButton(
                              icon: Icons.facebook,
                              color: const Color(0xff1877F2),
                              iconColor: Colors.white,
                              onTap: () {

                                showMessage(
                                  "Facebook Login Coming Soon",
                                );

                              },
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 25),

                      Row(
                        mainAxisAlignment:
                        MainAxisAlignment.center,
                        children: [

                          const Text(
                            "Don't have an account?",
                            style: TextStyle(
                              color: Colors.white70,
                            ),
                          ),

                          TextButton(
                            onPressed: () {

                              Navigator.pushReplacement(
                                context,
                                MaterialPageRoute(
                                  builder: (_) =>
                                  const RegisterScreen(),
                                ),
                              );

                            },
                            child: const Text(
                              "Create Account",
                              style: TextStyle(
                                color: Color(0xFFFF1100),
                                fontWeight:
                                FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),

        /// Full Screen Loader
        if (loading)
          Positioned.fill(
            child: Container(
              color: Colors.black54,
              child: const Center(
                child: CircularProgressIndicator(
                  color: Color(0xFFFF1100),
                ),
              ),
            ),
          ),
      ],
    ),
  );
  }
  Widget socialIconButton({
    required IconData icon,
    required Color color,
    required Color iconColor,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Container(
        height: 52,
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.25),
              blurRadius: 8,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Center(
          child: Icon(
            icon,
            size: 32,
            color: iconColor,
          ),
        ),
      ),
    );
  }





}