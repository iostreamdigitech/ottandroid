import 'dart:async';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';



import '../../../api/api_service.dart';
import '../../../api/auth_service.dart';

import '../../../core/utils/device_details.dart';
import '../../home/page/base_screen.dart';
import 'login_screen.dart';

class OtpVerificationScreen extends StatefulWidget {
  final int userId;
  final String email;
  final String? mobile;
  final String? maskedEmail;
  final String? maskedMobile;
  final int otpExpiresInSeconds;
  final String purpose;
  const OtpVerificationScreen({
    super.key,
    required this.userId,
    required this.email,
    this.mobile,
    this.maskedEmail,
    this.maskedMobile,
    required this.otpExpiresInSeconds,
    required this.purpose,
  });
  @override
  State<OtpVerificationScreen> createState() =>
      _OtpVerificationScreenState();
}

class _OtpVerificationScreenState
    extends State<OtpVerificationScreen> {
  final List<TextEditingController> controllers =
  List.generate(
    6,
        (_) => TextEditingController(),
  );

  final List<FocusNode> focusNodes =
  List.generate(
    6,
        (_) => FocusNode(),
  );

  int seconds = 60;

  Timer? timer;

  bool loading = false;

  @override
  void initState() {
    super.initState();
    startTimer();
  }

  @override
  void dispose() {
    timer?.cancel();

    for (final c in controllers) {
      c.dispose();
    }

    for (final f in focusNodes) {
      f.dispose();
    }

    super.dispose();
  }

  void startTimer() {
    seconds = widget.otpExpiresInSeconds;

    timer?.cancel();

    timer = Timer.periodic(
      const Duration(seconds: 1),
          (t) {
        if (seconds == 0) {
          t.cancel();
        } else {
          setState(() {
            seconds--;
          });
        }
      },
    );
  }

  String get otp =>
      controllers.map((e) => e.text).join();
  Future<void> _goToBaseScreen(BuildContext context) async {
    try {

      final device = await DeviceHelper.getDeviceDetails();
      final response = await ApiService.instance.dio.post(
        "/iam/api/users/devices",
        data: device.toJson(),
      );

      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(
          builder: (_) => const BaseScreen(),
        ),
            (route) => false,
      );
    } catch (e) {
      debugPrint("Device registration failed: $e");

      // Navigate even if API fails (optional)
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(
          builder: (_) => const BaseScreen(),
        ),
            (route) => false,
      );
    }
  }
  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    final cardWidth =
    size.width > 450 ? 420.0 : size.width * .92;

    return Scaffold(
      body: Stack(
        children: [
      Positioned.fill(
      child: Image.asset(
        "assets/bg_login.png",
        fit: BoxFit.cover,
      ),
    ),

    Positioned.fill(
    child: Container(
    decoration: BoxDecoration(
    gradient: LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [
    Colors.black.withOpacity(.30),
    Colors.black.withOpacity(.70),
    Colors.black.withOpacity(.95),
    ],
    ),
    ),
    ),
    ),

    SafeArea(
    child: Center(
    child: SingleChildScrollView(
    padding: const EdgeInsets.all(16),
    child: ClipRRect(
    borderRadius:
    BorderRadius.circular(28),
    child: BackdropFilter(
    filter: ImageFilter.blur(
    sigmaX: 14,
    sigmaY: 14,
    ),
    child: Container(
    width: cardWidth,
    padding:
    const EdgeInsets.all(24),
    decoration: BoxDecoration(
    color:
    Colors.black.withOpacity(.45),
    borderRadius:
    BorderRadius.circular(28),
    border: Border.all(
    color: Colors.white12,
    ),
    ),
    child: Column(
    children: [
    Image.asset(
    "assets/splash_logo.png",
    height: 75,
    ),

    const SizedBox(height: 25),

    const Text(
    "OTP Verification",
    style: TextStyle(
    color: Colors.white,
    fontSize: 28,
    fontWeight:
    FontWeight.bold,
    ),
    ),

    const SizedBox(height: 12),

    Text(
    "We've sent a verification code to",
    textAlign:
    TextAlign.center,
    style: TextStyle(
    color:
    Colors.white70,
    ),
    ),

    const SizedBox(height: 5),

      Text(
        widget.maskedEmail ??
            widget.maskedMobile ??
            widget.email,
        style: const TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.bold,
        ),
      ),

    const SizedBox(height: 35),

    Row(
    mainAxisAlignment:
    MainAxisAlignment
        .spaceBetween,
    children: List.generate(
    6,
    (index) {
    return SizedBox(
    width: 48,
    child: TextField(
    controller:
    controllers[
    index],
    focusNode:
    focusNodes[
    index],
    autofocus:
    index == 0,
    keyboardType:
    TextInputType
        .number,
    textAlign:
    TextAlign
        .center,
    maxLength: 1,

    style:
    const TextStyle(
    color:
    Colors.white,
    fontSize: 22,
    fontWeight:
    FontWeight
        .bold,
    ),

    autofillHints:
    const [
    AutofillHints
        .oneTimeCode,
    ],

    inputFormatters: [
    FilteringTextInputFormatter
        .digitsOnly,
    ],

    decoration:
    InputDecoration(
    counterText:
    "",
    filled:
    true,
    fillColor:
    Colors
        .white10,
    border:
    OutlineInputBorder(
    borderRadius:
    BorderRadius
        .circular(
    14),
    ),
    ),

    onChanged:
    (value) {
    if (value
        .isNotEmpty &&
    index <
    5) {
    focusNodes[
    index +
    1]
        .requestFocus();
    }

    if (value
        .isEmpty &&
    index >
    0) {
    focusNodes[
    index -
    1]
        .requestFocus();
    }
    },
    ),
    );
    },
    ),
    ),

    const SizedBox(height: 30),

    Text(
    seconds == 0
    ? "OTP Expired"
        : "00:${seconds.toString().padLeft(2, '0')}",
    style: TextStyle(
    color: seconds == 0
    ? Colors.red
        : Colors.white70,
    fontSize: 16,
    ),
    ),

    const SizedBox(height: 30),

      SizedBox(
        width: double.infinity,
        height: 56,
        child: DecoratedBox(
          decoration: BoxDecoration(
            borderRadius:
            BorderRadius.circular(16),
            gradient: const LinearGradient(
              colors: [
                Color(0xFFE50914),
                Color(0xFFFF3B30),
              ],
            ),
          ),
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.transparent,
              shadowColor: Colors.transparent,
              shape: RoundedRectangleBorder(
                borderRadius:
                BorderRadius.circular(16),
              ),
            ),
            onPressed: loading
                ? null
                : () async {
              FocusScope.of(context).unfocus();

              if (otp.length != 6) {
                ScaffoldMessenger.of(context)
                    .showSnackBar(
                  const SnackBar(
                    content: Text(
                      "Please enter the 6-digit OTP",
                    ),
                  ),
                );
                return;
              }

              setState(() {
                loading = true;
              });

              try {
                setState(() {
                  loading = true;
                });

                final result = await AuthService.instance.verifyOtp(
                  userId: widget.userId,
                  otp: otp,
                  purpose: widget.purpose,
                );

                if (!mounted) return;

                if (result["success"] == true) {

                  if (widget.purpose =="REGISTRATION") {

                    Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const LoginScreen(),
                      ),
                          (_) => false,
                    );

                  } else {

                    _goToBaseScreen(context);

                  }

                } else {

                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(result["message"]),
                    ),
                  );

                }
              } catch (e) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(e.toString()),
                  ),
                );
              } finally {
                if (mounted) {
                  setState(() {
                    loading = false;
                  });
                }
              }
            },
            child: loading
                ? const SizedBox(
              width: 28,
              height: 28,
              child:
              CircularProgressIndicator(
                color: Colors.white,
                strokeWidth: 3,
              ),
            )
                : const Text(
              "VERIFY OTP",
              style: TextStyle(
                color: Colors.white,
                fontWeight:
                FontWeight.bold,
                fontSize: 17,
              ),
            ),
          ),
        ),
      ),

      const SizedBox(height: 22),

      Row(
        mainAxisAlignment:
        MainAxisAlignment.center,
        children: [

          const Text(
            "Didn't receive OTP?",
            style: TextStyle(
              color: Colors.white70,
            ),
          ),

          TextButton(
            onPressed: seconds == 0
                ? () async {

              // TODO:
              // Call Resend OTP API

              startTimer();

              ScaffoldMessenger.of(context)
                  .showSnackBar(
                const SnackBar(
                  content: Text(
                    "OTP Sent Successfully",
                  ),
                ),
              );
            }
                : null,
            child: Text(
              "Resend",
              style: TextStyle(
                color: seconds == 0
                    ? const Color(0xFFE50914)
                    : Colors.grey,
                fontWeight:
                FontWeight.bold,
              ),
            ),
          ),

        ],
      ),

      const SizedBox(height: 20),

      TextButton.icon(
        onPressed: () {
          Navigator.pop(context);
        },
        icon: const Icon(
          Icons.arrow_back_ios_new,
          color: Colors.white70,
          size: 18,
        ),
        label: const Text(
          "Back",
          style: TextStyle(
            color: Colors.white70,
          ),
        ),
      ),

    ],
    ),
    ),
    ),
    ),
    ),
    ),
    ),
        ],
      ),
    );
  }
}