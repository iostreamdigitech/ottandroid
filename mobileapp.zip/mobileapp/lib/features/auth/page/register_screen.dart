import 'dart:io' show Platform;
import 'dart:ui';

import 'package:flutter/foundation.dart';

import 'package:flutter/material.dart';

import '../../../api/auth_service.dart';
import 'otp_verification_screen.dart';


class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {

  final nameController = TextEditingController();
  final mobileController = TextEditingController();
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  final confirmPasswordController = TextEditingController();

  bool obscurePassword = true;
  bool obscureConfirmPassword = true;
  bool loading = false;
  final bool showMobileField =
      kIsWeb || (kIsWeb && Platform.isAndroid);
  final _formKey = GlobalKey<FormState>();

  @override
  void dispose() {
    nameController.dispose();
    mobileController.dispose();
    emailController.dispose();
    passwordController.dispose();
    confirmPasswordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {

    final size = MediaQuery.of(context).size;

    final cardWidth = size.width > 450
        ? 420.0
        : size.width * .92;

    return Scaffold(

      body: Stack(

        children: [

      /// Background

      Positioned.fill(

      child: Image.asset(
        "assets/bg_login.png",
        fit: BoxFit.cover,
      ),
    ),

    /// Overlay

    Positioned.fill(

    child: Container(

    decoration: BoxDecoration(

    gradient: LinearGradient(

    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,

    colors: [

    Colors.black.withOpacity(.35),

    Colors.black.withOpacity(.75),

    Colors.black.withOpacity(.95),

    ],

    ),

    ),

    ),

    ),

    SafeArea(

    child: Center(

    child: SingleChildScrollView(

    padding: const EdgeInsets.all(12),

    child: ClipRRect(

    borderRadius: BorderRadius.circular(28),

    child: BackdropFilter(

    filter: ImageFilter.blur(
    sigmaX: 12,
    sigmaY: 12,
    ),

    child: Container(

    width: cardWidth,

    padding: const EdgeInsets.all(24),

    decoration: BoxDecoration(

    color: Colors.black.withOpacity(.45),

    borderRadius: BorderRadius.circular(28),

    border: Border.all(
    color: Colors.white.withOpacity(.08),
    ),

    ),

    child: Form(

    key: _formKey,

    child: Column(

    mainAxisSize: MainAxisSize.min,

    children: [

    Image.asset(
    "assets/splash_logo.png",
    height: 75,
    ),




    const SizedBox(height: 5),

    const Text(

    "Register to continue",

    style: TextStyle(

    color: Colors.white70,

    fontSize: 15,

    ),

    ),

    const SizedBox(height: 20),

    /// Name

    TextFormField(

    controller: nameController,

    style: const TextStyle(
    color: Colors.white,
    ),

    validator: (value) {

    if (value == null || value.trim().isEmpty) {
    return "Enter Full Name";
    }

    return null;
    },

    decoration: fieldDecoration(

    "Full Name",

    Icons.person_outline,

    ),

    ),

    const SizedBox(height: 16),

    /// Mobile (Android only)

      if (showMobileField)...[

    TextFormField(

    controller: mobileController,

    keyboardType: TextInputType.phone,

    style: const TextStyle(
    color: Colors.white,
    ),

    validator: (value) {

    if (value == null || value.isEmpty) {
    return "Enter Mobile Number";
    }

    if (value.length != 10) {
    return "Invalid Mobile Number";
    }

    return null;
    },

    decoration: fieldDecoration(

    "Mobile Number",

    Icons.phone_android,

    ),

    ),

    const SizedBox(height: 16),

    ],

    /// Email

    TextFormField(

    controller: emailController,

    keyboardType: TextInputType.emailAddress,

    style: const TextStyle(
    color: Colors.white,
    ),

    validator: (value) {

    if (value == null || value.isEmpty) {
    return "Enter Email";
    }

    if (!RegExp(
    r'^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$',
    ).hasMatch(value)) {
    return "Invalid Email";
    }

    return null;
    },

    decoration: fieldDecoration(

    "Email Address",

    Icons.email_outlined,

    ),

    ),

    const SizedBox(height: 16),

    /// Password

    TextFormField(

    controller: passwordController,

    obscureText: obscurePassword,

    style: const TextStyle(
    color: Colors.white,
    ),

    validator: (value) {

    if (value == null || value.length < 6) {
    return "Minimum 6 characters";
    }

    return null;
    },

    decoration: fieldDecoration(

    "Password",

    Icons.lock_outline,

    ).copyWith(

    suffixIcon: IconButton(

    icon: Icon(

    obscurePassword
    ? Icons.visibility_off
        : Icons.visibility,

    color: Colors.white70,

    ),

    onPressed: () {

    setState(() {

    obscurePassword =
    !obscurePassword;

    });

    },

    ),

    ),

    ),

    const SizedBox(height: 16),

    /// Confirm Password

    TextFormField(

    controller: confirmPasswordController,

    obscureText: obscureConfirmPassword,

    style: const TextStyle(
    color: Colors.white,
    ),

    validator: (value) {

    if (value != passwordController.text) {
    return "Password doesn't match";
    }

    return null;
    },

    decoration: fieldDecoration(

    "Confirm Password",

    Icons.lock_outline,

    ).copyWith(

    suffixIcon: IconButton(

    icon: Icon(

    obscureConfirmPassword
    ? Icons.visibility_off
        : Icons.visibility,

    color: Colors.white70,

    ),

    onPressed: () {

    setState(() {

    obscureConfirmPassword =
    !obscureConfirmPassword;

    });

    },

    ),

    ),

    ),

    const SizedBox(height: 20),

      /// CREATE ACCOUNT BUTTON

      SizedBox(
        width: double.infinity,
        height: 58,
        child: DecoratedBox(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            gradient: const LinearGradient(
              colors: [
                Color(0xFFFF1100),
                Color(0xFFE50914),
              ],
            ),
          ),
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.transparent,
              shadowColor: Colors.transparent,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
            ),
            onPressed: loading
                ? null
                : () async {
              FocusScope.of(context).unfocus();

              if (!_formKey.currentState!
                  .validate()) {
                return;
              }

              setState(() {
                loading = true;
              });

              try {
                final result = await AuthService.instance.register({
                  "username": emailController.text.trim(),
                  "email": emailController.text.trim(),
                  "password": passwordController.text.trim(),
                  "fullName": nameController.text.trim(),
                  "mobileNumber": mobileController.text.trim(),
                  "userType": "CUSTOMER",
                });

                if (!mounted) return;

                if (result["success"] == true &&
                    result["userId"]!= null) {

                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (_) => OtpVerificationScreen(
                        userId: result["userId"],
                        email: emailController.text.trim(),
                        mobile: mobileController.text.trim(),
                        maskedEmail: result["maskedEmail"],
                        maskedMobile: result["maskedMobile"],
                        otpExpiresInSeconds: result["otpExpiresInSeconds"] ?? 600,
                        purpose: "REGISTRATION",
                      ),
                    ),
                  );
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(result["message"] ?? "Registration failed"),
                    ),
                  );
                }
              } catch (e) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text(e.toString())),
                );
              } finally {
                if (mounted) {
                  setState(() => loading = false);
                }
              }
            },
            child: loading
                ? const SizedBox(
              width: 25,
              height: 25,
              child:
              CircularProgressIndicator(
                color: Colors.white,
                strokeWidth: 3,
              ),
            )
                : const Text(
              "CREATE ACCOUNT",
              style: TextStyle(
                fontSize: 17,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ),
        ),
      ),

      const SizedBox(height: 10),

      Row(
        mainAxisAlignment:
        MainAxisAlignment.center,
        children: [
          const Text(
            "Already have an account?",
            style: TextStyle(
              color: Colors.white70,
            ),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text(
              "LOGIN",
              style: TextStyle(
                color: Color(0xFFFF1100),
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    ],
    ),
    ),
    ),
    ),
    ),
    ),
    ),
    ),
        ],
      ),
    );
  }

  InputDecoration fieldDecoration(
      String hint,
      IconData icon,
      ) {
    return InputDecoration(
      hintText: hint,
      hintStyle: const TextStyle(
        color: Colors.white60,
      ),
      prefixIcon: Icon(
        icon,
        color: Colors.white70,
      ),
      filled: true,
      fillColor: Colors.white.withOpacity(.05),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide(
          color: Colors.white.withOpacity(.10),
        ),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: const BorderSide(
          color: Color(0xFFFF1100),
          width: 1.5,
        ),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: const BorderSide(
          color: Colors.redAccent,
        ),
      ),
      focusedErrorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: const BorderSide(
          color: Colors.redAccent,
          width: 2,
        ),
      ),
    );
  }
}