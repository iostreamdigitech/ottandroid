import 'package:flutter/material.dart';

import '../../../api/auth_service.dart';
import '../../../auth/service/google_auth_service.dart';
import '../../home/page/base_screen.dart';
import '../animation/fade_slide.dart';
import '../widget/full_screen_loader.dart';
import '../widget/login_card.dart';
import 'otp_verification_screen.dart';


class LoginScreen extends StatefulWidget {

  const LoginScreen({
    super.key,
  });


  @override
  State<LoginScreen> createState() =>
      _LoginScreenState();

}



class _LoginScreenState
    extends State<LoginScreen> {


  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  final GoogleAuthService _googleAuthService =
  GoogleAuthService();


  final emailController =
  TextEditingController();


  final passwordController =
  TextEditingController();



  bool isLoginLoading = false;


  bool isSocialLoading = false;


  bool rememberMe = false;


  String? validateEmailOrMobile(String? value) {
    if (value == null || value.trim().isEmpty) {
      return "Email or Mobile Number is required";
    }

    final input = value.trim();

    if (input.contains("@")) {
      final emailRegex = RegExp(
        r'^[\w\-.]+@([\w\-]+\.)+[\w\-]{2,4}$',
      );

      if (!emailRegex.hasMatch(input)) {
        return "Please enter a valid email";
      }
    } else {
      if (!RegExp(r'^[0-9]{10}$').hasMatch(input)) {
        return "Please enter a valid mobile number";
      }
    }

    return null;
  }

  String? validatePassword(String? value) {

    if (value == null || value.isEmpty) {
      return "Password is required";
    }

    if (value.length < 6) {
      return "Password must contain at least 6 characters";
    }

    return null;
  }

  void showMessage(
      String message, {
        bool success = false,
      }) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        behavior: SnackBarBehavior.floating,
        backgroundColor:
        success ? Colors.green : Colors.red,
        content: Text(message),
      ),
    );
  }

  Future<void> login() async {

    FocusScope.of(context).unfocus();

    if (!_formKey.currentState!.validate()) {
      return;
    }

    setState(() {
      isLoginLoading = true;
    });

    try {

      final result =
      await AuthService.instance.login({
        "email": emailController.text.trim(),
        "password": passwordController.text,
      });

      if (!mounted) return;

      if (result["twoFaRequired"] == true) {

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => OtpVerificationScreen(
              userId: result["userId"],
              email: emailController.text.trim(),
              maskedEmail: result["maskedEmail"],
              maskedMobile: result["maskedMobile"],
              otpExpiresInSeconds:
              result["otpExpiresInSeconds"] ?? 600,
              purpose: "LOGIN",
            ),
          ),
        );
      } else if (result["token"] != null) {

        showMessage(
          "Login Successful",
          success: true,
        );

        Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(
            builder: (_) => const BaseScreen(),
          ),
              (route) => false,
        );
      } else {

        showMessage(
          result["message"] ??
              "Invalid email or password",
        );
      }
    } catch (e) {

      showMessage(e.toString());

    } finally {

      if (mounted) {
        setState(() {
          isLoginLoading = false;
        });
      }
    }
  }

  @override
  void dispose() {

    emailController.dispose();

    passwordController.dispose();

    super.dispose();

  }











  Future<void> googleLogin() async {


    await socialAuthentication(
      "Google",
    );

  }





  Future<void> facebookLogin() async {


    await socialAuthentication(
      "Facebook",
    );

  }





  Future<void> appleLogin() async {


    await socialAuthentication(
      "Apple",
    );

  }





  Future<void> socialAuthentication(
      String provider
      ) async {


    setState(() {

      isSocialLoading=true;

    });



    try {


      // TODO:
      // Google/Facebook/Apple SDK Login

      await Future.delayed(
        const Duration(seconds:2),
      );



    }

    finally {


      if(mounted){

        setState(() {

          isSocialLoading=false;

        });

      }


    }

  }





  @override
  Widget build(BuildContext context) {


    return Scaffold(


      resizeToAvoidBottomInset:true,


      body:
      Stack(


        fit:
        StackFit.expand,


        children: [



          /// Background
          _background(),




          /// Dark cinematic overlay
          Container(

            decoration:
            BoxDecoration(

              gradient:
              LinearGradient(

                begin:
                Alignment.centerLeft,


                end:
                Alignment.centerRight,


                colors:[


                  Colors.black.withOpacity(.65),


                  Colors.black.withOpacity(.35),


                  Colors.black.withOpacity(.75),


                ],

              ),

            ),

          ),





          /// Login content

          SafeArea(


            child:
            SingleChildScrollView(


              padding:
              const EdgeInsets.symmetric(

                horizontal:20,

                vertical:30,

              ),



              child:
              FadeSlide(


                delay:
                const Duration(
                  milliseconds:200,
                ),



                child:
                LoginCard(
                  formKey: _formKey,


                  emailController:
                  emailController,


                  passwordController:
                  passwordController,


                  isLoading:
                  isLoginLoading,



                  rememberMe:
                  rememberMe,
                  emailValidator: validateEmailOrMobile,
                  passwordValidator: validatePassword,



                  onRememberChanged:
                      (value){

                    setState(() {

                      rememberMe =
                          value ?? false;

                    });

                  },



                  onLogin:
                  login,



                  onGuestLogin:
                      (){

                    // Guest flow

                  },


                  onForgotPassword:
                      (){

                    // Forgot password page

                  },


                ),

              ),

            ),

          ),





          /// Social / API loader overlay

          FullScreenLoader(

            visible:
            isSocialLoading,


            message:
            "Signing in...",

          ),



        ],

      ),


    );

  }





  Widget _background(){


    return Container(


      decoration:
      const BoxDecoration(


        image:
        DecorationImage(


          fit:
          BoxFit.cover,


          image:
          AssetImage(

            "assets/bg_cinimatic.png",

          ),


        ),


      ),


    );

  }


}