import 'package:flutter/material.dart';

import '../../../core/utils/device_utils.dart';
import '../../../enum/MenuItemType.dart';
import '../../../widgets/app_shell.dart';
import '../layout/mobile/mobile_profile_layout.dart';
import '../layout/tv/tv_profile_layout.dart';
import '../layout/web/desktop_profile_layout.dart';





class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return AppShell(
      activeMenu: MenuItemType.profile,
      child: Scaffold(
        backgroundColor: const Color(0xFF020B23),
        body: SafeArea(
          child: AnimatedSwitcher(
            duration: const Duration(milliseconds: 350),
            child: _buildResponsiveLayout(context),
          ),
        ),
      ),
    );
  }

  Widget _buildResponsiveLayout(BuildContext context) {
    if (DeviceUtils.isTV(context)) {
      return const TvProfileLayout();
    }

    if (DeviceUtils.isDesktop(context)) {
      return const DesktopProfileLayout();
    }

    if (DeviceUtils.isTablet(context)) {
      return const DesktopProfileLayout();
    }

    return const MobileProfileLayout();
  }
}