import 'package:dio/dio.dart';

import '../../../api/api_service.dart';
import '../models/CurrentUser.dart';
import '../models/active_subscription.dart';
import '../models/user_device.dart';

class ProfileService {
  ProfileService._();

  static final ProfileService instance =
  ProfileService._();

  final Dio _dio = Dio();

  Future<ActiveSubscription> getActiveSubscription() async {
    try {
      final response = await ApiService.instance.dio.get(
        '/payService/api/payments/subscriptions/user/me/active',
      );

      final responseData =
      Map<String, dynamic>.from(response.data);

      if (responseData['success'] != true) {
        return ActiveSubscription.none();
      }

      final data = responseData['data'];

      if (data == null) {
        return ActiveSubscription.none();
      }

      return ActiveSubscription.fromJson(
        Map<String, dynamic>.from(data),
      );
    } catch (e) {
      return ActiveSubscription.none();
    }
  }
  Future<List<UserDevice>> getDevices() async {
    final response = await ApiService.instance.dio.get("/iam/api/users/devices");

    final body = response.data;

    if (body is! Map<String, dynamic>) {
      throw Exception(
        'Invalid device response',
      );
    }

    if (body['success'] != true) {
      throw Exception(
        body['message'] ??
            'Unable to load devices',
      );
    }

    final data = body['data'];

    if (data is! List) {
      return [];
    }

    return data
        .whereType<Map<String, dynamic>>()
        .map(
          (json) => UserDevice.fromJson(json),
    )
        .toList();
  }
  Future<CurrentUser> getCurrentUser() async {
    final response = await ApiService.instance.dio.get("/iam/api/users/me");


    final body = response.data;

    if (body['success'] != true) {
      throw Exception(
        body['message'] ?? 'Unable to load profile',
      );
    }

    return CurrentUser.fromJson(
      body['data'],
    );
  }
}