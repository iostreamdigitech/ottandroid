import 'package:flutter/material.dart';
import 'package:ottoneapp/api/auth_service.dart';
import 'package:ottoneapp/widgets/ott_footer.dart';

import '../../../../screens/subscription_page.dart';
import '../../../home/page/base_screen.dart';
import '../../models/CurrentUser.dart';
import '../../models/active_subscription.dart';
import '../../models/user_device.dart';
import '../../service/ProfileService.dart';
import '../../widget/continue_watching_section.dart';
import '../../widget/dashboard_statistics.dart';
import '../../widget/downloads_devices_section.dart';
import '../../widget/quick_action_grid.dart';
import '../../widget/settings_section.dart';
import '../../widget/subscription_details_section.dart';
import '../../widget/watchlist_section.dart';



class DesktopProfileLayout extends StatefulWidget {
  const DesktopProfileLayout({super.key});

  @override
  State<DesktopProfileLayout> createState() =>
      _DesktopProfileLayoutState();
}

class _DesktopProfileLayoutState
    extends State<DesktopProfileLayout> {
  CurrentUser? _user;
  ActiveSubscription _subscription =
  ActiveSubscription.none();
  bool _loading = true;
  String? _error;
  List<UserDevice> _devices = [];
  @override
  void initState() {
    super.initState();
    _loadProfile();
  }

  Future<void> _loadProfile() async {
    if (mounted) {
      setState(() {
        _loading = true;
        _error = null;
      });
    }

    try {
      final results = await Future.wait([
        ProfileService.instance.getCurrentUser(),
        ProfileService.instance.getDevices(),
        ProfileService.instance.getActiveSubscription(),
      ]);

      final user = results[0] as CurrentUser;
      final devices = results[1] as List<UserDevice>;
      final subscription =
      results[2] as ActiveSubscription;

      if (!mounted) return;

      setState(() {
        _user = user;
        _devices = devices;
        _subscription = subscription;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _loading = false;
        _error = _cleanErrorMessage(e);
      });
    }
  }

  String _cleanErrorMessage(Object error) {
    final message = error.toString();

    if (message.startsWith('Exception: ')) {
      return message.substring('Exception: '.length);
    }

    return message;
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const _ProfileLoadingView();
    }

    if (_error != null || _user == null) {
      return _ProfileErrorView(
        message: _error ?? 'Unable to load profile',
        onRetry: _loadProfile,
      );
    }

    return Scaffold(
      backgroundColor: const Color(0xff020B23),
      body: SafeArea(
        child: Row(
          children: [
            /// LEFT PANEL
            Expanded(
              flex: 3,
              child: _LeftPanel(
                user: _user!,
                devices: _devices,
                subscription: _subscription,
              ),
            ),

            /// RIGHT PANEL
            Expanded(
              flex: 7,
              child: const _RightPanel(),
            ),
          ],
        ),
      ),
    );
  }
}

/// ===============================================================
/// LEFT PANEL
/// ===============================================================

class _LeftPanel extends StatelessWidget {
  final CurrentUser user;
  final List<UserDevice> devices;
  final ActiveSubscription subscription;

  const _LeftPanel({

    required this.user,
    required this.devices,
    required this.subscription,

  });
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xff0B1736),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(
          color: Colors.white10,
        ),
      ),
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            /// Profile avatar
            _ProfileAvatar(
              user: user,
            ),

            const SizedBox(height: 20),

            /// Name
            Text(
              user.fullName,
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 24,
              ),
            ),

            const SizedBox(height: 6),

            /// Email
            Text(
              user.email,
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: Colors.white60,
                fontSize: 13,
              ),
            ),

            if (user.mobileNumber.isNotEmpty) ...[
              const SizedBox(height: 5),

              /// Mobile
              Text(
                user.mobileNumber,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: Colors.white60,
                  fontSize: 13,
                ),
              ),
            ],

            const SizedBox(height: 16),

            /// Verification badges
            _VerificationRow(
              emailVerified: user.emailVerified,
              mobileVerified: user.mobileVerified,
            ),

            const SizedBox(height: 20),

            /// User type
            _InfoBadge(
              icon: Icons.person_outline,
              label: user.userType,
            ),

            const SizedBox(height: 24),

            /// Subscription
            _SubscriptionCard(
              subscription: subscription,
            ),

            const SizedBox(height: 24),

            /// Statistics
            _Statistics(
              deviceCount: devices.length,
            ),

            const SizedBox(height: 24),

            /// 2FA status
            _SecurityCard(
              twoFaEnabled: user.twoFaEnabled,
              active: user.active,
            ),

            const SizedBox(height: 24),

            /// Edit Profile
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: () {
                  _showEditProfileMessage(context);
                },
                icon: const Icon(
                  Icons.edit_outlined,
                  size: 18,
                ),
                label: const Text(
                  'Edit Profile',
                ),
              ),
            ),

            const SizedBox(height: 14),

            /// Logout
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                style: FilledButton.styleFrom(
                  backgroundColor: Colors.red.shade700,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(
                    vertical: 14,
                  ),
                ),
                onPressed: () async {
                  await AuthService.instance.logout();
                },
                icon: const Icon(
                  Icons.logout,
                  size: 18,
                ),
                label: const Text(
                  'Logout',
                ),
              ),
            ),

            const SizedBox(height: 10),
          ],
        ),
      ),
    );
  }

  void _showEditProfileMessage(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          'Edit Profile API can be connected here.',
        ),
      ),
    );
  }
}

class _SubscriptionCard extends StatelessWidget {
  final ActiveSubscription subscription;

  const _SubscriptionCard({
    required this.subscription,
  });

  @override
  Widget build(BuildContext context) {
    if (!subscription.active) {
      return _NoSubscriptionCard(
        onUpgrade: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => SubscriptionPage(),
            ),
          );
        },
      );
    }

    return _ActiveSubscriptionCard(
      subscription: subscription,
      onUpgrade: () {
        Navigator.pushNamed(
          context,
          '/subscriptions',
        );
      },
    );
  }
}

class _NoSubscriptionCard extends StatelessWidget {
  final VoidCallback onUpgrade;

  const _NoSubscriptionCard({
    required this.onUpgrade,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.045),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: Colors.white.withOpacity(.08),
        ),
      ),
      child: Column(
        children: [
          const Icon(
            Icons.workspace_premium_outlined,
            color: Colors.white54,
            size: 38,
          ),

          const SizedBox(height: 10),

          const Text(
            'No Active Subscription',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white,
              fontSize: 17,
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 5),

          const Text(
            'Choose a plan to unlock premium content.',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white54,
              fontSize: 12,
            ),
          ),

          const SizedBox(height: 15),

          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: onUpgrade,
              icon: const Icon(
                Icons.upgrade_rounded,
                size: 17,
              ),
              label: const Text(
                'Upgrade Subscription',
              ),
            ),
          ),
        ],
      ),
    );
  }
}
class _ActiveSubscriptionCard extends StatelessWidget {
  final ActiveSubscription subscription;
  final VoidCallback onUpgrade;

  const _ActiveSubscriptionCard({
    required this.subscription,
    required this.onUpgrade,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xff6A1B9A),
            Color(0xff283593),
          ],
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.purple.withOpacity(.18),
            blurRadius: 20,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(
                Icons.workspace_premium_rounded,
                color: Colors.amber,
                size: 32,
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  subscription.plan?.planName ?? 'Subscription',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 9,
                  vertical: 5,
                ),
                decoration: BoxDecoration(
                  color: Colors.greenAccent.withOpacity(.12),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Text(
                  'ACTIVE',
                  style: TextStyle(
                    color: Colors.greenAccent,
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: 16),

          if (subscription.startDate != null)
            _SubscriptionInfoRow(
              icon: Icons.calendar_today_outlined,
              label: 'Started',
              value: subscription.startDate!,
            ),

          if (subscription.endDate != null) ...[
            const SizedBox(height: 9),
            _SubscriptionInfoRow(
              icon: Icons.event_outlined,
              label: 'Expires',
              value: subscription.endDate!,
            ),
          ],

          const SizedBox(height: 9),

          _SubscriptionInfoRow(
            icon: Icons.autorenew_rounded,
            label: 'Auto Renew',
            value: subscription.autoRenew
                ? 'Enabled'
                : 'Disabled',
          ),

          const SizedBox(height: 16),

          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: onUpgrade,
              icon: const Icon(
                Icons.upgrade_rounded,
                size: 17,
              ),
              label: const Text('Upgrade Subscription'),
              style: OutlinedButton.styleFrom(
                foregroundColor: Colors.white,
                side: BorderSide(
                  color: Colors.white.withOpacity(.35),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SubscriptionInfoRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _SubscriptionInfoRow({
    required this.icon,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(
          icon,
          size: 15,
          color: Colors.white60,
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            label,
            style: const TextStyle(
              color: Colors.white60,
              fontSize: 11,
            ),
          ),
        ),
        Text(
          value,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 11,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }
}
/// ===============================================================
/// PROFILE AVATAR
/// ===============================================================

class _ProfileAvatar extends StatelessWidget {
  final CurrentUser user;

  const _ProfileAvatar({
    required this.user,
  });

  @override
  Widget build(BuildContext context) {
    final initials = _getInitials(user.fullName);

    return Container(
      width: 110,
      height: 110,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xffE50914),
            Color(0xff7B1FA2),
          ],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.red.withOpacity(.20),
            blurRadius: 25,
            spreadRadius: 3,
          ),
        ],
      ),
      padding: const EdgeInsets.all(3),
      child: CircleAvatar(
        backgroundColor: const Color(0xff111D3A),
        child: Text(
          initials,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 32,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }

  String _getInitials(String name) {
    if (name.trim().isEmpty) {
      return '?';
    }

    final parts = name
        .trim()
        .split(RegExp(r'\s+'))
        .where((e) => e.isNotEmpty)
        .toList();

    if (parts.length == 1) {
      return parts.first
          .substring(
        0,
        parts.first.length >= 2
            ? 2
            : 1,
      )
          .toUpperCase();
    }

    return '${parts.first[0]}${parts.last[0]}'
        .toUpperCase();
  }
}

/// ===============================================================
/// VERIFICATION
/// ===============================================================

class _VerificationRow extends StatelessWidget {
  final bool emailVerified;
  final bool mobileVerified;

  const _VerificationRow({
    required this.emailVerified,
    required this.mobileVerified,
  });

  @override
  Widget build(BuildContext context) {
    return Wrap(
      alignment: WrapAlignment.center,
      spacing: 8,
      runSpacing: 8,
      children: [
        _VerificationBadge(
          icon: Icons.email_outlined,
          label: 'Email',
          verified: emailVerified,
        ),
        _VerificationBadge(
          icon: Icons.phone_outlined,
          label: 'Mobile',
          verified: mobileVerified,
        ),
      ],
    );
  }
}

class _VerificationBadge extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool verified;

  const _VerificationBadge({
    required this.icon,
    required this.label,
    required this.verified,
  });

  @override
  Widget build(BuildContext context) {
    final color = verified
        ? Colors.greenAccent
        : Colors.orangeAccent;

    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 10,
        vertical: 7,
      ),
      decoration: BoxDecoration(
        color: color.withOpacity(.08),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: color.withOpacity(.18),
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            verified
                ? Icons.verified_rounded
                : Icons.warning_amber_rounded,
            size: 14,
            color: color,
          ),
          const SizedBox(width: 5),
          Text(
            verified
                ? '$label Verified'
                : '$label Pending',
            style: TextStyle(
              color: color,
              fontSize: 11,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

/// ===============================================================
/// USER TYPE
/// ===============================================================

class _InfoBadge extends StatelessWidget {
  final IconData icon;
  final String label;

  const _InfoBadge({
    required this.icon,
    required this.label,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 14,
        vertical: 8,
      ),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.05),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: Colors.white.withOpacity(.06),
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            icon,
            size: 15,
            color: Colors.white70,
          ),
          const SizedBox(width: 6),
          Text(
            label,
            style: const TextStyle(
              color: Colors.white70,
              fontSize: 12,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
}

/// ===============================================================
/// PREMIUM CARD
/// ===============================================================

class _PremiumCard extends StatelessWidget {
  const _PremiumCard();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(
        horizontal: 16,
        vertical: 18,
      ),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xff6A1B9A),
            Color(0xff283593),
          ],
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.purple.withOpacity(.18),
            blurRadius: 20,
          ),
        ],
      ),
      child: const Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            Icons.workspace_premium_rounded,
            color: Colors.amber,
            size: 36,
          ),
          SizedBox(height: 8),
          Text(
            'Premium Plan',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 19,
            ),
          ),
          SizedBox(height: 4),
          Text(
            'Subscription details',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white70,
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }
}

/// ===============================================================
/// STATISTICS
/// ===============================================================

class _Statistics extends StatelessWidget {
  final int deviceCount;

  const _Statistics({
    required this.deviceCount,
  });

  @override
  Widget build(BuildContext context) {
    final items = [

      {
        'icon': Icons.favorite_border_rounded,
        'title': 'Watchlist',
        'value': '0',
      },

      {
        'icon': Icons.devices_outlined,
        'title': 'Devices',
        'value': deviceCount.toString(),
      },
    ];

    return GridView.builder(
      shrinkWrap: true,
      physics:
      const NeverScrollableScrollPhysics(),
      itemCount: items.length,
      gridDelegate:
      const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        childAspectRatio: 1.35,
      ),
      itemBuilder: (context, index) {
        final item = items[index];

        return Container(
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(.045),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: Colors.white.withOpacity(.04),
            ),
          ),
          child: Column(
            mainAxisAlignment:
            MainAxisAlignment.center,
            children: [
              Icon(
                item['icon'] as IconData,
                color: Colors.redAccent,
                size: 25,
              ),
              const SizedBox(height: 7),
              Text(
                item['value'] as String,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 19,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 3),
              Text(
                item['title'] as String,
                style: const TextStyle(
                  color: Colors.white54,
                  fontSize: 11,
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

/// ===============================================================
/// SECURITY CARD
/// ===============================================================

class _SecurityCard extends StatelessWidget {
  final bool twoFaEnabled;
  final bool active;

  const _SecurityCard({
    required this.twoFaEnabled,
    required this.active,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.04),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: Colors.white.withOpacity(.05),
        ),
      ),
      child: Column(
        children: [
          _SecurityRow(
            icon: Icons.security_outlined,
            title: 'Two-Factor Authentication',
            value: twoFaEnabled
                ? 'Enabled'
                : 'Disabled',
            positive: twoFaEnabled,
          ),
          const SizedBox(height: 12),
          _SecurityRow(
            icon: Icons.check_circle_outline,
            title: 'Account Status',
            value: active
                ? 'Active'
                : 'Inactive',
            positive: active,
          ),
        ],
      ),
    );
  }
}

class _SecurityRow extends StatelessWidget {
  final IconData icon;
  final String title;
  final String value;
  final bool positive;

  const _SecurityRow({
    required this.icon,
    required this.title,
    required this.value,
    required this.positive,
  });

  @override
  Widget build(BuildContext context) {
    final color = positive
        ? Colors.greenAccent
        : Colors.orangeAccent;

    return Row(
      children: [
        Icon(
          icon,
          size: 18,
          color: color,
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Text(
            title,
            style: const TextStyle(
              color: Colors.white70,
              fontSize: 12,
            ),
          ),
        ),
        Text(
          value,
          style: TextStyle(
            color: color,
            fontSize: 11,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }
}

/// ===============================================================
/// RIGHT PANEL
/// ===============================================================

class _RightPanel extends StatelessWidget {
  const _RightPanel();

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(
        horizontal: 32,
        vertical: 24,
      ),
      child: Column(
        crossAxisAlignment:
        CrossAxisAlignment.start,
        children: const [
          DesktopHeader(),

          SizedBox(height: 30),

          DashboardStatistics(),



         // SizedBox(height: 35),

         // ContinueWatchingSection(),

         // SizedBox(height: 35),

          //WatchlistSection(),



         // SizedBox(height: 35),

        //  SubscriptionDetailsSection(),

          SizedBox(height: 35),

          SettingsSection(),



          SizedBox(height: 20),
        ],
      ),
    );
  }
}

/// ===============================================================
/// DESKTOP HEADER
/// ===============================================================

class DesktopHeader extends StatelessWidget {
  const DesktopHeader({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        IconButton(
          tooltip: 'Back',
          onPressed: () {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (_) =>
                const BaseScreen(),
              ),
            );
          },
          icon: const Icon(
            Icons.arrow_back_ios_new_rounded,
            color: Colors.white,
            size: 20,
          ),
        ),

        const SizedBox(width: 8),

        const Expanded(
          child: Text(
            'My Profile',
            style: TextStyle(
              color: Colors.white,
              fontSize: 34,
              fontWeight: FontWeight.bold,
              letterSpacing: -.5,
            ),
          ),
        ),

        FilledButton.icon(
          onPressed: () {
            // TODO:
            // Open Edit Profile page/dialog
          },
          icon: const Icon(
            Icons.edit_outlined,
            size: 17,
          ),
          label: const Text(
            'Edit Profile',
          ),
        ),
      ],
    );
  }
}

/// ===============================================================
/// LOADING
/// ===============================================================

class _ProfileLoadingView
    extends StatelessWidget {
  const _ProfileLoadingView();

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      backgroundColor: Color(0xff020B23),
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              width: 32,
              height: 32,
              child: CircularProgressIndicator(
                strokeWidth: 2.5,
                color: Colors.white,
              ),
            ),
            SizedBox(height: 18),
            Text(
              'Loading profile...',
              style: TextStyle(
                color: Colors.white70,
                fontSize: 14,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// ===============================================================
/// ERROR
/// ===============================================================

class _ProfileErrorView
    extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;

  const _ProfileErrorView({
    required this.message,
    required this.onRetry,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xff020B23),
      body: Center(
        child: Container(
          constraints: const BoxConstraints(
            maxWidth: 420,
          ),
          margin: const EdgeInsets.all(24),
          padding: const EdgeInsets.all(28),
          decoration: BoxDecoration(
            color: const Color(0xff0B1736),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(
              color: Colors.white10,
            ),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(
                Icons.cloud_off_rounded,
                color: Colors.white54,
                size: 52,
              ),

              const SizedBox(height: 18),

              const Text(
                'Unable to load profile',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 8),

              Text(
                message,
                textAlign: TextAlign.center,
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: Colors.white54,
                  fontSize: 13,
                ),
              ),

              const SizedBox(height: 22),

              FilledButton.icon(
                onPressed: onRetry,
                icon: const Icon(
                  Icons.refresh,
                ),
                label: const Text(
                  'Try Again',
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}