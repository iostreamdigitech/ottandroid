import 'package:flutter/material.dart';

import '../../../../core/utils/device_utils.dart';

import '../../widget/profile_header.dart';
import '../../widget/quick_action_grid.dart';
import '../../widget/settings_section.dart';
import '../../widget/subscription_card_profile.dart';




class MobileProfileLayout extends StatelessWidget {
  const MobileProfileLayout({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF020B23),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: false,
        title: const Text(
          "My Profile",
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new,
              color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(
          DeviceUtils.horizontalPadding(context),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: const [

            /// Profile Header
            ProfileHeader(),

            SizedBox(height: 24),

            /// Subscription
            SubscriptionCardProfile(),

            SizedBox(height: 28),

            Text(
              "Quick Actions",
              style: TextStyle(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),

            SizedBox(height: 16),

            QuickActionGrid(),

            SizedBox(height: 30),

            Text(
              "Settings",
              style: TextStyle(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),

            SizedBox(height: 16),

            SettingsSection(),

            SizedBox(height: 30),

            LogoutButton(),

            SizedBox(height: 40),
          ],
        ),
      ),
    );
  }
}

class LogoutButton extends StatelessWidget {
  const LogoutButton({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 55,
      child: ElevatedButton.icon(
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.red.shade700,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
        ),
        icon: const Icon(Icons.logout),
        label: const Text(
          "Logout",
          style: TextStyle(
            fontSize: 17,
            fontWeight: FontWeight.bold,
          ),
        ),
        onPressed: () {
          showDialog(
            context: context,
            builder: (_) => AlertDialog(
              backgroundColor: const Color(0xFF111827),
              title: const Text(
                "Logout",
                style: TextStyle(color: Colors.white),
              ),
              content: const Text(
                "Are you sure you want to logout?",
                style: TextStyle(color: Colors.white70),
              ),
              actions: [
                TextButton(
                  child: const Text("Cancel"),
                  onPressed: () => Navigator.pop(context),
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red,
                  ),
                  child: const Text("Logout"),
                  onPressed: () {
                    Navigator.pop(context);

                    // TODO:
                    // Clear Token
                    // Clear MPIN
                    // Navigate Login
                  },
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}