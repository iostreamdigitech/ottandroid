import 'package:flutter/material.dart';

import '../../widget/profile_header.dart';
import '../../widget/quick_action_grid.dart';
import '../../widget/settings_section.dart';
import '../../widget/subscription_card_profile.dart';



class TvProfileLayout extends StatefulWidget {
  const TvProfileLayout({super.key});

  @override
  State<TvProfileLayout> createState() => _TvProfileLayoutState();
}

class _TvProfileLayoutState extends State<TvProfileLayout> {
  final List<String> menus = [
    "Account",
    "Subscription",
    "Watchlist",
    "Downloads",
    "Devices",
    "History",
    "Settings",
    "Help",
    "Logout",
  ];

  int selectedIndex = 0;

  late List<FocusNode> focusNodes;

  @override
  void initState() {
    super.initState();

    focusNodes = List.generate(
      menus.length,
          (_) => FocusNode(),
    );

    WidgetsBinding.instance.addPostFrameCallback((_) {
      focusNodes.first.requestFocus();
    });
  }

  @override
  void dispose() {
    for (final node in focusNodes) {
      node.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xff020B23),
      body: SafeArea(
        child: Row(
          children: [

            /// Left Navigation
            Container(
              width: 340,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(.04),
                border: Border(
                  right: BorderSide(
                    color: Colors.white10,
                  ),
                ),
              ),
              child: Column(
                children: [

                  const SizedBox(height: 30),

                  const Icon(
                    Icons.account_circle,
                    size: 90,
                    color: Colors.white,
                  ),

                  const SizedBox(height: 15),

                  const Text(
                    "MY PROFILE",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  const SizedBox(height: 35),

                  Expanded(
                    child: ListView.builder(
                      itemCount: menus.length,
                      itemBuilder: (_, index) {
                        return _menuItem(index);
                      },
                    ),
                  ),
                ],
              ),
            ),

            /// Right Content
            Expanded(
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 300),
                child: _buildContent(),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _menuItem(int index) {
    return Focus(
      focusNode: focusNodes[index],
      onFocusChange: (hasFocus) {
        if (hasFocus) {
          setState(() {
            selectedIndex = index;
          });
        }
      },
      child: Builder(
        builder: (context) {
          final focused = Focus.of(context).hasFocus;

          return Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 16,
              vertical: 8,
            ),
            child: InkWell(
              onTap: () {
                setState(() {
                  selectedIndex = index;
                });
              },
              borderRadius: BorderRadius.circular(16),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 250),
                height: 72,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  color: focused
                      ? Colors.red.withOpacity(.25)
                      : Colors.transparent,
                  border: Border.all(
                    color: focused
                        ? Colors.red
                        : Colors.transparent,
                    width: 2,
                  ),
                ),
                child: Center(
                  child: Text(
                    menus[index],
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 22,
                      fontWeight: focused
                          ? FontWeight.bold
                          : FontWeight.w500,
                    ),
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildContent() {
    switch (selectedIndex) {
      case 0:
        return const _AccountPage();

      case 1:
        return const _SubscriptionPage();

      case 2:
        return const _WatchListPage();

      case 3:
        return const _DownloadsPage();

      case 4:
        return const _DevicesPage();

      case 5:
        return const _HistoryPage();

      case 6:
        return const _SettingsPage();

      case 7:
        return const _HelpPage();

      case 8:
        return const _LogoutPage();

      default:
        return const _AccountPage();
    }
  }
}
class _AccountPage extends StatelessWidget {
  const _AccountPage();

  @override
  Widget build(BuildContext context) {
    return const SingleChildScrollView(
      padding: EdgeInsets.all(40),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ProfileHeader(),
          SizedBox(height: 30),
          SubscriptionCardProfile(),
          SizedBox(height: 30),
          QuickActionGrid(),
        ],
      ),
    );
  }
}

class _SubscriptionPage extends StatelessWidget {
  const _SubscriptionPage();

  @override
  Widget build(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.all(40),
      child: SubscriptionCardProfile(),
    );
  }
}

class _WatchListPage extends StatelessWidget {
  const _WatchListPage();

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text(
        "Watchlist",
        style: TextStyle(color: Colors.white, fontSize: 30),
      ),
    );
  }
}

class _DownloadsPage extends StatelessWidget {
  const _DownloadsPage();

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text(
        "Downloads",
        style: TextStyle(color: Colors.white, fontSize: 30),
      ),
    );
  }
}

class _DevicesPage extends StatelessWidget {
  const _DevicesPage();

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text(
        "Manage Devices",
        style: TextStyle(color: Colors.white, fontSize: 30),
      ),
    );
  }
}

class _HistoryPage extends StatelessWidget {
  const _HistoryPage();

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text(
        "Watch History",
        style: TextStyle(color: Colors.white, fontSize: 30),
      ),
    );
  }
}

class _SettingsPage extends StatelessWidget {
  const _SettingsPage();

  @override
  Widget build(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.all(40),
      child: SettingsSection(),
    );
  }
}

class _HelpPage extends StatelessWidget {
  const _HelpPage();

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text(
        "Help & Support",
        style: TextStyle(color: Colors.white, fontSize: 30),
      ),
    );
  }
}

class _LogoutPage extends StatelessWidget {
  const _LogoutPage();

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text(
        "Logout",
        style: TextStyle(color: Colors.red, fontSize: 30),
      ),
    );
  }
}