import 'package:flutter/material.dart';

class WatchlistSection extends StatelessWidget {
  const WatchlistSection({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [

        Row(
          children: [

            const Text(
              "My Watchlist",
              style: TextStyle(
                color: Colors.white,
                fontSize: 28,
                fontWeight: FontWeight.bold,
              ),
            ),

            const Spacer(),

            TextButton.icon(
              onPressed: () {},
              icon: const Icon(Icons.favorite_border),
              label: const Text("View All"),
            ),
          ],
        ),

        const SizedBox(height: 20),

        SizedBox(
          height: 340,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: 12,
            separatorBuilder: (_, __) =>
            const SizedBox(width: 20),
            itemBuilder: (_, index) {
              return WatchlistCard(
                title: "Movie ${index + 1}",
                genre: "Action • Thriller",
                rating: "8.${index}",
                year: "2026",
                duration: "2h 18m",
                image:
                "https://picsum.photos/300/450?random=${index + 100}",
              );
            },
          ),
        ),
      ],
    );
  }
}

class WatchlistCard extends StatefulWidget {
  final String title;
  final String genre;
  final String rating;
  final String duration;
  final String year;
  final String image;

  const WatchlistCard({
    super.key,
    required this.title,
    required this.genre,
    required this.rating,
    required this.duration,
    required this.year,
    required this.image,
  });

  @override
  State<WatchlistCard> createState() =>
      _WatchlistCardState();
}

class _WatchlistCardState extends State<WatchlistCard> {

  bool hover = false;

  @override
  Widget build(BuildContext context) {

    return MouseRegion(

      onEnter: (_) => setState(() => hover = true),

      onExit: (_) => setState(() => hover = false),

      child: AnimatedScale(

        duration: const Duration(milliseconds: 200),

        scale: hover ? 1.05 : 1,

        child: AnimatedContainer(

          duration: const Duration(milliseconds: 250),

          width: 220,

          decoration: BoxDecoration(

            color: Colors.white.withOpacity(.05),

            borderRadius: BorderRadius.circular(22),

            border: Border.all(

              color: hover
                  ? Colors.red
                  : Colors.white10,

              width: hover ? 2 : 1,
            ),

            boxShadow: hover
                ? [
              BoxShadow(
                color: Colors.red.withOpacity(.30),
                blurRadius: 18,
              )
            ]
                : [],
          ),

          child: Column(

            crossAxisAlignment:
            CrossAxisAlignment.start,

            children: [

              Expanded(

                flex: 7,

                child: Stack(

                  children: [

                    ClipRRect(

                      borderRadius:
                      const BorderRadius.vertical(
                        top: Radius.circular(22),
                      ),

                      child: Image.network(

                        widget.image,

                        width: double.infinity,

                        fit: BoxFit.cover,
                      ),
                    ),

                    AnimatedOpacity(

                      opacity: hover ? 1 : 0,

                      duration:
                      const Duration(milliseconds: 200),

                      child: Container(

                        decoration: BoxDecoration(

                          color: Colors.black54,

                          borderRadius:
                          const BorderRadius.vertical(
                            top: Radius.circular(22),
                          ),
                        ),
                      ),
                    ),

                    if (hover)

                      Center(

                        child: Row(

                          mainAxisAlignment:
                          MainAxisAlignment.center,

                          children: [

                            CircleAvatar(

                              radius: 26,

                              backgroundColor: Colors.red,

                              child: IconButton(

                                icon: const Icon(
                                  Icons.play_arrow,
                                  color: Colors.white,
                                ),

                                onPressed: () {},
                              ),
                            ),

                            const SizedBox(width: 15),

                            CircleAvatar(

                              radius: 26,

                              backgroundColor:
                              Colors.white24,

                              child: IconButton(

                                icon: const Icon(
                                  Icons.delete_outline,
                                  color: Colors.white,
                                ),

                                onPressed: () {},
                              ),
                            ),
                          ],
                        ),
                      ),

                    Positioned(

                      top: 12,

                      right: 12,

                      child: Container(

                        padding:
                        const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 5,
                        ),

                        decoration: BoxDecoration(

                          color: Colors.black87,

                          borderRadius:
                          BorderRadius.circular(20),
                        ),

                        child: Row(

                          children: [

                            const Icon(
                              Icons.star,
                              color: Colors.amber,
                              size: 16,
                            ),

                            const SizedBox(width: 4),

                            Text(
                              widget.rating,
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight:
                                FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              Expanded(

                flex: 3,

                child: Padding(

                  padding: const EdgeInsets.all(14),

                  child: Column(

                    crossAxisAlignment:
                    CrossAxisAlignment.start,

                    children: [

                      Text(

                        widget.title,

                        maxLines: 1,

                        overflow: TextOverflow.ellipsis,

                        style: const TextStyle(

                          color: Colors.white,

                          fontWeight: FontWeight.bold,

                          fontSize: 18,
                        ),
                      ),

                      const SizedBox(height: 6),

                      Text(

                        widget.genre,

                        style: const TextStyle(

                          color: Colors.white60,

                          fontSize: 13,
                        ),
                      ),

                      const Spacer(),

                      Row(

                        children: [

                          const Icon(
                            Icons.calendar_today,
                            color: Colors.white54,
                            size: 14,
                          ),

                          const SizedBox(width: 5),

                          Text(
                            widget.year,
                            style: const TextStyle(
                              color: Colors.white54,
                            ),
                          ),

                          const Spacer(),

                          const Icon(
                            Icons.schedule,
                            color: Colors.white54,
                            size: 14,
                          ),

                          const SizedBox(width: 5),

                          Text(
                            widget.duration,
                            style: const TextStyle(
                              color: Colors.white54,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}