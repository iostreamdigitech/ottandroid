import 'package:flutter/material.dart';
import 'package:ottoneapp/features/profile/widget/summary_card.dart';
import 'package:ottoneapp/features/profile/widget/usage_progress_tile.dart';


class UsageProgressCard extends StatelessWidget {
  const UsageProgressCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: const Color(0xff101C3A),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(
          color: Colors.white10,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [

          Row(
            children: [

              const CircleAvatar(
                radius: 22,
                backgroundColor: Colors.deepPurple,
                child: Icon(
                  Icons.analytics,
                  color: Colors.white,
                ),
              ),

              const SizedBox(width: 14),

              const Expanded(
                child: Text(
                  "Usage Analytics",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),

              IconButton(
                onPressed: () {},
                icon: const Icon(
                  Icons.refresh,
                  color: Colors.white70,
                ),
              )
            ],
          ),

          const SizedBox(height: 28),

          const UsageProgressTile(
            title: "Device Usage",
            value: "3 / 4 Devices",
            progress: .75,
            color: Colors.green,
            icon: Icons.devices,
          ),

          const SizedBox(height: 22),

          const UsageProgressTile(
            title: "Download Storage",
            value: "18.6 GB / 32 GB",
            progress: .58,
            color: Colors.blue,
            icon: Icons.download,
          ),

          const SizedBox(height: 22),

          const UsageProgressTile(
            title: "Monthly Watch Time",
            value: "92 Hours",
            progress: .82,
            color: Colors.orange,
            icon: Icons.movie,
          ),

          const SizedBox(height: 22),

          const UsageProgressTile(
            title: "Offline Downloads",
            value: "12 Movies",
            progress: .60,
            color: Colors.red,
            icon: Icons.cloud_download,
          ),

          const SizedBox(height: 30),

          Row(
            children: [

              Expanded(
                child: SummaryCard(
                  title: "Video Quality",
                  value: "4K UHD",
                  icon: Icons.high_quality,
                  color: Colors.purple,
                ),
              ),

              const SizedBox(width: 15),

              Expanded(
                child: SummaryCard(
                  title: "Screens",
                  value: "2 / 4",
                  icon: Icons.tv,
                  color: Colors.teal,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}