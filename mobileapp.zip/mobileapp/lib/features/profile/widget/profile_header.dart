import 'package:flutter/material.dart';

import '../../../core/utils/device_utils.dart';

class ProfileHeader extends StatelessWidget {
  final String name;
  final String email;
  final String mobile;
  final String? imageUrl;
  final bool isPremium;
  final VoidCallback? onEdit;

  const ProfileHeader({
    super.key,
    this.name = "Sathya Venthan",
    this.email = "sathya@gmail.com",
    this.mobile = "+91 9876543210",
    this.imageUrl,
    this.isPremium = true,
    this.onEdit,
  });

  @override
  Widget build(BuildContext context) {
    final isDesktop = DeviceUtils.isDesktop(context);
    final isTablet = DeviceUtils.isTablet(context);
    final isTV = DeviceUtils.isTV(context);

    final avatarSize = isTV
        ? 140.0
        : isDesktop
        ? 110.0
        : isTablet
        ? 90.0
        : 80.0;

    final titleSize = isTV
        ? 30.0
        : isDesktop
        ? 26.0
        : 22.0;

    final subTitle = isTV
        ? 20.0
        : isDesktop
        ? 16.0
        : 14.0;

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: LinearGradient(
          colors: [
            Colors.white.withOpacity(.08),
            Colors.white.withOpacity(.03),
          ],
        ),
        border: Border.all(
          color: Colors.white10,
        ),
      ),
      child: isDesktop || isTV
          ? Row(
        children: [
          _avatar(avatarSize),
          const SizedBox(width: 30),
          Expanded(
            child: _details(
              titleSize,
              subTitle,
            ),
          ),
          _editButton(context),
        ],
      )
          : Column(
        children: [
          _avatar(avatarSize),
          const SizedBox(height: 18),
          _details(
            titleSize,
            subTitle,
            center: true,
          ),
          const SizedBox(height: 18),
          _editButton(context),
        ],
      ),
    );
  }

  Widget _avatar(double size) {
    return Stack(
      children: [
        CircleAvatar(
          radius: size / 2,
          backgroundColor: Colors.white12,
          backgroundImage:
          imageUrl != null ? NetworkImage(imageUrl!) : null,
          child: imageUrl == null
              ? Icon(
            Icons.person,
            color: Colors.white,
            size: size * .5,
          )
              : null,
        ),

        Positioned(
          bottom: 4,
          right: 4,
          child: Container(
            width: 18,
            height: 18,
            decoration: BoxDecoration(
              color: Colors.green,
              shape: BoxShape.circle,
              border: Border.all(
                color: Colors.white,
                width: 2,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _details(
      double title,
      double subTitle, {
        bool center = false,
      }) {
    return Column(
      crossAxisAlignment: center
          ? CrossAxisAlignment.center
          : CrossAxisAlignment.start,
      children: [

        Text(
          name,
          textAlign: center ? TextAlign.center : TextAlign.left,
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: title,
          ),
        ),

        const SizedBox(height: 6),

        Text(
          email,
          style: TextStyle(
            color: Colors.white70,
            fontSize: subTitle,
          ),
        ),

        const SizedBox(height: 6),

        Text(
          mobile,
          style: TextStyle(
            color: Colors.white70,
            fontSize: subTitle,
          ),
        ),

        const SizedBox(height: 12),

        if (isPremium)
          Container(
            padding: const EdgeInsets.symmetric(
              horizontal: 14,
              vertical: 8,
            ),
            decoration: BoxDecoration(
              color: Colors.amber.withOpacity(.15),
              borderRadius: BorderRadius.circular(20),
            ),
            child: const Row(
              mainAxisSize: MainAxisSize.min,
              children: [

                Icon(
                  Icons.workspace_premium,
                  color: Colors.amber,
                  size: 18,
                ),

                SizedBox(width: 6),

                Text(
                  "Premium Member",
                  style: TextStyle(
                    color: Colors.amber,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
      ],
    );
  }

  Widget _editButton(BuildContext context) {
    return ElevatedButton.icon(
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.red,
        padding: const EdgeInsets.symmetric(
          horizontal: 20,
          vertical: 14,
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
      ),
      onPressed: onEdit,
      icon: const Icon(Icons.edit),
      label: const Text("Edit Profile"),
    );
  }
}