import 'package:flutter/material.dart';

class CurrentPlanCard extends StatelessWidget {
  const CurrentPlanCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(28),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xff4F46E5),
            Color(0xff2563EB),
            Color(0xff0EA5E9),
          ],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.blue.withOpacity(.25),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [

          Row(
            children: [

              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 8,
                ),
                decoration: BoxDecoration(
                  color: Colors.amber,
                  borderRadius: BorderRadius.circular(30),
                ),
                child: const Row(
                  children: [
                    Icon(
                      Icons.workspace_premium,
                      color: Colors.black,
                      size: 18,
                    ),
                    SizedBox(width: 6),
                    Text(
                      "PREMIUM",
                      style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),

              const Spacer(),

              IconButton(
                onPressed: () {},
                icon: const Icon(
                  Icons.more_vert,
                  color: Colors.white,
                ),
              ),
            ],
          ),

          const SizedBox(height: 25),

          const Text(
            "Premium Family",
            style: TextStyle(
              color: Colors.white,
              fontSize: 30,
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 8),

          const Text(
            "Unlimited Entertainment",
            style: TextStyle(
              color: Colors.white70,
              fontSize: 16,
            ),
          ),

          const SizedBox(height: 28),

          const Row(
            children: [

              Expanded(
                child: _PlanInfo(
                  icon: Icons.currency_rupee,
                  title: "Price",
                  value: "₹999 / Year",
                ),
              ),

              Expanded(
                child: _PlanInfo(
                  icon: Icons.calendar_today,
                  title: "Renewal",
                  value: "31 Dec 2026",
                ),
              ),
            ],
          ),

          const SizedBox(height: 20),

          const Divider(color: Colors.white24),

          const SizedBox(height: 20),

          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: const [

              _FeatureChip("4K UHD", Icons.high_quality),
              _FeatureChip("HDR10+", Icons.hdr_strong),
              _FeatureChip("Dolby Atmos", Icons.surround_sound),
              _FeatureChip("4 Devices", Icons.devices),
              _FeatureChip("4 Screens", Icons.tv),
              _FeatureChip("Unlimited Download", Icons.download),
              _FeatureChip("No Ads", Icons.block),
              _FeatureChip("Offline Viewing", Icons.cloud_download),
            ],
          ),

          const SizedBox(height: 30),

          Row(
            children: [

              Expanded(
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: Colors.blue,
                    padding: const EdgeInsets.symmetric(
                      vertical: 16,
                    ),
                  ),
                  onPressed: () {},
                  icon: const Icon(Icons.upgrade),
                  label: const Text(
                    "Upgrade",
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),

              const SizedBox(width: 16),

              Expanded(
                child: OutlinedButton.icon(
                  style: OutlinedButton.styleFrom(
                    foregroundColor: Colors.white,
                    side: const BorderSide(
                      color: Colors.white54,
                    ),
                    padding: const EdgeInsets.symmetric(
                      vertical: 16,
                    ),
                  ),
                  onPressed: () {},
                  icon: const Icon(Icons.settings),
                  label: const Text("Manage"),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _PlanInfo extends StatelessWidget {
  final IconData icon;
  final String title;
  final String value;

  const _PlanInfo({
    required this.icon,
    required this.title,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [

        CircleAvatar(
          radius: 22,
          backgroundColor: Colors.white24,
          child: Icon(
            icon,
            color: Colors.white,
            size: 20,
          ),
        ),

        const SizedBox(width: 12),

        Expanded(
          child: Column(
            crossAxisAlignment:
            CrossAxisAlignment.start,
            children: [

              Text(
                title,
                style: const TextStyle(
                  color: Colors.white60,
                  fontSize: 13,
                ),
              ),

              const SizedBox(height: 4),

              Text(
                value,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 15,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _FeatureChip extends StatelessWidget {
  final String title;
  final IconData icon;

  const _FeatureChip(
      this.title,
      this.icon,
      );

  @override
  Widget build(BuildContext context) {
    return Chip(
      avatar: Icon(
        icon,
        color: Colors.white,
        size: 18,
      ),
      label: Text(title),
      backgroundColor: Colors.white.withOpacity(.12),
      labelStyle: const TextStyle(
        color: Colors.white,
      ),
      side: BorderSide.none,
    );
  }
}