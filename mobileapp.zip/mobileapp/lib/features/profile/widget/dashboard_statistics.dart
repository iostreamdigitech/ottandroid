import 'package:flutter/material.dart';

class DashboardStatistics extends StatelessWidget {
  const DashboardStatistics({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: const [
        Expanded(
          child: DashboardStatCard(
            title: "Total Hours Watched",
            value: "128 Hrs",
            icon: Icons.schedule,
            color: Color(0xff3B82F6),
            trend: "+12%",
          ),
        ),

        SizedBox(width: 20),
        Expanded(
          child: DashboardStatCard(
            title: "Watchlist",
            value: "86",
            icon: Icons.favorite_outline,
            color: Color(0xffEC4899),
            trend: "+5%",
          ),
        ),
        SizedBox(width: 20),
        Expanded(
          child: DashboardStatCard(
            title: "Devices",
            value: "3",
            icon: Icons.devices_other,
            color: Color(0xff10B981),
            trend: "Active",
          ),
        ),
      ],
    );
  }
}

class DashboardStatCard extends StatefulWidget {
  final String title;
  final String value;
  final String trend;
  final IconData icon;
  final Color color;

  const DashboardStatCard({
    super.key,
    required this.title,
    required this.value,
    required this.trend,
    required this.icon,
    required this.color,
  });

  @override
  State<DashboardStatCard> createState() =>
      _DashboardStatCardState();
}

class _DashboardStatCardState
    extends State<DashboardStatCard> {
  bool hover = false;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      onEnter: (_) => setState(() => hover = true),
      onExit: (_) => setState(() => hover = false),
      child: AnimatedScale(
        duration: const Duration(milliseconds: 180),
        scale: hover ? 1.03 : 1,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          height: 165,
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(24),
            gradient: LinearGradient(
              colors: [
                widget.color.withOpacity(.18),
                Colors.white.withOpacity(.03),
              ],
            ),
            border: Border.all(
              color: hover
                  ? widget.color
                  : Colors.white12,
              width: hover ? 2 : 1,
            ),
            boxShadow: hover
                ? [
              BoxShadow(
                color:
                widget.color.withOpacity(.35),
                blurRadius: 24,
                offset: const Offset(0, 10),
              )
            ]
                : [],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  CircleAvatar(
                    radius: 22,
                    backgroundColor: widget.color.withOpacity(.18),
                    child: Icon(
                      widget.icon,
                      color: widget.color,
                    ),
                  ),
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.green.withOpacity(.15),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      widget.trend,
                      style: const TextStyle(
                        color: Colors.green,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.value,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 30,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    widget.title,
                    style: const TextStyle(
                      color: Colors.white70,
                      fontSize: 14,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}