import 'package:flutter/material.dart';

import '../../../core/utils/device_utils.dart';



class SubscriptionCardProfile extends StatelessWidget {
  final String planName;
  final String expiryDate;
  final String videoQuality;
  final int devices;
  final int screens;
  final VoidCallback? onUpgrade;

  const SubscriptionCardProfile({
    super.key,
    this.planName = "Premium",
    this.expiryDate = "31 Dec 2026",
    this.videoQuality = "4K UHD",
    this.devices = 4,
    this.screens = 4,
    this.onUpgrade,
  });

  @override
  Widget build(BuildContext context) {
    final isDesktop = DeviceUtils.isDesktop(context);
    final isTV = DeviceUtils.isTV(context);

    final titleSize = isTV
        ? 32.0
        : isDesktop
        ? 26.0
        : 20.0;

    final bodySize = isTV
        ? 20.0
        : isDesktop
        ? 16.0
        : 14.0;

    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: const LinearGradient(
          colors: [
            Color(0xff4A148C),
            Color(0xff1A237E),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(.35),
            blurRadius: 20,
            offset: const Offset(0, 12),
          )
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [

          Row(
            children: [

              const Icon(
                Icons.workspace_premium,
                color: Colors.amber,
                size: 34,
              ),

              const SizedBox(width: 12),

              Expanded(
                child: Column(
                  crossAxisAlignment:
                  CrossAxisAlignment.start,
                  children: [

                    Text(
                      planName,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: titleSize,
                        fontWeight: FontWeight.bold,
                      ),
                    ),

                    const SizedBox(height: 4),

                    Text(
                      "Active Subscription",
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: bodySize,
                      ),
                    ),
                  ],
                ),
              ),

              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.amber,
                  foregroundColor: Colors.black,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 18,
                    vertical: 14,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius:
                    BorderRadius.circular(14),
                  ),
                ),
                onPressed: onUpgrade,
                child: const Text(
                  "Upgrade",
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              )
            ],
          ),

          const SizedBox(height: 25),

          Row(
            children: [

              Expanded(
                child: _infoCard(
                  Icons.calendar_month,
                  "Expiry",
                  expiryDate,
                ),
              ),

              const SizedBox(width: 12),

              Expanded(
                child: _infoCard(
                  Icons.high_quality,
                  "Quality",
                  videoQuality,
                ),
              ),
            ],
          ),

          const SizedBox(height: 12),

          Row(
            children: [

              Expanded(
                child: _infoCard(
                  Icons.devices,
                  "Devices",
                  "$devices Devices",
                ),
              ),

              const SizedBox(width: 12),

              Expanded(
                child: _infoCard(
                  Icons.tv,
                  "Screens",
                  "$screens Screens",
                ),
              ),
            ],
          ),

          const SizedBox(height: 25),

          const Divider(
            color: Colors.white24,
          ),

          const SizedBox(height: 20),

          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: const [

              FeatureChip("Ad Free"),

              FeatureChip("4K UHD"),

              FeatureChip("Dolby Audio"),

              FeatureChip("Offline Download"),

              FeatureChip("Unlimited Streaming"),
            ],
          ),
        ],
      ),
    );
  }

  Widget _infoCard(
      IconData icon,
      String title,
      String value,
      ) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.08),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        children: [

          Icon(
            icon,
            color: Colors.white,
          ),

          const SizedBox(height: 8),

          Text(
            title,
            style: const TextStyle(
              color: Colors.white70,
            ),
          ),

          const SizedBox(height: 4),

          Text(
            value,
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}

class FeatureChip extends StatelessWidget {
  final String title;

  const FeatureChip(
      this.title, {
        super.key,
      });

  @override
  Widget build(BuildContext context) {
    return Chip(
      backgroundColor: Colors.white12,
      avatar: const Icon(
        Icons.check_circle,
        color: Colors.green,
        size: 18,
      ),
      label: Text(
        title,
        style: const TextStyle(
          color: Colors.white,
        ),
      ),
    );
  }
}