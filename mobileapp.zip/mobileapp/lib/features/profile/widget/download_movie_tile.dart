import 'package:flutter/material.dart';

class DownloadMovieTile extends StatefulWidget {
  final String title;
  final String image;
  final String quality;
  final String size;
  final double progress;
  final bool completed;

  const DownloadMovieTile({
    super.key,
    required this.title,
    required this.image,
    required this.quality,
    required this.size,
    required this.progress,
    this.completed = false,
  });

  @override
  State<DownloadMovieTile> createState() =>
      _DownloadMovieTileState();
}

class _DownloadMovieTileState
    extends State<DownloadMovieTile> {

  bool hover = false;

  @override
  Widget build(BuildContext context) {

    return MouseRegion(

      onEnter: (_) => setState(() => hover = true),

      onExit: (_) => setState(() => hover = false),

      child: AnimatedContainer(

        duration: const Duration(milliseconds: 200),

        margin: const EdgeInsets.only(bottom: 18),

        padding: const EdgeInsets.all(14),

        decoration: BoxDecoration(

          color: hover
              ? Colors.white.withOpacity(.06)
              : Colors.transparent,

          borderRadius: BorderRadius.circular(18),

          border: Border.all(

            color: hover
                ? Colors.blue
                : Colors.white10,
          ),
        ),

        child: Row(

          children: [

            /// Poster

            Stack(

              children: [

                ClipRRect(

                  borderRadius:
                  BorderRadius.circular(14),

                  child: Image.network(

                    widget.image,

                    width: 72,

                    height: 100,

                    fit: BoxFit.cover,
                  ),
                ),

                Positioned(

                  top: 6,

                  right: 6,

                  child: Container(

                    padding:
                    const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 4,
                    ),

                    decoration: BoxDecoration(

                      color: Colors.black87,

                      borderRadius:
                      BorderRadius.circular(12),
                    ),

                    child: Text(

                      widget.quality,

                      style: const TextStyle(

                        color: Colors.amber,

                        fontWeight:
                        FontWeight.bold,

                        fontSize: 11,
                      ),
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(width: 18),

            /// Details

            Expanded(

              child: Column(

                crossAxisAlignment:
                CrossAxisAlignment.start,

                children: [

                  Text(

                    widget.title,

                    maxLines: 1,

                    overflow:
                    TextOverflow.ellipsis,

                    style: const TextStyle(

                      color: Colors.white,

                      fontWeight:
                      FontWeight.bold,

                      fontSize: 17,
                    ),
                  ),

                  const SizedBox(height: 6),

                  Text(

                    widget.size,

                    style: const TextStyle(

                      color: Colors.white60,
                    ),
                  ),

                  const SizedBox(height: 12),

                  ClipRRect(

                    borderRadius:
                    BorderRadius.circular(30),

                    child: LinearProgressIndicator(

                      value: widget.progress,

                      minHeight: 6,

                      backgroundColor:
                      Colors.white12,

                      color: widget.completed
                          ? Colors.green
                          : Colors.blue,
                    ),
                  ),

                  const SizedBox(height: 8),

                  Text(

                    widget.completed
                        ? "Downloaded"
                        : "${(widget.progress * 100).toInt()}% Downloaded",

                    style: TextStyle(

                      color: widget.completed
                          ? Colors.green
                          : Colors.white60,

                      fontSize: 13,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(width: 12),

            /// Actions

            Column(

              mainAxisAlignment:
              MainAxisAlignment.center,

              children: [

                IconButton(

                  tooltip: widget.completed
                      ? "Play"
                      : "Pause",

                  onPressed: () {},

                  icon: Icon(

                    widget.completed
                        ? Icons.play_circle_fill
                        : Icons.pause_circle_outline,

                    color: widget.completed
                        ? Colors.green
                        : Colors.white,
                  ),
                ),

                IconButton(

                  tooltip: "Delete",

                  onPressed: () {},

                  icon: const Icon(

                    Icons.delete_outline,

                    color: Colors.red,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}