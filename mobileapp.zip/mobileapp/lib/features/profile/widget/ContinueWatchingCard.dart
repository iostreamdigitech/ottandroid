import 'package:flutter/material.dart';

class ContinueWatchingCard extends StatefulWidget {
  final String image;
  final String title;
  final String subtitle;
  final double progress;
  final String remainingTime;
  final String quality;
  final String duration;

  const ContinueWatchingCard({
    super.key,
    required this.image,
    required this.title,
    required this.subtitle,
    required this.progress,
    required this.remainingTime,
    required this.quality,
    required this.duration,
  });

  @override
  State<ContinueWatchingCard> createState() =>
      _ContinueWatchingCardState();
}

class _ContinueWatchingCardState extends State<ContinueWatchingCard> {
  bool hover = false;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      onEnter: (_) => setState(() => hover = true),
      onExit: (_) => setState(() => hover = false),
      child: AnimatedScale(
        duration: const Duration(milliseconds: 200),
        scale: hover ? 1.03 : 1,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          width: 240,
          height: 360,
          decoration: BoxDecoration(
            color: const Color(0xff101C3A),
            borderRadius: BorderRadius.circular(22),
            border: Border.all(
              color: hover ? Colors.red : Colors.white12,
              width: hover ? 2 : 1,
            ),
            boxShadow: hover
                ? [
              BoxShadow(
                color: Colors.red.withOpacity(.25),
                blurRadius: 20,
                offset: const Offset(0, 10),
              )
            ]
                : [],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [

              /// Poster
              SizedBox(
                height: 205,
                width: double.infinity,
                child: Stack(
                  fit: StackFit.expand,
                  children: [

                    ClipRRect(
                      borderRadius: const BorderRadius.vertical(
                        top: Radius.circular(22),
                      ),
                      child: Image.network(
                        widget.image,
                        fit: BoxFit.cover,
                      ),
                    ),

                    AnimatedOpacity(
                      duration: const Duration(milliseconds: 200),
                      opacity: hover ? 1 : 0,
                      child: Container(
                        color: Colors.black54,
                      ),
                    ),

                    if (hover)
                      Center(
                        child: CircleAvatar(
                          radius: 32,
                          backgroundColor: Colors.red,
                          child: IconButton(
                            onPressed: () {},
                            icon: const Icon(
                              Icons.play_arrow,
                              size: 36,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),

                    Positioned(
                      top: 12,
                      right: 12,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 4,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.black87,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          widget.quality,
                          style: const TextStyle(
                            color: Colors.amber,
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              /// Content
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment:
                    MainAxisAlignment.spaceBetween,
                    children: [

                      Text(
                        widget.title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 17,
                        ),
                      ),

                      Text(
                        widget.subtitle,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Colors.white60,
                          fontSize: 13,
                        ),
                      ),

                      ClipRRect(
                        borderRadius:
                        BorderRadius.circular(30),
                        child: LinearProgressIndicator(
                          value: widget.progress,
                          minHeight: 6,
                          backgroundColor: Colors.white12,
                          color: Colors.red,
                        ),
                      ),

                      Row(
                        children: [
                          const Icon(
                            Icons.schedule,
                            color: Colors.white54,
                            size: 15,
                          ),

                          const SizedBox(width: 5),

                          Expanded(
                            child: Text(
                              widget.remainingTime,
                              overflow:
                              TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: Colors.white60,
                                fontSize: 12,
                              ),
                            ),
                          ),

                          Text(
                            widget.duration,
                            style: const TextStyle(
                              color: Colors.white54,
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}