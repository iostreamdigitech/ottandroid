import 'package:flutter/material.dart';
import 'package:ottoneapp/features/profile/widget/registered_devices_panel.dart';

import 'downloads_panel.dart';


class DownloadsDevicesSection extends StatelessWidget {
  const DownloadsDevicesSection({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: const [

        Expanded(
          flex: 3,
          child: DownloadsPanel(),
        ),

        SizedBox(width: 24),

        Expanded(
          flex: 2,
          child: RegisteredDevicesPanel(),
        ),
      ],
    );
  }
}