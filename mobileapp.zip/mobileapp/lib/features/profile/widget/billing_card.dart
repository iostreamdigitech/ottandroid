import 'package:flutter/material.dart';

class BillingCard extends StatelessWidget {
  const BillingCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: const Color(0xff101C3A),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(
          color: Colors.white10,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [

          Row(
            children: [

              const CircleAvatar(
                radius: 22,
                backgroundColor: Colors.green,
                child: Icon(
                  Icons.receipt_long,
                  color: Colors.white,
                ),
              ),

              const SizedBox(width: 14),

              const Expanded(
                child: Text(
                  "Billing Information",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),

              IconButton(
                onPressed: () {},
                icon: const Icon(
                  Icons.more_vert,
                  color: Colors.white,
                ),
              )
            ],
          ),

          const SizedBox(height: 25),

          const BillingInfoRow(
            icon: Icons.credit_card,
            title: "Payment Method",
            value: "Visa •••• 4258",
          ),

          const BillingInfoRow(
            icon: Icons.currency_rupee,
            title: "Plan Amount",
            value: "₹999 / Year",
          ),

          const BillingInfoRow(
            icon: Icons.calendar_today,
            title: "Next Billing",
            value: "31 Dec 2026",
          ),

          const BillingInfoRow(
            icon: Icons.receipt,
            title: "Invoice",
            value: "#INV-202600124",
          ),

          const BillingInfoRow(
            icon: Icons.autorenew,
            title: "Auto Renewal",
            value: "Enabled",
          ),

          const BillingInfoRow(
            icon: Icons.verified,
            title: "Status",
            value: "Active",
            valueColor: Colors.green,
          ),

          const SizedBox(height: 25),

          const Divider(
            color: Colors.white12,
          ),

          const SizedBox(height: 20),

          Row(
            children: [

              Expanded(
                child: ElevatedButton.icon(
                  onPressed: () {},
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue,
                    padding: const EdgeInsets.symmetric(
                      vertical: 16,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius:
                      BorderRadius.circular(14),
                    ),
                  ),
                  icon: const Icon(Icons.download),
                  label: const Text(
                    "Invoice",
                  ),
                ),
              ),

              const SizedBox(width: 15),

              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () {},
                  style: OutlinedButton.styleFrom(
                    foregroundColor: Colors.white,
                    side: const BorderSide(
                      color: Colors.white30,
                    ),
                    padding: const EdgeInsets.symmetric(
                      vertical: 16,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius:
                      BorderRadius.circular(14),
                    ),
                  ),
                  icon: const Icon(Icons.edit),
                  label: const Text(
                    "Change Card",
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class BillingInfoRow extends StatelessWidget {

  final IconData icon;
  final String title;
  final String value;
  final Color valueColor;

  const BillingInfoRow({
    super.key,
    required this.icon,
    required this.title,
    required this.value,
    this.valueColor = Colors.white,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 18),
      child: Row(
        children: [

          CircleAvatar(
            radius: 18,
            backgroundColor: Colors.white10,
            child: Icon(
              icon,
              size: 18,
              color: Colors.white70,
            ),
          ),

          const SizedBox(width: 14),

          Expanded(
            child: Column(
              crossAxisAlignment:
              CrossAxisAlignment.start,
              children: [

                Text(
                  title,
                  style: const TextStyle(
                    color: Colors.white60,
                    fontSize: 13,
                  ),
                ),

                const SizedBox(height: 3),

                Text(
                  value,
                  style: TextStyle(
                    color: valueColor,
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}