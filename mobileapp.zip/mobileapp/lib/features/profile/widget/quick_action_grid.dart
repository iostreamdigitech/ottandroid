import 'package:flutter/material.dart';

import '../../../core/utils/device_utils.dart';

class QuickActionGrid extends StatelessWidget {
  const QuickActionGrid({super.key});

  @override
  Widget build(BuildContext context) {
    final actions = <QuickActionItem>[
      QuickActionItem(
        title: "Continue Watching",
        subtitle: "Resume playback",
        icon: Icons.play_circle_fill,
        color: Colors.red,
        onTap: () {},
      ),
      QuickActionItem(
        title: "My Watchlist",
        subtitle: "Saved movies",
        icon: Icons.favorite,
        color: Colors.pink,
        onTap: () {},
      ),
      QuickActionItem(
        title: "Downloads",
        subtitle: "Offline videos",
        icon: Icons.download,
        color: Colors.blue,
        onTap: () {},
      ),
      QuickActionItem(
        title: "Devices",
        subtitle: "Manage devices",
        icon: Icons.devices,
        color: Colors.green,
        onTap: () {},
      ),
      QuickActionItem(
        title: "Watch History",
        subtitle: "Recently watched",
        icon: Icons.history,
        color: Colors.orange,
        onTap: () {},
      ),
      QuickActionItem(
        title: "Notifications",
        subtitle: "Latest updates",
        icon: Icons.notifications,
        color: Colors.amber,
        onTap: () {},
      ),
      QuickActionItem(
        title: "Language",
        subtitle: "Audio & subtitles",
        icon: Icons.language,
        color: Colors.teal,
        onTap: () {},
      ),
      QuickActionItem(
        title: "Settings",
        subtitle: "Preferences",
        icon: Icons.settings,
        color: Colors.deepPurple,
        onTap: () {},
      ),
    ];

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: actions.length,
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: DeviceUtils.gridCount(context),
        crossAxisSpacing: 16,
        mainAxisSpacing: 16,
          childAspectRatio:
          DeviceUtils.isMobile(context)
              ? 1.0
              : DeviceUtils.isTablet(context)
              ? 1.15
              : 0.95,
      ),
      itemBuilder: (_, index) {
        return QuickActionCard(
          item: actions[index],
        );
      },
    );
  }
}

class QuickActionItem {
  final String title;
  final String subtitle;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  QuickActionItem({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.color,
    required this.onTap,
  });
}

class QuickActionCard extends StatefulWidget {
  final QuickActionItem item;

  const QuickActionCard({
    super.key,
    required this.item,
  });

  @override
  State<QuickActionCard> createState() =>
      _QuickActionCardState();
}

class _QuickActionCardState
    extends State<QuickActionCard> {

  bool focused = false;

  @override
  Widget build(BuildContext context) {
    final isTV = DeviceUtils.isTV(context);

    return Focus(
      onFocusChange: (value) {
        setState(() {
          focused = value;
        });
      },
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: widget.item.onTap,
        child: AnimatedContainer(
          duration:
          const Duration(milliseconds: 250),
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: focused
                ? Colors.white12
                : Colors.white.withOpacity(.05),
            borderRadius:
            BorderRadius.circular(20),
            border: Border.all(
              color: focused
                  ? widget.item.color
                  : Colors.white10,
              width: focused ? 2 : 1,
            ),
            boxShadow: focused
                ? [
              BoxShadow(
                color: widget.item.color
                    .withOpacity(.35),
                blurRadius: 20,
              )
            ]
                : [],
          ),
          child: Column(
            mainAxisAlignment:
            MainAxisAlignment.center,
            children: [

              CircleAvatar(
                radius: isTV ? 34 : 28,
                backgroundColor:
                widget.item.color.withOpacity(.18),
                child: Icon(
                  widget.item.icon,
                  color: widget.item.color,
                  size: isTV ? 34 : 28,
                ),
              ),

              const SizedBox(height: 16),

              Text(
                widget.item.title,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: isTV ? 22 : 16,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 8),

              Text(
                widget.item.subtitle,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white60,
                  fontSize: isTV ? 16 : 12,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}