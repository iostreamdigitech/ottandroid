import 'package:flutter/material.dart';

import '../../../core/utils/device_utils.dart';
import 'ContinueWatchingCard.dart';

class ContinueWatchingSection extends StatelessWidget {
  const ContinueWatchingSection({super.key});

  @override
  Widget build(BuildContext context) {
    final isDesktop = DeviceUtils.isDesktop(context);
    final isTablet = DeviceUtils.isTablet(context);

    final double cardWidth =
    isDesktop ? 260 : isTablet ? 220 : 180;

    final double cardHeight =
    isDesktop ? 390 : isTablet ? 340 : 300;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [

        /// Header
        Row(
          children: [

            Container(
              width: 5,
              height: 32,
              decoration: BoxDecoration(
                color: Colors.red,
                borderRadius: BorderRadius.circular(10),
              ),
            ),

            const SizedBox(width: 12),

            const Expanded(
              child: Text(
                "Continue Watching",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 30,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),

            TextButton.icon(
              onPressed: () {},
              icon: const Icon(Icons.arrow_forward),
              label: const Text("View All"),
            ),
          ],
        ),

        const SizedBox(height: 22),

        /// Cards
        SizedBox(
          height: cardHeight,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            itemCount: 10,
            itemBuilder: (_, index) {
              return Padding(
                padding: EdgeInsets.only(
                  right: index == 9 ? 0 : 20,
                ),
                child: SizedBox(
                  width: cardWidth,
                  child: ContinueWatchingCard(
                    image:
                    "https://picsum.photos/500/750?random=$index",
                    title: "Movie ${index + 1}",
                    subtitle: "Episode ${index + 3}",
                    progress: (index + 2) / 12,
                    remainingTime:
                    "${18 + index} mins left",
                    quality: index.isEven ? "4K" : "HD",
                    duration:
                    "${2 + index % 2}h ${(10 + index * 3)}m",
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}