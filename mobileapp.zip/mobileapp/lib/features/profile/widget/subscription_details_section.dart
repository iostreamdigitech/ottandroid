import 'package:flutter/material.dart';
import 'package:ottoneapp/features/profile/widget/usage_progress_card.dart';


import 'billing_card.dart';
import 'current_planCard.dart';

class SubscriptionDetailsSection extends StatelessWidget {
  const SubscriptionDetailsSection({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(28),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.04),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(
          color: Colors.white10,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [

          Row(
            children: [

              const Icon(
                Icons.workspace_premium,
                color: Colors.amber,
                size: 30,
              ),

              const SizedBox(width: 12),

              const Text(
                "Subscription Details",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const Spacer(),

              ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 22,
                    vertical: 16,
                  ),
                ),
                onPressed: () {},
                icon: const Icon(Icons.upgrade),
                label: const Text("Upgrade Plan"),
              )
            ],
          ),

          const SizedBox(height: 30),

          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: const [

              Expanded(
                flex: 3,
                child: CurrentPlanCard(),
              ),

              SizedBox(width: 24),

              Expanded(
                flex: 2,
                child: BillingCard(),
              ),
            ],
          ),

          const SizedBox(height: 25),

          const Text(
            "Streaming Usage",
            style: TextStyle(
              color: Colors.white,
              fontSize: 22,
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 18),

          const UsageProgressCard(),
        ],
      ),
    );
  }
}