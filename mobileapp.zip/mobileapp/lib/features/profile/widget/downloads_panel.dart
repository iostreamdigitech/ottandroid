import 'package:flutter/material.dart';

import 'download_movie_tile.dart';



class DownloadsPanel extends StatelessWidget {
  const DownloadsPanel({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: const Color(0xff101C3A),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: Colors.white10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [

          /// Header
          Row(
            children: [

              const CircleAvatar(
                radius: 22,
                backgroundColor: Colors.blue,
                child: Icon(
                  Icons.download,
                  color: Colors.white,
                ),
              ),

              const SizedBox(width: 15),

              const Expanded(
                child: Column(
                  crossAxisAlignment:
                  CrossAxisAlignment.start,
                  children: [

                    Text(
                      "Downloads",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                      ),
                    ),

                    SizedBox(height: 4),

                    Text(
                      "12 Movies • 18.6 GB",
                      style: TextStyle(
                        color: Colors.white60,
                      ),
                    ),
                  ],
                ),
              ),

              OutlinedButton.icon(
                onPressed: () {},
                icon: const Icon(Icons.delete_outline),
                label: const Text("Clear"),
              ),
            ],
          ),

          const SizedBox(height: 25),

          /// Storage
          const Text(
            "Storage Used",
            style: TextStyle(
              color: Colors.white70,
            ),
          ),

          const SizedBox(height: 10),

          ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: const LinearProgressIndicator(
              value: .72,
              minHeight: 10,
              backgroundColor: Colors.white12,
              color: Colors.blue,
            ),
          ),

          const SizedBox(height: 8),

          const Align(
            alignment: Alignment.centerRight,
            child: Text(
              "18.6 GB / 32 GB",
              style: TextStyle(
                color: Colors.white54,
              ),
            ),
          ),

          const SizedBox(height: 30),

          ...List.generate(
            5,
                (index) => DownloadMovieTile(
              title: "Movie ${index + 1}",
              size: "${1.5 + index} GB",
              progress: 0.35 + (index * .1),
              image:
              "https://picsum.photos/200/300?random=$index", quality: '',
            ),
          ),
        ],
      ),
    );
  }
}