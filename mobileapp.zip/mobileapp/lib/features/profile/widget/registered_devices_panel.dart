import 'package:flutter/material.dart';

import '../models/DeviceModel.dart';
import 'device_tile.dart';


class RegisteredDevicesPanel extends StatelessWidget {
  const RegisteredDevicesPanel({super.key});

  @override
  Widget build(BuildContext context) {
    final List<DeviceModel> demoDevices = [
      DeviceModel(
        icon: Icons.phone_android,
        name: "Samsung Galaxy S24",
        platform: "Android 15",
        lastLogin: "Now",
        current: true,
      ),
      DeviceModel(
        icon: Icons.tv,
        name: "Android TV",
        platform: "Google TV",
        lastLogin: "Today",
        current: false,
      ),
      DeviceModel(
        icon: Icons.laptop_mac,
        name: "MacBook Pro",
        platform: "macOS",
        lastLogin: "Yesterday",
        current: false,
      ),
    ];
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: const Color(0xff101C3A),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(
          color: Colors.white10,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [

          Row(
            children: [

              const CircleAvatar(
                radius: 22,
                backgroundColor: Colors.green,
                child: Icon(
                  Icons.devices,
                  color: Colors.white,
                ),
              ),

              const SizedBox(width: 15),

              const Expanded(
                child: Column(
                  crossAxisAlignment:
                  CrossAxisAlignment.start,
                  children: [

                    Text(
                      "Registered Devices",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                      ),
                    ),

                    SizedBox(height: 4),

                    Text(
                      "3 of 4 Devices Used",
                      style: TextStyle(
                        color: Colors.white60,
                      ),
                    ),
                  ],
                ),
              ),

              FilledButton.icon(
                onPressed: () {},
                icon: const Icon(Icons.add),
                label: const Text("Add"),
              )
            ],
          ),

          const SizedBox(height: 25),

          ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: const LinearProgressIndicator(
              value: .75,
              minHeight: 8,
              color: Colors.green,
              backgroundColor: Colors.white12,
            ),
          ),

          const SizedBox(height: 10),

          const Align(
            alignment: Alignment.centerRight,
            child: Text(
              "3 / 4 Devices",
              style: TextStyle(
                color: Colors.white54,
              ),
            ),
          ),

          const SizedBox(height: 25),

          ...List.generate(
            demoDevices.length,
                (index) => DeviceTile(
              device: demoDevices[index],
            ),
          ),
        ],
      ),
    );
  }
}