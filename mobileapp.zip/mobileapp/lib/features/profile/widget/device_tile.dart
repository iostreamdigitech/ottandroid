import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../models/DeviceModel.dart';

class DeviceTile extends StatelessWidget {
  final DeviceModel device;

  const DeviceTile({
    super.key,
    required this.device,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(device.icon),
      title: Text(device.name),
      subtitle: Text(device.platform),
    );
  }
}