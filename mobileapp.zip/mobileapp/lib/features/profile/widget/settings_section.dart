import 'package:flutter/material.dart';

import '../../../core/utils/device_utils.dart';

class SettingsSection extends StatelessWidget {
  const SettingsSection({super.key});

  @override
  Widget build(BuildContext context) {
    final settings = <SettingItem>[
      SettingItem(
        title: "Notifications",
        subtitle: "Push notifications",
        icon: Icons.notifications_outlined,
        color: Colors.orange,
        onTap: () {},
      ),
      SettingItem(
        title: "Language",
        subtitle: "Audio & Subtitle",
        icon: Icons.language,
        color: Colors.blue,
        onTap: () {},
      ),
      SettingItem(
        title: "Privacy Policy",
        subtitle: "Privacy & Permissions",
        icon: Icons.privacy_tip_outlined,
        color: Colors.green,
        onTap: () {},
      ),
      SettingItem(
        title: "Security",
        subtitle: "MPIN & Biometrics",
        icon: Icons.lock_outline,
        color: Colors.red,
        onTap: () {},
      ),
      SettingItem(
        title: "Help & Support",
        subtitle: "FAQ & Contact",
        icon: Icons.support_agent,
        color: Colors.purple,
        onTap: () {},
      ),
      SettingItem(
        title: "About",
        subtitle: "Version Information",
        icon: Icons.info_outline,
        color: Colors.teal,
        onTap: () {},
      ),
      SettingItem(
        title: "Rate App",
        subtitle: "Leave a Review",
        icon: Icons.star_outline,
        color: Colors.amber,
        onTap: () {},
      ),
      SettingItem(
        title: "Share App",
        subtitle: "Invite Friends",
        icon: Icons.share_outlined,
        color: Colors.indigo,
        onTap: () {},
      ),
    ];

    return Column(
      children: settings
          .map((e) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: SettingTile(item: e),
      ))
          .toList(),
    );
  }
}

class SettingItem {
  final String title;
  final String subtitle;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  SettingItem({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.color,
    required this.onTap,
  });
}

class SettingTile extends StatefulWidget {
  final SettingItem item;

  const SettingTile({
    super.key,
    required this.item,
  });

  @override
  State<SettingTile> createState() => _SettingTileState();
}

class _SettingTileState extends State<SettingTile> {
  bool focused = false;

  @override
  Widget build(BuildContext context) {
    final isTV = DeviceUtils.isTV(context);

    return Focus(
      onFocusChange: (value) {
        setState(() {
          focused = value;
        });
      },
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: widget.item.onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: focused
                ? Colors.white12
                : Colors.white.withOpacity(.05),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
              color: focused
                  ? widget.item.color
                  : Colors.white10,
              width: focused ? 2 : 1,
            ),
            boxShadow: focused
                ? [
              BoxShadow(
                color: widget.item.color.withOpacity(.35),
                blurRadius: 18,
              )
            ]
                : [],
          ),
          child: Row(
            children: [
              CircleAvatar(
                radius: isTV ? 28 : 22,
                backgroundColor:
                widget.item.color.withOpacity(.15),
                child: Icon(
                  widget.item.icon,
                  color: widget.item.color,
                  size: isTV ? 28 : 22,
                ),
              ),

              const SizedBox(width: 16),

              Expanded(
                child: Column(
                  crossAxisAlignment:
                  CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.item.title,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: isTV ? 22 : 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      widget.item.subtitle,
                      style: TextStyle(
                        color: Colors.white60,
                        fontSize: isTV ? 16 : 13,
                      ),
                    ),
                  ],
                ),
              ),

              const Icon(
                Icons.arrow_forward_ios,
                color: Colors.white54,
                size: 18,
              ),
            ],
          ),
        ),
      ),
    );
  }
}