import 'package:flutter/cupertino.dart';
class CurrentUser {
  final int id;
  final String username;
  final String email;
  final String fullName;
  final int roleId;
  final String mobileNumber;
  final String userType;
  final bool emailVerified;
  final bool mobileVerified;
  final bool twoFaEnabled;
  final bool active;
  final DateTime? createdDate;

  const CurrentUser({
    required this.id,
    required this.username,
    required this.email,
    required this.fullName,
    required this.roleId,
    required this.mobileNumber,
    required this.userType,
    required this.emailVerified,
    required this.mobileVerified,
    required this.twoFaEnabled,
    required this.active,
    required this.createdDate,
  });

  factory CurrentUser.fromJson(Map<String, dynamic> json) {
    return CurrentUser(
      id: json['id'] ?? 0,
      username: json['username'] ?? '',
      email: json['email'] ?? '',
      fullName: json['fullName'] ?? '',
      roleId: json['roleId'] ?? 0,
      mobileNumber: json['mobileNumber'] ?? '',
      userType: json['userType'] ?? '',
      emailVerified: json['emailVerified'] ?? false,
      mobileVerified: json['mobileVerified'] ?? false,
      twoFaEnabled: json['twoFaEnabled'] ?? false,
      active: json['active'] ?? false,
      createdDate: json['createdDate'] != null
          ? DateTime.tryParse(json['createdDate'])
          : null,
    );
  }
}