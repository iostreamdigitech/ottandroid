import '../../../models/subscription_plan.dart';

class ActiveSubscription {
  final int? id;
  final int? userId;

  final String status;
  final String? startDate;
  final String? endDate;
  final bool autoRenew;

  final SubscriptionPlan? plan;

  const ActiveSubscription({
    this.id,
    this.userId,
    required this.status,
    this.startDate,
    this.endDate,
    required this.autoRenew,
    this.plan,
  });

  bool get active =>
      status.toUpperCase() == 'ACTIVE';

  factory ActiveSubscription.fromJson(
      Map<String, dynamic> json,
      ) {
    return ActiveSubscription(
      id: json['id'],
      userId: json['userId'],
      status: json['status']?.toString() ?? 'INACTIVE',
      startDate: json['startDate']?.toString(),
      endDate: json['endDate']?.toString(),
      autoRenew: json['autoRenew'] == true,
      plan: json['plan'] != null
          ? SubscriptionPlan.fromJson(
        Map<String, dynamic>.from(json['plan']),
      )
          : null,
    );
  }

  factory ActiveSubscription.none() {
    return const ActiveSubscription(
      status: 'INACTIVE',
      autoRenew: false,
      plan: null,
    );
  }
}