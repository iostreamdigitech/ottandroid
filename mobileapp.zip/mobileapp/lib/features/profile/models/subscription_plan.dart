class SubscriptionPlan {
  final int? id;
  final String planName;
  final String planCode;
  final String planType;

  final int validityDays;
  final int maxDevices;
  final int maxScreens;

  final String? videoQuality;
  final String? audioQuality;

  final bool accessAllContent;
  final bool watchOnTvLaptop;
  final bool adsFree;
  final bool downloadAllowed;
  final bool featuredPlan;
  final bool adsEnabled;
  final bool liveChannelEnabled;

  final String? description;
  final List<String> features;

  final String? image;

  SubscriptionPlan({
    this.id,
    required this.planName,
    required this.planCode,
    required this.planType,
    required this.validityDays,
    required this.maxDevices,
    required this.maxScreens,
    this.videoQuality,
    this.audioQuality,
    required this.accessAllContent,
    required this.watchOnTvLaptop,
    required this.adsFree,
    required this.downloadAllowed,
    required this.featuredPlan,
    required this.adsEnabled,
    required this.liveChannelEnabled,
    this.description,
    required this.features,
    this.image,
  });

  factory SubscriptionPlan.fromJson(
      Map<String, dynamic> json,
      ) {
    return SubscriptionPlan(
      id: json['id'],
      planName: json['planName']?.toString() ?? '',
      planCode: json['planCode']?.toString() ?? '',
      planType: json['planType']?.toString() ?? '',

      validityDays:
      int.tryParse(json['validityDays']?.toString() ?? '') ?? 0,

      maxDevices:
      int.tryParse(json['maxDevices']?.toString() ?? '') ?? 0,

      maxScreens:
      int.tryParse(json['maxScreens']?.toString() ?? '') ?? 0,

      videoQuality: json['videoQuality']?.toString(),
      audioQuality: json['audioQuality']?.toString(),

      accessAllContent:
      json['accessAllContent'] == true,

      watchOnTvLaptop:
      json['watchOnTvLaptop'] == true,

      adsFree:
      json['adsFree'] == true,

      downloadAllowed:
      json['downloadAllowed'] == true,

      featuredPlan:
      json['featuredPlan'] == true,

      adsEnabled:
      json['adsEnabled'] == true,

      liveChannelEnabled:
      json['liveChannelEnabled'] == true,

      description:
      json['description']?.toString(),

      features: json['features'] is List
          ? List<String>.from(
        (json['features'] as List)
            .map((e) => e.toString()),
      )
          : [],

      image: json['image']?.toString(),
    );
  }
}