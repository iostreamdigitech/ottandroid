import 'CurrentUser.dart';

class CurrentUserResponse {
  final bool success;
  final String message;
  final CurrentUser data;
  final DateTime? timestamp;

  const CurrentUserResponse({
    required this.success,
    required this.message,
    required this.data,
    this.timestamp,
  });

  factory CurrentUserResponse.fromJson(
      Map<String, dynamic> json,
      ) {
    return CurrentUserResponse(
      success: json['success'] ?? false,
      message: json['message'] ?? '',
      data: CurrentUser.fromJson(
        json['data'] ?? {},
      ),
      timestamp: json['timestamp'] != null
          ? DateTime.tryParse(json['timestamp'])
          : null,
    );
  }
}