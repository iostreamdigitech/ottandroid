import 'package:flutter/cupertino.dart';
class UserDevice {
  final int id;
  final String deviceId;
  final String deviceType;
  final String deviceName;
  final DateTime? registeredAt;

  const UserDevice({
    required this.id,
    required this.deviceId,
    required this.deviceType,
    required this.deviceName,
    required this.registeredAt,
  });

  factory UserDevice.fromJson(
      Map<String, dynamic> json,
      ) {
    return UserDevice(
      id: json['id'] ?? 0,
      deviceId: json['deviceId'] ?? '',
      deviceType: json['deviceType'] ?? '',
      deviceName: json['deviceName'] ?? '',
      registeredAt: json['registeredAt'] != null
          ? DateTime.tryParse(
        json['registeredAt'].toString(),
      )
          : null,
    );
  }
}