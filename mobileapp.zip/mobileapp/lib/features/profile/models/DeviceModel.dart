import 'package:flutter/cupertino.dart';

class DeviceModel {
  final IconData icon;
  final String name;
  final String platform;
  final String lastLogin;
  final bool current;

  DeviceModel({
    required this.icon,
    required this.name,
    required this.platform,
    required this.lastLogin,
    required this.current,
  });
}