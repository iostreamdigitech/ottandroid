import 'dart:js_interop';
import 'dart:js_interop_unsafe';

@JS('Razorpay')
external JSFunction get razorpayConstructor;

/// Razorpay checkout options.
@JS()
extension type RazorpayOptions._(JSObject _) implements JSObject {
  external factory RazorpayOptions({
    JSString key,
    JSString amount,
    JSString currency,
    JSString name,
    JSString description,
    JSString order_id,
  });
}

/// Normal Dart representation of Razorpay success response.
class RazorpayWebSuccessResponse {
  final String paymentId;
  final String orderId;
  final String signature;

  const RazorpayWebSuccessResponse({
    required this.paymentId,
    required this.orderId,
    required this.signature,
  });

  @override
  String toString() {
    return 'RazorpayWebSuccessResponse('
        'paymentId=$paymentId, '
        'orderId=$orderId, '
        'signaturePresent=${signature.isNotEmpty}'
        ')';
  }
}

/// Normal Dart representation of Razorpay failure response.
class RazorpayWebFailureResponse {
  final String code;
  final String description;
  final String reason;
  final String source;
  final String step;
  final String orderId;

  const RazorpayWebFailureResponse({
    required this.code,
    required this.description,
    required this.reason,
    required this.source,
    required this.step,
    required this.orderId,
  });

  @override
  String toString() {
    return 'RazorpayWebFailureResponse('
        'code=$code, '
        'description=$description, '
        'reason=$reason, '
        'source=$source, '
        'step=$step, '
        'orderId=$orderId'
        ')';
  }
}

class RazorpayWeb {
  static void open({
    required String key,
    required int amount,
    required String currency,
    required String name,
    required String description,
    required String orderId,
    required void Function(RazorpayWebSuccessResponse response) onSuccess,
    required void Function(RazorpayWebFailureResponse response) onFailure,
  }) {
    final Map<String, JSAny?> options = <String, JSAny?>{
      'key': key.toJS,
      'amount': amount.toString().toJS,
      'currency': currency.toJS,
      'name': name.toJS,
      'description': description.toJS,
      'order_id': orderId.toJS,
    };

    final JSAny jsOptions = options.jsify()!;

    final RazorpayWebInstance gateway =
    razorpayConstructor.callAsConstructor(jsOptions);

    gateway.on(
      'payment.success'.toJS,
      ((JSAny response) {
        _handleSuccess(
          response,
          onSuccess,
        );
      }).toJS,
    );

    gateway.on(
      'payment.failed'.toJS,
      ((JSAny response) {
        _handleFailure(
          response,
          onFailure,
        );
      }).toJS,
    );

    gateway.open();
  }
  static String _jsString(JSAny? value) {
    if (value == null) {
      return '';
    }

    try {
      if (value is JSString) {
        return value.toDart;
      }

      final dynamic dartValue = value.dartify();

      return dartValue?.toString() ?? '';
    } catch (e) {
      print(
        '[RazorpayWeb] JS string conversion failed: $e',
      );

      return '';
    }
  }
  static void _handleSuccess(
      JSAny response,
      void Function(RazorpayWebSuccessResponse response) onSuccess,
      ) {
    try {
      if (response is! JSObject) {
        throw StateError(
          'Razorpay success response is not JSObject: '
              '${response.runtimeType}',
        );
      }

      final JSObject eventObject = response;

      print(
        '[RazorpayWeb] ===== SUCCESS CALLBACK START =====',
      );

      print(
        '[RazorpayWeb] RAW RESPONSE TYPE = '
            '${response.runtimeType}',
      );

      // --------------------------------------------------
      // ROOT OBJECT
      // --------------------------------------------------

      final dynamic rootDart = eventObject.dartify();

      if (rootDart is Map) {
        print(
          '[RazorpayWeb] ROOT KEYS = '
              '${rootDart.keys.toList()}',
        );

        print(
          '[RazorpayWeb] EVENT NAME = '
              '${rootDart['event_name']}',
        );

        print(
          '[RazorpayWeb] TIMESTAMP PRESENT = '
              '${rootDart.containsKey('timestamp')}',
        );
      }

      // Check traditional Razorpay fields at root.
      final String rootPaymentId =
      _readString(eventObject, 'razorpay_payment_id');

      final String rootOrderId =
      _readString(eventObject, 'razorpay_order_id');

      final String rootSignature =
      _readString(eventObject, 'razorpay_signature');

      print(
        '[RazorpayWeb] ROOT STANDARD FIELDS | '
            'paymentIdPresent=${rootPaymentId.isNotEmpty} | '
            'orderIdPresent=${rootOrderId.isNotEmpty} | '
            'signaturePresent=${rootSignature.isNotEmpty}',
      );

      // --------------------------------------------------
      // PAYLOAD
      // --------------------------------------------------

      final JSAny? payload =
      eventObject.getProperty('payload'.toJS);

      print(
        '[RazorpayWeb] PAYLOAD PRESENT = '
            '${payload != null}',
      );

      if (payload == null || payload is! JSObject) {
        throw StateError(
          'Razorpay payload is missing.',
        );
      }

      final JSObject payloadObject = payload;

      final dynamic payloadDart =
      payloadObject.dartify();

      if (payloadDart is Map) {
        print(
          '[RazorpayWeb] PAYLOAD KEYS = '
              '${payloadDart.keys.toList()}',
        );

        print(
          '[RazorpayWeb] PAYLOAD payment PRESENT = '
              '${payloadDart.containsKey('payment')}',
        );

        // Do not print the complete payload.
      }

      // Check possible signature/order fields directly
      // under payload.
      final String payloadPaymentId =
      _readString(payloadObject, 'razorpay_payment_id');

      final String payloadOrderId =
      _readString(payloadObject, 'razorpay_order_id');

      final String payloadSignature =
      _readString(payloadObject, 'razorpay_signature');

      print(
        '[RazorpayWeb] PAYLOAD STANDARD FIELDS | '
            'paymentIdPresent=${payloadPaymentId.isNotEmpty} | '
            'orderIdPresent=${payloadOrderId.isNotEmpty} | '
            'signaturePresent=${payloadSignature.isNotEmpty}',
      );

      // --------------------------------------------------
      // PAYMENT
      // --------------------------------------------------

      final JSAny? payment =
      payloadObject.getProperty('payment'.toJS);

      print(
        '[RazorpayWeb] PAYMENT PRESENT = '
            '${payment != null}',
      );

      if (payment == null || payment is! JSObject) {
        throw StateError(
          'Razorpay payment object is missing.',
        );
      }

      final JSObject paymentObject = payment;

      final dynamic paymentDart =
      paymentObject.dartify();

      if (paymentDart is Map) {
        print(
          '[RazorpayWeb] PAYMENT KEYS = '
              '${paymentDart.keys.toList()}',
        );
      }

      // --------------------------------------------------
      // PAYMENT FIELDS
      // --------------------------------------------------

      final String paymentId =
      _readString(paymentObject, 'id');

      final String paymentOrderId =
      _readString(paymentObject, 'order_id');

      final String paymentSignature =
      _readString(paymentObject, 'razorpay_signature');

      print(
        '[RazorpayWeb] PAYMENT FIELDS | '
            'idPresent=${paymentId.isNotEmpty} | '
            'orderIdPresent=${paymentOrderId.isNotEmpty} | '
            'signaturePresent=${paymentSignature.isNotEmpty}',
      );

      // --------------------------------------------------
      // INSTRUMENT
      // --------------------------------------------------

      final JSAny? instrument =
      paymentObject.getProperty('instrument'.toJS);

      print(
        '[RazorpayWeb] INSTRUMENT PRESENT = '
            '${instrument != null}',
      );

      if (instrument is JSObject) {
        final dynamic instrumentDart =
        instrument.dartify();

        if (instrumentDart is Map) {
          print(
            '[RazorpayWeb] INSTRUMENT KEYS = '
                '${instrumentDart.keys.toList()}',
          );
        }
      }

      // --------------------------------------------------
      // PAYMENT ID
      // --------------------------------------------------

      print(
        '[RazorpayWeb] PAYMENT ID = '
            '${paymentId.isNotEmpty ? paymentId : '<missing>'}',
      );

      if (paymentId.isEmpty) {
        throw StateError(
          'Razorpay payment ID is missing.',
        );
      }

      // --------------------------------------------------
      // DETERMINE ORDER ID
      // --------------------------------------------------

      final String callbackOrderId =
      rootOrderId.isNotEmpty
          ? rootOrderId
          : payloadOrderId.isNotEmpty
          ? payloadOrderId
          : paymentOrderId;

      // --------------------------------------------------
      // DETERMINE SIGNATURE
      //
      // We only report where it was found.
      // Never print the actual signature.
      // --------------------------------------------------

      String signature = '';

      String signatureSource = 'none';

      if (rootSignature.isNotEmpty) {
        signature = rootSignature;
        signatureSource = 'root.razorpay_signature';
      } else if (payloadSignature.isNotEmpty) {
        signature = payloadSignature;
        signatureSource =
        'payload.razorpay_signature';
      } else if (paymentSignature.isNotEmpty) {
        signature = paymentSignature;
        signatureSource =
        'payload.payment.razorpay_signature';
      }

      print(
        '[RazorpayWeb] SIGNATURE SOURCE = '
            '$signatureSource',
      );

      print(
        '[RazorpayWeb] SUCCESS SUMMARY | '
            'paymentIdPresent=${paymentId.isNotEmpty} | '
            'callbackOrderIdPresent=${callbackOrderId.isNotEmpty} | '
            'signaturePresent=${signature.isNotEmpty}',
      );

      print(
        '[RazorpayWeb] ===== SUCCESS CALLBACK END =====',
      );

      onSuccess(
        RazorpayWebSuccessResponse(
          paymentId: paymentId,
          orderId: callbackOrderId,
          signature: signature,
        ),
      );
    } catch (e, stackTrace) {
      print(
        '[RazorpayWeb] ERROR parsing success response: '
            '$e\n$stackTrace',
      );

      onSuccess(
        const RazorpayWebSuccessResponse(
          paymentId: '',
          orderId: '',
          signature: '',
        ),
      );
    }
  }
  static void _handleFailure(
      JSAny response,
      void Function(RazorpayWebFailureResponse response) onFailure,
      ) {
    try {
      if (response is! JSObject) {
        throw StateError(
          'Razorpay failure response is not a JSObject. '
              'type=${response.runtimeType}',
        );
      }

      final JSObject object = response;

      final String code = _readString(
        object,
        'code',
      );

      final String description = _readString(
        object,
        'description',
      );

      final String reason = _readString(
        object,
        'reason',
      );

      final String source = _readString(
        object,
        'source',
      );

      final String step = _readString(
        object,
        'step',
      );

      final String orderId = _readString(
        object,
        'order_id',
      );

      print(
        '[RazorpayWeb] FAILURE | '
            'code=$code | '
            'description=$description | '
            'reason=$reason | '
            'source=$source | '
            'step=$step | '
            'orderId=$orderId',
      );

      onFailure(
        RazorpayWebFailureResponse(
          code: code,
          description: description,
          reason: reason,
          source: source,
          step: step,
          orderId: orderId,
        ),
      );
    } catch (e, stackTrace) {
      print(
        '[RazorpayWeb] ERROR parsing failure response: '
            '$e\n$stackTrace',
      );

      onFailure(
        const RazorpayWebFailureResponse(
          code: '',
          description: '',
          reason: '',
          source: '',
          step: '',
          orderId: '',
        ),
      );
    }
  }

  /// Reads a JavaScript object property safely.
  static String _readString(
      JSObject object,
      String propertyName,
      ) {
    try {
      final JSAny? value =
      object.getProperty(propertyName.toJS);

      if (value == null) {
        return '';
      }

      if (value is JSString) {
        return value.toDart;
      }

      final dynamic dartValue = value.dartify();

      if (dartValue == null) {
        return '';
      }

      return dartValue.toString();
    } catch (e) {
      print(
        '[RazorpayWeb] Failed reading property '
            '"$propertyName": $e',
      );

      return '';
    }
  }
}

@JS()
extension type RazorpayWebInstance._(JSObject _) implements JSObject {
  external void open();

  external void on(
      JSString event,
      JSFunction handler,
      );
}