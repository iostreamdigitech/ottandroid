import 'package:dio/dio.dart';

import '../api/api_service.dart';
import '../features/home/models/movie.dart';


class SearchRepository {
  Future<List<Movie>> searchMovies({
    required String keyword,
    String type = "ALL",
    int page = 0,
    int size = 20,
  }) async {
    try {
      final response = await ApiService.instance.dio.get(
        "/contentservice/api/v1/content/search",
        queryParameters: {
          "q": keyword,
          "type": type,
          "page": page,
          "size": size,
        },
      );

      final List data = response.data["content"] ?? [];

      return data.map((e) => Movie.fromJson(e)).toList();
    } on DioException catch (e) {
      throw Exception(e.response?.data["message"] ?? "Search Failed");
    }
  }
}