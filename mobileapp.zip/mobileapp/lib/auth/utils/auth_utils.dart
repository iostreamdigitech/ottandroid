import 'package:jwt_decode/jwt_decode.dart';

class AuthUtils {
  /// Returns true if the JWT is expired.
  static bool isExpired(String token) {
    return Jwt.isExpired(token);
  }

  /// Returns true if the user is logged in.
  static bool isLoggedIn(String? token) {
    if (token == null || token.isEmpty) {
      return false;
    }

    return !Jwt.isExpired(token);
  }

  /// Returns the JWT payload.
  static Map<String, dynamic> getPayload(String token) {
    return Jwt.parseJwt(token);
  }

  /// Returns the token expiry date.
  static DateTime? getExpiryDate(String token) {
    return Jwt.getExpiryDate(token);
  }

  /// Returns remaining validity duration.
  static Duration? remainingTime(String token) {
    final expiry = Jwt.getExpiryDate(token);

    if (expiry == null) {
      return null;
    }

    return expiry.difference(DateTime.now());
  }
}