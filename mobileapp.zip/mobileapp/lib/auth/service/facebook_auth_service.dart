import 'package:flutter_facebook_auth/flutter_facebook_auth.dart';

import '../model/social_user.dart';


class FacebookAuthService {
  final FacebookAuth _facebookAuth = FacebookAuth.instance;

  Future<SocialUser?> login() async {
    try {
      final LoginResult result = await _facebookAuth.login(
        permissions: [
          'email',
          'public_profile',
        ],
      );

      if (result.status != LoginStatus.success) {
        return null;
      }

      final AccessToken? token = result.accessToken;

      if (token == null) {
        return null;
      }

      final userData = await _facebookAuth.getUserData(
        fields: "id,name,email,picture.width(300)",
      );

      return SocialUser(
        id: userData["id"] ?? "",
        email: userData["email"] ?? "",
        name: userData["name"],
        photoUrl: userData["picture"]?["data"]?["url"],
        provider: "FACEBOOK",
        accessToken: token.tokenString,
        idToken: null,
      );
    } catch (e) {
      throw Exception("Facebook login failed: $e");
    }
  }

  Future<void> logout() async {
    await _facebookAuth.logOut();
  }
}