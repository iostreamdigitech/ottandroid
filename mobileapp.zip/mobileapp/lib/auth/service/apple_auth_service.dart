import 'package:sign_in_with_apple/sign_in_with_apple.dart';

import '../model/social_user.dart';

class AppleAuthService {
  Future<SocialUser?> login() async {

    final credential = await SignInWithApple.getAppleIDCredential(
      scopes: [
        AppleIDAuthorizationScopes.email,
        AppleIDAuthorizationScopes.fullName,
      ],
    );

    return SocialUser(
      id: credential.userIdentifier ?? "",
      email: credential.email ?? "",
      name: credential.givenName,
      provider: "APPLE",
      accessToken: credential.authorizationCode,
      idToken: credential.identityToken,
    );
  }
}