import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import '../../api/api_service.dart';
import '../../api/crypto_service.dart';
import '../model/auth_response.dart';
import '../model/social_user.dart';



class AuthApiService {
  final Dio dio;
  final FlutterSecureStorage _storage = const FlutterSecureStorage();
  AuthApiService(this.dio);

  Future<AuthResponse> socialLogin(
      SocialUser socialUser,
      ) async {
    try {
      final response = await dio.post(
        "/api/v1/auth/social-login",
        data: {
          "provider": socialUser.provider,
          "accessToken": socialUser.accessToken,
          "idToken": socialUser.idToken,
        },
      );

      return AuthResponse.fromJson(response.data);
    } on DioException catch (e) {
      throw Exception(
        e.response?.data["message"] ??
            "Authentication failed",
      );
    }
  }
}