import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:google_sign_in/google_sign_in.dart';

import '../model/social_user.dart';

class GoogleAuthService {
  static const String _webClientId =
      '354689049419-63g6upddso5ue9qgvno15go6g33923hu.apps.googleusercontent.com';

  // Web requires `clientId` and rejects `serverClientId`; mobile is the reverse.
  final GoogleSignIn _google = GoogleSignIn(
    clientId: kIsWeb ? _webClientId : null,
    serverClientId: kIsWeb ? null : _webClientId,
    scopes: [
      'email',
      'profile',
    ],
  );

  Future<SocialUser?> login() async {
    final account = await _google.signIn();

    if (account == null) return null;

    final auth = await account.authentication;
    debugPrint("Google User ID      : ${account.id}");
    debugPrint("Access Token        : ${auth.accessToken}");
    debugPrint("ID Token            : ${auth.idToken}");

    return SocialUser(
      id: account.id,
      email: account.email,
      name: account.displayName,
      photoUrl: account.photoUrl,
      provider: "GOOGLE",
      accessToken: auth.accessToken ?? '',
      idToken: auth.idToken,
    );
  }

  Future<void> logout() async {
    await _google.signOut();
  }
}