import 'package:flutter/material.dart';
import 'package:ottoneapp/auth/repositories/auth_repository.dart';
import 'package:ottoneapp/auth/utils/token_manager.dart';

import 'model/auth_response.dart';
import 'model/social_user.dart';


enum AuthStatus {
  initial,
  loading,
  authenticated,
  unauthenticated,
  error,
}

class AuthProvider extends ChangeNotifier {
  final AuthRepository _repository;

  AuthProvider(this._repository);

  AuthStatus _status = AuthStatus.initial;
  AuthStatus get status => _status;

  SocialUser? _socialUser;
  SocialUser? get socialUser => _socialUser;

  AuthResponse? _authResponse;
  AuthResponse? get authResponse => _authResponse;

  String? _errorMessage;
  String? get errorMessage => _errorMessage;

  bool get isAuthenticated =>
      _status == AuthStatus.authenticated;

  Future<void> loginWithGoogle() async {
    await _login(() => _repository.googleLogin());
  }

  Future<void> loginWithApple() async {
    await _login(() => _repository.appleLogin());
  }

  Future<void> loginWithFacebook() async {
    await _login(() => _repository.facebookLogin());
  }

  Future<void> _login(
      Future<SocialUser?> Function() loginMethod,
      ) async {
    try {
      _status = AuthStatus.loading;
      _errorMessage = null;
      notifyListeners();

      final user = await loginMethod();

      if (user == null) {
        _status = AuthStatus.unauthenticated;
        _errorMessage = "Login cancelled.";
        notifyListeners();
        return;
      }

      _socialUser = user;

      final response = await _repository.socialLogin(user);

      _authResponse = response;

      await TokenManager.saveToken(response.accessToken);

      _status = AuthStatus.authenticated;
    } catch (e) {
      _status = AuthStatus.error;
      _errorMessage = e.toString();
    }

    notifyListeners();
  }

  Future<void> logout() async {
    await _repository.logout();

    _socialUser = null;
    _authResponse = null;
    _status = AuthStatus.unauthenticated;

    notifyListeners();
  }

  Future<void> checkLoginStatus() async {
    final token = await TokenManager.getToken();

    if (token == null) {
      _status = AuthStatus.unauthenticated;
    } else {
      _status = AuthStatus.authenticated;
    }

    notifyListeners();
  }
}