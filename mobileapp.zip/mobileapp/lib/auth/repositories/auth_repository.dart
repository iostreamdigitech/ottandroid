import '../model/auth_response.dart';
import '../model/social_user.dart';
import '../service/apple_auth_service.dart';
import '../service/auth_api_service.dart';
import '../service/facebook_auth_service.dart';
import '../service/google_auth_service.dart';
import '../utils/token_manager.dart';

class AuthRepository {
  final GoogleAuthService googleAuthService;
  final AppleAuthService appleAuthService;
  final FacebookAuthService facebookAuthService;
  final AuthApiService authApiService;

  AuthRepository({
    required this.googleAuthService,
    required this.appleAuthService,
    required this.facebookAuthService,
    required this.authApiService,
  });

  Future<SocialUser?> googleLogin() async {
    return await googleAuthService.login();
  }

  Future<SocialUser?> appleLogin() async {
    return await appleAuthService.login();
  }

  Future<SocialUser?> facebookLogin() async {
    return await facebookAuthService.login();
  }

  Future<AuthResponse> socialLogin(SocialUser socialUser) async {
    return await authApiService.socialLogin(socialUser);
  }

  Future<void> logout() async {
    await googleAuthService.logout();
    await facebookAuthService.logout();

    // Apple Sign-In doesn't provide a client-side logout API.

    await TokenManager.clear();
  }
}