import 'dart:convert';

class SocialUser {
  final String id;
  final String email;
  final String? name;
  final String? photoUrl;
  final String provider;
  final String accessToken;
  final String? idToken;

  const SocialUser({
    required this.id,
    required this.email,
    this.name,
    this.photoUrl,
    required this.provider,
    required this.accessToken,
    this.idToken,
  });

  /// Create from JSON
  factory SocialUser.fromJson(Map<String, dynamic> json) {
    return SocialUser(
      id: json['id'] as String,
      email: json['email'] as String,
      name: json['name'] as String?,
      photoUrl: json['photoUrl'] as String?,
      provider: json['provider'] as String,
      accessToken: json['accessToken'] as String,
      idToken: json['idToken'] as String?,
    );
  }

  /// Convert to JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'email': email,
      'name': name,
      'photoUrl': photoUrl,
      'provider': provider,
      'accessToken': accessToken,
      'idToken': idToken,
    };
  }

  /// Convert JSON String → Object
  factory SocialUser.fromRawJson(String source) =>
      SocialUser.fromJson(json.decode(source));

  /// Convert Object → JSON String
  String toRawJson() => json.encode(toJson());

  /// Copy with updated values
  SocialUser copyWith({
    String? id,
    String? email,
    String? name,
    String? photoUrl,
    String? provider,
    String? accessToken,
    String? idToken,
  }) {
    return SocialUser(
      id: id ?? this.id,
      email: email ?? this.email,
      name: name ?? this.name,
      photoUrl: photoUrl ?? this.photoUrl,
      provider: provider ?? this.provider,
      accessToken: accessToken ?? this.accessToken,
      idToken: idToken ?? this.idToken,
    );
  }

  @override
  String toString() {
    return 'SocialUser('
        'id: $id, '
        'email: $email, '
        'name: $name, '
        'provider: $provider'
        ')';
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
          other is SocialUser &&
              runtimeType == other.runtimeType &&
              id == other.id &&
              provider == other.provider;

  @override
  int get hashCode => Object.hash(id, provider);
}