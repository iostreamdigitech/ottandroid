class AuthResponse {
  final String accessToken;
  final String refreshToken;
  final UserInfo user;

  AuthResponse({
    required this.accessToken,
    required this.refreshToken,
    required this.user,
  });

  factory AuthResponse.fromJson(Map<String, dynamic> json) {
    return AuthResponse(
      accessToken: json["accessToken"],
      refreshToken: json["refreshToken"],
      user: UserInfo.fromJson(json["user"]),
    );
  }
}

class UserInfo {
  final String customerId;
  final String mobile;

  UserInfo({
    required this.customerId,
    required this.mobile,
  });

  factory UserInfo.fromJson(Map<String, dynamic> json) {
    return UserInfo(
      customerId: json["customerId"],
      mobile: json["mobile"],
    );
  }
}