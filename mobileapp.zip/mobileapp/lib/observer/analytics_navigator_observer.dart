import 'package:flutter/cupertino.dart';

import '../analytics/services/screen_tracker.dart';

class AnalyticsNavigatorObserver extends NavigatorObserver {
  @override
  void didPush(Route route, Route? previousRoute) {
    final screen = route.settings.name;

    if (screen != null) {
      ScreenTracker.trackScreen(screenName: screen);
    }

    super.didPush(route, previousRoute);
  }
}