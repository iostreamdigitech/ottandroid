class GeoResult {
  final bool allowed;
  final String countryCode;
  final String message;

  const GeoResult({
    required this.allowed,
    required this.countryCode,
    required this.message,
  });
}