class TokenizedStream {
  final String playbackUrl;
  final String accessToken;
  final DateTime expiresAt;

  const TokenizedStream({
    required this.playbackUrl,
    required this.accessToken,
    required this.expiresAt,
  });

  bool get isExpired => DateTime.now().isAfter(expiresAt);

  String get streamUrl {
    final uri = Uri.parse(playbackUrl);

    return uri.replace(
      queryParameters: {
        ...uri.queryParameters,
        "token": accessToken,
      },
    ).toString();
  }
}