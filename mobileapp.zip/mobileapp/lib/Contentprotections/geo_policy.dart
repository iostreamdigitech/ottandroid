class GeoPolicy {
  final List<String> allowedCountries;
  final List<String> blockedCountries;

  const GeoPolicy({
    this.allowedCountries = const [],
    this.blockedCountries = const [],
  });
}