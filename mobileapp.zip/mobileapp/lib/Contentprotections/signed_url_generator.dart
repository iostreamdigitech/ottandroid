import 'dart:convert';
import 'package:http/http.dart' as http;

class SignedUrlGenerator {
  final String baseUrl;
  final String jwtToken;

  SignedUrlGenerator({
    required this.baseUrl,
    required this.jwtToken,
  });

  Future<String> getPlaybackUrl(String videoId) async {
    final response = await http.post(
      Uri.parse("$baseUrl/api/v1/playback/signed-url"),
      headers: {
        "Authorization": "Bearer $jwtToken",
        "Content-Type": "application/json",
      },
      body: jsonEncode({
        "videoId": videoId,
      }),
    );

    if (response.statusCode != 200) {
      throw Exception("Unable to generate playback URL");
    }

    return jsonDecode(response.body)["signedUrl"];
  }
}