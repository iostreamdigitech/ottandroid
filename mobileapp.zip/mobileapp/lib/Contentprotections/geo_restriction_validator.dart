import 'geo_policy.dart';
import 'geo_result.dart';

class GeoRestrictionValidator {
  final GeoPolicy policy;

  const GeoRestrictionValidator(this.policy);

  GeoResult validate(String countryCode) {
    final code = countryCode.toUpperCase();

    if (policy.blockedCountries.contains(code)) {
      return GeoResult(
        allowed: false,
        countryCode: code,
        message: "Streaming is not available in your country.",
      );
    }

    if (policy.allowedCountries.isNotEmpty &&
        !policy.allowedCountries.contains(code)) {
      return GeoResult(
        allowed: false,
        countryCode: code,
        message: "Content is not licensed in your region.",
      );
    }

    return GeoResult(
      allowed: true,
      countryCode: code,
      message: "Access granted.",
    );
  }
}