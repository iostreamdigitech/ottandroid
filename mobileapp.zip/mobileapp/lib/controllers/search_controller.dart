import 'dart:async';

import 'package:flutter/material.dart';
import 'package:get/get.dart';


import '../features/home/models/movie.dart';
import '../repositories/search_repository.dart';

class SearchController extends GetxController {
  final SearchRepository repository = SearchRepository();

  final TextEditingController searchController =
  TextEditingController();

  final RxBool isLoading = false.obs;

  final RxList<Movie> movies = <Movie>[].obs;

  final RxString error = "".obs;

  Timer? _debounce;

  void onSearchChanged(String value) {
    _debounce?.cancel();

    _debounce = Timer(
      const Duration(milliseconds: 500),
          () {
        search(value);
      },
    );
  }

  Future<void> search(String keyword) async {
    if (keyword.trim().isEmpty) {
      movies.clear();
      return;
    }

    isLoading.value = true;

    error.value = "";

    try {
      final data = await repository.searchMovies(
        keyword: keyword,
      );

      movies.assignAll(data);
    } catch (e) {
      error.value = e.toString();
    } finally {
      isLoading.value = false;
    }
  }

  @override
  void onClose() {
    _debounce?.cancel();
    searchController.dispose();
    super.onClose();
  }
}