import 'analytics_manager.dart';

class SearchTracker {
  SearchTracker._();

  static Future<void> search({
    required String keyword,
    int? resultCount,
    String? screen,
  }) async {
    await AnalyticsManager.instance.logEvent(
      eventName: "search",
      parameters: {
        "keyword": keyword,
        if (resultCount != null) "result_count": resultCount,
        if (screen != null) "screen": screen,
      },
    );
  }

  static Future<void> resultClick({
    required String keyword,
    required String contentId,
    required String contentName,
    int? position,
  }) async {
    await AnalyticsManager.instance.logEvent(
      eventName: "search_result_click",
      parameters: {
        "keyword": keyword,
        "content_id": contentId,
        "content_name": contentName,
        if (position != null) "position": position,
      },
    );
  }

  static Future<void> noResult(String keyword) async {
    await AnalyticsManager.instance.logEvent(
      eventName: "search_no_result",
      parameters: {
        "keyword": keyword,
      },
    );
  }
}