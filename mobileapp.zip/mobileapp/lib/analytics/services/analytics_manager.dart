import 'package:firebase_analytics/firebase_analytics.dart';

class AnalyticsManager {
  AnalyticsManager._();

  static final AnalyticsManager instance =
  AnalyticsManager._();

  final FirebaseAnalytics analytics =
      FirebaseAnalytics.instance;

  Future<void> initialize() async {
    // Future initialization (Remote Config, user properties, etc.)
  }

  Future<void> logEvent({
    required String eventName,
    Map<String, dynamic>? parameters,
  }) async {
    final Map<String, Object> firebaseParams = {};

    parameters?.forEach((key, value) {
      if (value != null &&
          (value is String ||
              value is int ||
              value is double ||
              value is bool)) {
        firebaseParams[key] = value;
      }
    });

    await analytics.logEvent(
      name: eventName,
      parameters: firebaseParams,
    );
  }
}