import 'analytics_manager.dart';

class StreamingTracker {
  static Future<void> play({
    required String contentId,
    required String title,
    required String quality,
  }) async {
    await AnalyticsManager.instance.logEvent(
      eventName: "video_play",
      parameters: {
        "content_id": contentId,
        "title": title,
        "quality": quality,
      },
    );
  }

  static Future<void> pause(String contentId) async {
    await AnalyticsManager.instance.logEvent(
      eventName: "video_pause",
      parameters: {
        "content_id": contentId,
      },
    );
  }

  static Future<void> complete(String contentId) async {
    await AnalyticsManager.instance.logEvent(
      eventName: "video_complete",
      parameters: {
        "content_id": contentId,
      },
    );
  }
}