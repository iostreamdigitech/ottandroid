import 'analytics_manager.dart';

class UserEventTracker {
  UserEventTracker._();

  /// Generic event tracker
  static Future<void> track({
    required String eventName,
    Map<String, dynamic>? parameters,
  }) async {
    await AnalyticsManager.instance.logEvent(
      eventName: eventName,
      parameters: parameters ?? {},
    );
  }

  /// Generic click event
  static Future<void> click({
    required String screen,
    required String widget,
    String? action,
    Map<String, dynamic>? extra,
  }) async {
    final params = <String, dynamic>{
      "screen": screen,
      "widget": widget,
      "action": action ?? "click",
      ...?extra,
    };

    await AnalyticsManager.instance.logEvent(
      eventName: "ui_click",
      parameters: params,
    );
  }
}