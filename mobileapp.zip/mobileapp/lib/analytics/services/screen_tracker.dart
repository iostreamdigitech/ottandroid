import 'package:firebase_analytics/firebase_analytics.dart';

class ScreenTracker {
  ScreenTracker._();

  static final FirebaseAnalytics _analytics =
      FirebaseAnalytics.instance;

  static Future<void> trackScreen({
    required String screenName,
    String? screenClass,
  }) async {
    await _analytics.logScreenView(
      screenName: screenName,
      screenClass: screenClass ?? screenName,
    );
  }
}