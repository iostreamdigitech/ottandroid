

import 'analytics_manager.dart';

class PaymentTracker {
  PaymentTracker._();

  static Future<void> paymentStarted({
    required String planId,
    required double amount,
    required String currency,
  }) async {
    await AnalyticsManager.instance.logEvent(
      eventName: "payment_started",
      parameters: {
        "plan_id": planId,
        "amount": amount,
        "currency": currency,
      },
    );
  }

  static Future<void> paymentSuccess({
    required String transactionId,
    required String planId,
    required double amount,
  }) async {
    await AnalyticsManager.instance.logEvent(
      eventName: "payment_success",
      parameters: {
        "transaction_id": transactionId,
        "plan_id": planId,
        "amount": amount,
      },
    );
  }

  static Future<void> paymentFailed({
    required String reason,
    String? errorCode,
  }) async {
    await AnalyticsManager.instance.logEvent(
      eventName: "payment_failed",
      parameters: {
        "reason": reason,
        if (errorCode != null) "error_code": errorCode,
      },
    );
  }
}