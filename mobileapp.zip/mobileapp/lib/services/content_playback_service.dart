import 'package:dio/dio.dart';

import '../api/api_service.dart';
import '../core/constants/api_constants.dart';
import '../core/utils/json_parse.dart';
import '../models/play_access_response.dart';

/// Playback entitlement.
///
/// Whether a title can be played, and the URL to play it with, are both server
/// decisions. Nothing here falls back to a catalogue URL when the check fails.
class ContentPlaybackService {
  Dio get _dio => ApiService.instance.dio;

  /// The play gate renders its own progress UI.
  static final Options _playOptions = Options(
    extra: const {ApiService.hideLoaderKey: true},
  );

  /// Asks whether [contentId] may play, and for the URL if it may.
  Future<PlayAccessResponse> checkPlayAccess(int contentId) async {
    try {
      final response = await _dio.get(
        ApiConstants.contentPlayAccess(contentId),
        options: _playOptions,
      );

      final body = JsonParse.object(response.data);

      if (body == null) {
        throw Exception(
          'Empty response from the playback service.',
        );
      }

      return PlayAccessResponse.fromJson(body);
    } on DioException catch (e) {
      throw _handleDioException(e);
    }
  }

  Exception _handleDioException(DioException error) {
    switch (error.type) {
      case DioExceptionType.connectionTimeout:
      case DioExceptionType.sendTimeout:
      case DioExceptionType.receiveTimeout:
        return Exception(
          'The request timed out. Please try again.',
        );

      case DioExceptionType.connectionError:
        return Exception(
          'Unable to connect to server.',
        );

      case DioExceptionType.badResponse:
        final int? statusCode = error.response?.statusCode;

        if (statusCode == 401) {
          return Exception(
            'Session expired. Please login again.',
          );
        }

        if (statusCode == 403) {
          return Exception(
            'This title is not available on your plan.',
          );
        }

        if (statusCode == 404) {
          return Exception(
            'This title is no longer available.',
          );
        }

        if (statusCode != null && statusCode >= 500) {
          return Exception(
            'Server error. Please try again later.',
          );
        }

        return Exception(
          JsonParse.text(
            JsonParse.object(error.response?.data)?['message'],
            fallback: 'Unable to start playback. Please try again.',
          ),
        );

      default:
        return Exception(
          'Unable to start playback. Please try again.',
        );
    }
  }
}
