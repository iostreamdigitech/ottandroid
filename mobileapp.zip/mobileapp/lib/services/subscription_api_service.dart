import 'package:dio/dio.dart';

import '../api/api_service.dart';
import '../core/constants/api_constants.dart';
import '../core/utils/json_parse.dart';
import '../models/create_payment_orderResponse.dart';
import '../models/subscription_plan.dart';
import '../models/verify_transaction_response.dart';

/// Subscription + payment endpoints.
///
/// Everything goes through [ApiService.instance] so the gateway base URL, the
/// bearer token, the HMAC headers and the payload encryption all apply. There
/// is no second Dio instance here on purpose.
class SubscriptionApiService {
  /// The shared, fully configured client.
  Dio get _dio => ApiService.instance.dio;

  /// Payment calls render their own full-screen placeholder, so they opt out
  /// of the generic "Please wait..." overlay.
  static final Options _paymentOptions = Options(
    extra: const {ApiService.hideLoaderKey: true},
  );

  // ============================================================
  // GET SUBSCRIPTION PLANS
  // ============================================================

  Future<SubscriptionResponse> getPlans() async {
    try {
      final response = await _dio.get(
        ApiConstants.subscriptionPlans,
      );

      if (response.data == null) {
        throw Exception('Empty response from server');
      }

      final List<dynamic> data = response.data;

      final plans = data
          .map(
            (json) => SubscriptionPlan.fromJson(
              json as Map<String, dynamic>,
            ),
          )
          .toList();

      return SubscriptionResponse.fromPlans(plans);
    } on DioException catch (e) {
      throw _handleDioException(e);
    } catch (e) {
      rethrow;
    }
  }

  // ============================================================
  // CREATE PAYMENT ORDER
  // ============================================================

  /// Asks the backend to create the purchase order and the matching Razorpay
  /// order.
  ///
  /// [payload] names what is being bought - a subscription plan or a single
  /// title rental. The amount is deliberately NOT part of it: the backend
  /// prices the purchase, so a tampered client cannot buy a yearly plan for
  /// one rupee.
  Future<CreatePaymentOrderResponse> createOrder({
    required Map<String, dynamic> payload,
  }) async {
    try {
      final response = await _dio.post(
        ApiConstants.createPaymentOrder,
        data: payload,
        options: _paymentOptions,
      );

      final body = _unwrap(
        response.data,
        fallbackError: 'Unable to create payment order',
      );

      return CreatePaymentOrderResponse.fromJson(body);
    } on DioException catch (e) {
      throw _handleDioException(e);
    } catch (e) {
      rethrow;
    }
  }
  Future<VerifyTransactionResponse> verifyWebTransaction({
    required String razorpayOrderId,
    required String razorpayPaymentId,
    String? transactionId,
    int? purchaseOrderId,
    int? paymentTransactionId,
  }) async {
    try {
      final response = await _dio.post(
        ApiConstants.verifyPaymentTransaction,
        data: {
          'razorpayOrderId': razorpayOrderId,
          'razorpayPaymentId': razorpayPaymentId,

          // Correlation IDs from create-order step.
          if (transactionId != null && transactionId.isNotEmpty)
            'transactionId': transactionId,

          if (purchaseOrderId != null && purchaseOrderId > 0)
            'purchaseOrderId': purchaseOrderId,

          if (paymentTransactionId != null && paymentTransactionId > 0)
            'paymentTransactionId': paymentTransactionId,
        },
        options: _paymentOptions,
      );

      print('[Payment] RAW RESPONSE DATA: ${response.data}');

      final body = JsonParse.object(response.data);

      print('[Payment] PARSED BODY: $body');

      if (body == null) {
        return const VerifyTransactionResponse(
          success: false,
          status: '',
          message: 'Empty response from the payment server.',
          transactionId: '',
          orderId: '',
          paymentId: '',
          planName: '',
          subscriptionStatus: '',
          startDate: '',
          endDate: '',
            paymentStatus: '',
        );
      }

      return VerifyTransactionResponse.fromJson(body);
    } on DioException catch (e) {
      throw _handleDioException(e);
    } catch (e) {
      rethrow;
    }
  }
  // ============================================================
  // VERIFY TRANSACTION
  // ============================================================

  /// Hands the Razorpay result to the backend for signature verification.
  ///
  /// The returned [VerifyTransactionResponse] is the single source of truth
  /// for whether the subscription is active - never the Razorpay callback.
  ///
  /// Unlike [createOrder] this does not throw on a business failure: a
  /// declined verification is a normal outcome the caller has to show to the
  /// user, so it comes back as a response with `isVerified == false`. Only
  /// transport-level problems throw.
  Future<VerifyTransactionResponse> verifyTransaction({
    required String razorpayOrderId,
    required String razorpayPaymentId,
    required String razorpaySignature,
    String? transactionId,
    int? purchaseOrderId,
    int? paymentTransactionId,
  }) async {
    try {
      final response = await _dio.post(
        ApiConstants.verifyPaymentTransaction,
        data: {
          'razorpayOrderId': razorpayOrderId,
          'razorpayPaymentId': razorpayPaymentId,
          'razorpaySignature': razorpaySignature,

          // Correlation ids from the create-order step, so the backend can
          // settle the exact transaction row it opened.
          if (transactionId != null && transactionId.isNotEmpty)
            'transactionId': transactionId,
          if (purchaseOrderId != null && purchaseOrderId > 0)
            'purchaseOrderId': purchaseOrderId,
          if (paymentTransactionId != null && paymentTransactionId > 0)
            'paymentTransactionId': paymentTransactionId,
        },
        options: _paymentOptions,
      );

      final body = JsonParse.object(response.data);

      if (body == null) {
        return const VerifyTransactionResponse(
          success: false,
          status: '',
          message: 'Empty response from the payment server.',
          transactionId: '',
          orderId: '',
          paymentId: '',
          planName: '',
          subscriptionStatus: '',
          startDate: '',
          endDate: '',
          paymentStatus: '',
        );
      }

      return VerifyTransactionResponse.fromJson(body);
    } on DioException catch (e) {
      throw _handleDioException(e);
    } catch (e) {
      rethrow;
    }
  }

  // ============================================================
  // CURRENT USER SUBSCRIPTION
  // ============================================================

  Future<CurrentSubscription?> getCurrentSubscription() async {
    try {
      final response = await _dio.get(
        ApiConstants.activeSubscription,
      );

      final body = JsonParse.object(response.data);

      if (body == null || body['success'] != true) {
        return null;
      }

      final data = JsonParse.object(body['data']);

      if (data == null) {
        return null;
      }

      return CurrentSubscription.fromJson(data);
    } on DioException catch (e) {
      throw _handleDioException(e);
    }
  }

  // ============================================================
  // CANCEL SUBSCRIPTION
  // ============================================================

  // TODO(backend): confirm path - not exercised by any screen yet.
  Future<bool> cancelSubscription({
    required int subscriptionId,
    String? reason,
  }) async {
    try {
      final response = await _dio.post(
        '/payService/api/payments/subscriptions/$subscriptionId/cancel',
        data: {
          'reason': reason,
        },
      );

      return response.data?['success'] == true;
    } on DioException catch (e) {
      throw _handleDioException(e);
    }
  }

  // ============================================================
  // PAYMENT HISTORY
  // ============================================================

  // TODO(backend): confirm path - not exercised by any screen yet.
  Future<List<PaymentHistory>> getPaymentHistory() async {
    try {
      final response = await _dio.get(
        '/payService/api/payments/history',
      );

      if (response.data?['success'] != true) {
        return [];
      }

      final List data = response.data['data'] ?? [];

      return data
          .map(
            (e) => PaymentHistory.fromJson(e),
          )
          .toList();
    } on DioException catch (e) {
      throw _handleDioException(e);
    }
  }

  // ============================================================
  // RESPONSE ENVELOPE
  // ============================================================

  /// Unwraps the `{success, message, data}` envelope the pay service uses.
  ///
  /// Throws with the message the backend sent when it reports a failure, so
  /// the user sees why the order could not be created rather than a generic
  /// error.
  Map<String, dynamic> _unwrap(
    dynamic responseData, {
    required String fallbackError,
  }) {
    final body = JsonParse.object(responseData);

    if (body == null) {
      throw Exception(fallbackError);
    }

    // A `success` key is only meaningful when the backend sends one.
    if (body.containsKey('success') && body['success'] != true) {
      throw Exception(
        JsonParse.text(
          JsonParse.pick(body, const ['message', 'error']),
          fallback: fallbackError,
        ),
      );
    }

    return JsonParse.object(body['data']) ?? body;
  }

  // ============================================================
  // COMMON ERROR HANDLER
  // ============================================================

  Exception _handleDioException(
    DioException error,
  ) {
    switch (error.type) {
      case DioExceptionType.connectionTimeout:
        return Exception(
          'Connection timeout. Please try again.',
        );

      case DioExceptionType.sendTimeout:
        return Exception(
          'Request timeout. Please try again.',
        );

      case DioExceptionType.receiveTimeout:
        return Exception(
          'Server response timeout.',
        );

      case DioExceptionType.badResponse:
        final statusCode = error.response?.statusCode;

        final message = JsonParse.object(
          error.response?.data,
        )?['message'];

        if (statusCode == 401) {
          return Exception(
            'Session expired. Please login again.',
          );
        }

        if (statusCode == 403) {
          return Exception(
            'You are not authorized for this operation.',
          );
        }

        if (statusCode == 404) {
          return Exception(
            'Subscription service not found.',
          );
        }

        if (statusCode != null && statusCode >= 500) {
          return Exception(
            'Server error. Please try again later.',
          );
        }

        return Exception(
          JsonParse.text(
            message,
            fallback: 'Request failed. Please try again.',
          ),
        );

      case DioExceptionType.cancel:
        return Exception(
          'Request cancelled.',
        );

      case DioExceptionType.connectionError:
        return Exception(
          'Unable to connect to server.',
        );

      default:
        return Exception(
          'Something went wrong. Please try again.',
        );
    }
  }
}

// ============================================================
// SUBSCRIPTION RESPONSE
// ============================================================

class SubscriptionResponse {
  final List<SubscriptionPlan> monthly;
  final List<SubscriptionPlan> yearly;

  SubscriptionResponse({
    required this.monthly,
    required this.yearly,
  });

  factory SubscriptionResponse.fromPlans(
    List<SubscriptionPlan> plans,
  ) {
    return SubscriptionResponse(
      monthly: plans
          .where((plan) => plan.type.toUpperCase() == 'M')
          .toList(),

      yearly: plans
          .where((plan) => plan.type.toUpperCase() == 'Y')
          .toList(),
    );
  }
}

// ============================================================
// CURRENT SUBSCRIPTION
// ============================================================

class CurrentSubscription {
  final int id;
  final int planId;
  final String planName;
  final String billingCycle;
  final String status;
  final String startDate;
  final String endDate;
  final bool autoRenew;

  CurrentSubscription({
    required this.id,
    required this.planId,
    required this.planName,
    required this.billingCycle,
    required this.status,
    required this.startDate,
    required this.endDate,
    required this.autoRenew,
  });

  factory CurrentSubscription.fromJson(
    Map<String, dynamic> json,
  ) {
    return CurrentSubscription(
      id: json['id'] ?? 0,
      planId: json['planId'] ?? 0,
      planName: json['planName']?.toString() ?? '',
      billingCycle: json['billingCycle']?.toString() ?? '',
      status: json['status']?.toString() ?? '',
      startDate: json['startDate']?.toString() ?? '',
      endDate: json['endDate']?.toString() ?? '',
      autoRenew: json['autoRenew'] ?? false,
    );
  }
}

// ============================================================
// PAYMENT HISTORY
// ============================================================

class PaymentHistory {
  final int id;
  final String orderId;
  final String paymentId;
  final double amount;
  final String currency;
  final String status;
  final String paidAt;

  PaymentHistory({
    required this.id,
    required this.orderId,
    required this.paymentId,
    required this.amount,
    required this.currency,
    required this.status,
    required this.paidAt,
  });

  factory PaymentHistory.fromJson(
    Map<String, dynamic> json,
  ) {
    return PaymentHistory(
      id: json['id'] ?? 0,
      orderId: json['orderId']?.toString() ?? '',
      paymentId: json['paymentId']?.toString() ?? '',
      amount: double.tryParse(
            json['amount']?.toString() ?? '0',
          ) ??
          0,
      currency: json['currency']?.toString() ?? 'INR',
      status: json['status']?.toString() ?? '',
      paidAt: json['paidAt']?.toString() ?? '',
    );
  }
}
