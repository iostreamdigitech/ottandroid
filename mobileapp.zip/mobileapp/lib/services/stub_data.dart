

import '../features/home/models/movie.dart';

/// Central home for sample/mock data used until the real backend is wired up.
/// UI widgets must never hardcode sample data directly - read it from here.
class StubData {
  StubData._();

  // TODO: Replace with API call - this sample stream is for local playback testing only.
  static const String sampleVideoUrl =
      'https://devstreaming-cdn.apple.com/videos/streaming/examples/bipbop_4x3/bipbop_4x3_variant.m3u8';

  static final List<Movie> banners = [
    const Movie(
      id: 2,
      title: 'Aarroraa',
      posterUrl: 'https://picsum.photos/200/300?10',
      bannerUrl: 'https://picsum.photos/800/400?1',
      description: 'A gripping tale of ambition, betrayal and redemption.',
      genre: 'Action',
      year: '2026',
      duration: '2h 10m',
      rating: 4.5,
      videoUrl: sampleVideoUrl,
    ),
    const Movie(
      id: 2,
      title: 'Midnight Tide',
      posterUrl: 'https://picsum.photos/200/300?13',
      bannerUrl: 'https://picsum.photos/801/400',
      description: 'A coastal town hides a secret that surfaces at midnight.',
      genre: 'Thriller',
      year: '2025',
      duration: '1h 58m',
      rating: 4.2,
      videoUrl: sampleVideoUrl,
    ),
    const Movie(
      id: 2,
      title: 'Silver Horizon',
      posterUrl: 'https://picsum.photos/200/300?14',
      bannerUrl: 'https://picsum.photos/802/400',
      description: 'An astronaut fights to find her way back home.',
      genre: 'Sci-Fi',
      year: '2025',
      duration: '2h 21m',
      rating: 4.6,
      videoUrl: sampleVideoUrl,
    ),
  ];

  static final List<Movie> continueWatching = [
    const Movie(
      id: 2,
      title: 'Bheeshma Parvam',
      posterUrl: 'https://picsum.photos/200/300?1',
      description: 'A family patriarch must protect his legacy from rivals.',
      genre: 'Drama',
      year: '2022',
      duration: '2h 30m',
      rating: 4.2,
      progress: 0.45,
      videoUrl: sampleVideoUrl,
    ),
    const Movie(
      id: 2,
      title: 'Kannur Squad',
      posterUrl: 'https://picsum.photos/200/300?2',
      description: 'An elite police squad hunts down a fugitive across states.',
      genre: 'Action',
      year: '2023',
      duration: '2h 20m',
      rating: 4.3,
      progress: 0.60,
      videoUrl: sampleVideoUrl,
    ),
    const Movie(
      id: 2,
      title: 'Aavesham',
      posterUrl: 'https://picsum.photos/200/300?3',
      description: 'Three college friends fall in with a flamboyant gangster.',
      genre: 'Comedy',
      year: '2024',
      duration: '2h 15m',
      rating: 4.6,
      progress: 0.20,
      videoUrl: sampleVideoUrl,
    ),
  ];

  static final List<Movie> trending = [
    const Movie(
      id: 2,
      title: 'Premalu',
      posterUrl: 'https://picsum.photos/200/300?4',
      description: 'A young man navigates love and misunderstandings abroad.',
      genre: 'Romance',
      year: '2024',
      duration: '2h 5m',
      rating: 4.4,
      videoUrl: sampleVideoUrl,
    ),
    const Movie(
      id: 2,
      title: 'ARM',
      posterUrl: 'https://picsum.photos/200/300?5',
      description: 'A retired officer is pulled back for one last mission.',
      genre: 'Thriller',
      year: '2023',
      duration: '2h 25m',
      rating: 4.1,
      videoUrl: sampleVideoUrl,
    ),
    const Movie(
      id: 2,
      title: 'Manjummel Boys',
      posterUrl: 'https://picsum.photos/200/300?6',
      description: 'A group of friends face a life-or-death rescue on a trip.',
      genre: 'Adventure',
      year: '2024',
      duration: '2h 15m',
      rating: 4.7,
      videoUrl: sampleVideoUrl,
    ),
    const Movie(
      id: 2,
      title: 'Kishkindha Kaandam',
      posterUrl: 'https://picsum.photos/200/300?7',
      description: 'A family unravels a mystery hidden in their own home.',
      genre: 'Mystery',
      year: '2024',
      duration: '2h 20m',
      rating: 4.5,
      videoUrl: sampleVideoUrl,
    ),
  ];

  static final List<Movie> newReleases = [
    const Movie(
      id: 2,
      title: 'Bramayugam',
      posterUrl: 'https://picsum.photos/200/300?8',
      description: 'A wandering singer is trapped in a haunted mansion.',
      genre: 'Horror',
      year: '2024',
      duration: '2h 19m',
      rating: 4.3,
      videoUrl: sampleVideoUrl,
    ),
    const Movie(
      id: 2,
      title: 'Malaikottai Vaaliban',
      posterUrl: 'https://picsum.photos/200/300?9',
      description: 'A wandering fighter is challenged by a mysterious rival.',
      genre: 'Fantasy',
      year: '2024',
      duration: '2h 39m',
      rating: 4.0,
      videoUrl: sampleVideoUrl,
    ),
    const Movie(
      id: 2,
      title: 'Varshangalkku Shesham',
      posterUrl: 'https://picsum.photos/200/300?11',
      description: 'Two friends chase their dreams in the world of cinema.',
      genre: 'Drama',
      year: '2024',
      duration: '2h 45m',
      rating: 4.6,
      videoUrl: sampleVideoUrl,
    ),
    const Movie(
      id: 2,
      title: 'Aadujeevitham',
      posterUrl: 'https://picsum.photos/200/300?12',
      description: 'A migrant worker fights to survive brutal captivity.',
      genre: 'Survival',
      year: '2024',
      duration: '2h 40m',
      rating: 4.8,
      videoUrl: sampleVideoUrl,
    ),
  ];

  static final List<String> genres = [
    'Action',
    'Comedy',
    'Drama',
    'Thriller',
    'Horror',
    'Romance',
  ];

  static List<Movie> get allMovies => [
        ...banners,
        ...continueWatching,
        ...trending,
        ...newReleases,
      ];
}
