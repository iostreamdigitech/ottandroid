import 'package:ottoneapp/models/BannerModel.dart';

import '../api/api_service.dart';
import '../features/home/models/movie.dart';
import '../features/home/models/Category.dart';

import 'stub_data.dart';

/// Data-source layer. Every method currently resolves from [StubData];
/// swap the body for a real Dio/API call without touching callers.
class MovieService {
  // TODO: Replace with API call - GET /movies/banners
  Future<List<Movie>> getCategoryContent(String categoryCode) async {
    final response = await ApiService.instance.dio.get(
      "/contentservice/api/v1/content/category/$categoryCode",
    );

    final List<dynamic> content = response.data["data"]["content"];

    print("========================================");
    print("API Content Count: ${content.length}");

    final List<Movie> movies = [];

    for (final item in content) {
      try {
        print("Raw JSON:");
        print(item);

        final movie = Movie.fromJson(item);

        print("Parsed Successfully: ${movie.title}");

        movies.add(movie);
      } catch (e, stackTrace) {
        print("========================================");
        print("Movie.fromJson Failed");
        print("Error: $e");
        print("JSON: $item");
        print(stackTrace);
        print("========================================");
      }
    }

    print("Movies Parsed: ${movies.length}");

    return movies;
  }
  Future<List<Category>> getCategories() async {
    final response = await ApiService.instance.dio.get("/contentservice/api/v1/categories");

    final List data = response.data["data"];

    return data
        .map((e) => Category.fromJson(e))
        .where((e) => e.active)
        .toList()
      ..sort((a, b) => a.displayOrder.compareTo(b.displayOrder));
  }
  Future<List<BannerModel>> fetchBanners() async {
    try {
      final response = await ApiService.instance.dio.get("/contentservice/api/banners");

      if (response.data["success"] == true) {
        final List data = response.data["data"];

        return data
            .map((e) => BannerModel.fromJson(e))
            .where((e) => e.active)
            .toList();
      }

      return [];
    } catch (e) {
      throw Exception("Failed to load banners: $e");
    }
  }

  // TODO: Replace with API call - GET /user/continue-watching
  Future<List<Movie>> fetchContinueWatching() async {

    return StubData.continueWatching;
  }

  // TODO: Replace with API call - GET /movies/trending
  Future<List<Movie>> fetchTrending() async {

    return StubData.trending;
  }

  // TODO: Replace with API call - GET /movies/new-releases
  Future<List<Movie>> fetchNewReleases() async {

    return StubData.newReleases;
  }

  // TODO: Replace with API call - GET /genres
  Future<List<String>> fetchGenres() async {

    return StubData.genres;
  }

  // TODO: Replace with API call - GET /movies
  Future<List<Movie>> fetchAllMovies() async {

    return StubData.allMovies;
  }

  // TODO: Replace with API call - GET /movies/{id}
  Future<Movie> fetchMovieById(String id) async {

    return StubData.allMovies.firstWhere(
      (movie) => movie.id == id,
      orElse: () => StubData.allMovies.first,
    );
  }
}
