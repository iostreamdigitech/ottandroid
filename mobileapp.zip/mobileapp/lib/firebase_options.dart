// File: lib/firebase_options.dart

import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }

    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
        case TargetPlatform.macOS:
        return macos;
      case TargetPlatform.windows:
        return windows;
      case TargetPlatform.linux:
        return linux;
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }

  static const FirebaseOptions web = FirebaseOptions(
      apiKey: "AIzaSyBOUkslqAXV95YjlNvAgeirLWLDMW0_1lE",
      authDomain: "angular-century-122310.firebaseapp.com",
      databaseURL: "https://angular-century-122310-default-rtdb.firebaseio.com",
      projectId: "angular-century-122310",
      storageBucket: "angular-century-122310.firebasestorage.app",
      messagingSenderId: "354689049419",
      appId: "1:354689049419:web:2ca3055e06afd46576bece",
      measurementId: "G-9KKHEMT2GC"
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyDCuhfmWZ85SBFdP1ybhSkI7SxYgz1aacU',
    appId: 'com.ottoneentertainment.ottoneapp',
    messagingSenderId: '354689049419',
    projectId: '354689049419',
    storageBucket: 'YOUR_PROJECT_ID.appspot.com',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyDCuhfmWZ85SBFdP1ybhSkI7SxYgz1aacU',
    appId: 'YOUR_IOS_APP_ID',
    messagingSenderId: 'YOUR_MESSAGING_SENDER_ID',
    projectId: 'YOUR_PROJECT_ID',
    storageBucket: 'YOUR_PROJECT_ID.appspot.com',
    iosBundleId: 'com.example.app',
  );

  static const FirebaseOptions macos = ios;

  static const FirebaseOptions windows = FirebaseOptions(
    apiKey: '',
    appId: '',
    messagingSenderId: '',
    projectId: '',
    storageBucket: '',
  );

  static const FirebaseOptions linux = FirebaseOptions(
    apiKey: '',
    appId: '',
    messagingSenderId: '',
    projectId: '',
    storageBucket: '',
  );
}