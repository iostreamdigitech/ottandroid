import 'package:dio/dio.dart';

import '../../api/api_service.dart';
import '../../models/subscription_plan.dart';


class SubscriptionService {

  Future<List<SubscriptionPlan>> getPlans() async {

    try {

      final Response response =
      await ApiService.instance.dio.get(
        "/payService/api/subscription-plans", // <-- Replace
      );

      final List data = response.data;

      return data
          .map((e) => SubscriptionPlan.fromJson(e))
          .toList();

    } catch (e) {
      rethrow;
    }
  }
}