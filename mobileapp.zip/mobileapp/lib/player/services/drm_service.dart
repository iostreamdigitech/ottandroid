enum DRMType {
  none,
  widevine,
  fairplay,
  playready,
}

class DRMConfig {
  final DRMType type;
  final String? licenseUrl;
  final String? certificateUrl;
  final Map<String, String> headers;
  final String? licenseToken;

  const DRMConfig({
    required this.type,
    this.licenseUrl,
    this.certificateUrl,
    this.headers = const {},
    this.licenseToken,
  });

  bool get isProtected => type != DRMType.none;
}

abstract class DRMService {
  /// Get DRM configuration for content
  Future<DRMConfig> getDRMConfig(
      String contentId,
      );

  /// Refresh license token if expired
  Future<DRMConfig> refreshToken(
      String contentId,
      );

  /// Release offline license
  Future<void> releaseLicense(
      String contentId,
      );
}