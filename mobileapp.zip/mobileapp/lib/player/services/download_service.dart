import 'dart:async';

enum DownloadStatus {
  idle,
  queued,
  downloading,
  paused,
  completed,
  failed,
  cancelled,
}

class DownloadTask {
  final String contentId;
  final String title;
  final String url;

  double progress;
  DownloadStatus status;

  DownloadTask({
    required this.contentId,
    required this.title,
    required this.url,
    this.progress = 0,
    this.status = DownloadStatus.idle,
  });
}

abstract class DownloadService {
  /// Start download
  Future<void> download(DownloadTask task);

  /// Pause download
  Future<void> pause(String contentId);

  /// Resume download
  Future<void> resume(String contentId);

  /// Cancel download
  Future<void> cancel(String contentId);

  /// Delete downloaded file
  Future<void> delete(String contentId);

  /// Current progress stream
  Stream<DownloadTask> progressStream();

  /// Active downloads
  List<DownloadTask> activeDownloads();
}