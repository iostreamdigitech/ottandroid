
import '../../analytics/services/analytics_manager.dart';

class AnalyticsService {
  AnalyticsService._();

  static final AnalyticsService instance =
  AnalyticsService._();

  Future<void> track({
    required String event,
    Map<String, Object>? params,
  }) async {
    await AnalyticsManager.instance.logEvent(
      eventName: event,
      parameters: params,
    );
  }

  Future<void> screenView(String screen) async {
    await track(
      event: "screen_view",
      params: {
        "screen_name": screen,
      },
    );
  }

  Future<void> playerPlay({
    required String contentId,
    required String title,
    required int position,
  }) async {
    await track(
      event: "video_play",
      params: {
        "content_id": contentId,
        "title": title,
        "position": position,
      },
    );
  }

  Future<void> playerPause({
    required String contentId,
    required int position,
  }) async {
    await track(
      event: "video_pause",
      params: {
        "content_id": contentId,
        "position": position,
      },
    );
  }

  Future<void> playerComplete(
      String contentId) async {
    await track(
      event: "video_complete",
      params: {
        "content_id": contentId,
      },
    );
  }

  Future<void> seek({
    required String contentId,
    required int from,
    required int to,
  }) async {
    await track(
      event: "video_seek",
      params: {
        "content_id": contentId,
        "from": from,
        "to": to,
      },
    );
  }

  Future<void> bufferingStart(
      String contentId) async {
    await track(
      event: "buffer_start",
      params: {
        "content_id": contentId,
      },
    );
  }

  Future<void> bufferingEnd(
      String contentId) async {
    await track(
      event: "buffer_end",
      params: {
        "content_id": contentId,
      },
    );
  }

  Future<void> playerError({
    required String contentId,
    required String message,
  }) async {
    await track(
      event: "player_error",
      params: {
        "content_id": contentId,
        "error": message,
      },
    );
  }

  Future<void> heartbeat({
    required String contentId,
    required int watchTime,
  }) async {
    await track(
      event: "heartbeat",
      params: {
        "content_id": contentId,
        "watch_time": watchTime,
      },
    );
  }

  Future<void> downloadStarted(
      String contentId) async {
    await track(
      event: "download_start",
      params: {
        "content_id": contentId,
      },
    );
  }

  Future<void> downloadCompleted(
      String contentId) async {
    await track(
      event: "download_complete",
      params: {
        "content_id": contentId,
      },
    );
  }

  Future<void> downloadFailed({
    required String contentId,
    required String reason,
  }) async {
    await track(
      event: "download_failed",
      params: {
        "content_id": contentId,
        "reason": reason,
      },
    );
  }

  Future<void> search(String keyword) async {
    await track(
      event: "search",
      params: {
        "keyword": keyword,
      },
    );
  }

  Future<void> login(String method) async {
    await track(
      event: "login",
      params: {
        "method": method,
      },
    );
  }

  Future<void> logout() async {
    await track(
      event: "logout",
    );
  }
}