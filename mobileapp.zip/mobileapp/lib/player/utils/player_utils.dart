import 'package:better_player/better_player.dart';

class PlayerUtils {
  PlayerUtils._();

  static String formatDuration(Duration duration) {
    final hours = duration.inHours;
    final minutes = duration.inMinutes.remainder(60);
    final seconds = duration.inSeconds.remainder(60);

    if (hours > 0) {
      return "${hours.toString().padLeft(2, '0')}:"
          "${minutes.toString().padLeft(2, '0')}:"
          "${seconds.toString().padLeft(2, '0')}";
    }

    return "${minutes.toString().padLeft(2, '0')}:"
        "${seconds.toString().padLeft(2, '0')}";
  }

  static double progress({
    required Duration position,
    required Duration duration,
  }) {
    if (duration.inMilliseconds == 0) {
      return 0;
    }

    return position.inMilliseconds /
        duration.inMilliseconds;
  }

  static bool isCompleted({
    required Duration position,
    required Duration duration,
  }) {
    return duration.inMilliseconds > 0 &&
        position >= duration;
  }

  static Duration remainingTime({
    required Duration position,
    required Duration duration,
  }) {
    if (position >= duration) {
      return Duration.zero;
    }

    return duration - position;
  }

  static bool isLive(
      BetterPlayerController controller) {
    return controller
        .betterPlayerDataSource?.liveStream ??
        false;
  }

  static Future<void> seekForward(
      BetterPlayerController controller, {
        int seconds = 10,
      }) async {
    final videoController =
        controller.videoPlayerController;

    if (videoController == null) return;

    final position =
        videoController.value.position;

    await controller.seekTo(
      position + Duration(seconds: seconds),
    );
  }

  static Future<void> seekBackward(
      BetterPlayerController controller, {
        int seconds = 10,
      }) async {
    final videoController =
        controller.videoPlayerController;

    if (videoController == null) return;

    final position =
        videoController.value.position;

    var target =
        position - Duration(seconds: seconds);

    if (target.isNegative) {
      target = Duration.zero;
    }

    await controller.seekTo(target);
  }

  static Future<void> togglePlayPause(
      BetterPlayerController controller) async {
    if (controller.isPlaying() ?? false) {
      controller.pause();
    } else {
      controller.play();
    }
  }

  static Future<void> setPlaybackSpeed(
      BetterPlayerController controller,
      double speed,
      ) async {
    controller.setSpeed(speed);
  }
}