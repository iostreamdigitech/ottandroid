import 'dart:async';

import 'package:better_player/better_player.dart';
import 'package:flutter/foundation.dart';

import '../models/video_source.dart';
import '../services/drm_service.dart';
import '../widgets/player_state.dart';
import 'heartbeat_controller.dart';

import 'resume_controller.dart';

class OTTPlayerController {
  OTTPlayerController({
    required this.resumeController,
    required this.heartbeatController,
    required this.drmService,
  });

  final ResumeController resumeController;
  final HeartbeatController heartbeatController;
  final DRMService drmService;

  BetterPlayerController? _player;

  VideoSource? _source;

  Timer? _progressTimer;
  bool get isInitialized =>
      state.value.initialized;
  final ValueNotifier<PlayerState> state =
  ValueNotifier(const PlayerState());
  bool get isPlaying =>
      state.value.playing;

  bool get isBuffering =>
      state.value.buffering;

  Duration get position =>
      state.value.position;

  Duration get duration =>
      state.value.duration;

  bool get isFullscreen =>
      state.value.fullscreen;
  BetterPlayerController? get player => _player;

  Future<void> initialize({
    required BetterPlayerController player,
    required VideoSource source,
  }) async {
    _player = player;
    _source = source;

    final resume =
    await resumeController.restore(source.id);

    if (resume != null) {
      await player.seekTo(resume);
    }

    state.value = state.value.copyWith(
      initialized: true,
    );

    _startProgressListener();
  }

  void _startProgressListener() {
    _progressTimer?.cancel();

    _progressTimer = Timer.periodic(
      const Duration(milliseconds: 500),
          (_) {
        final video = _player?.videoPlayerController;

        if (video == null) return;

        final value = video.value;

        state.value = state.value.copyWith(
          position: value.position,
          duration: value.duration,
          playing: value.isPlaying,
          buffering: value.isBuffering,
        );
      },
    );
  }

  Future<void> play() async {
    await _player?.play();

    state.value = state.value.copyWith(
      playing: true,
    );

    heartbeatController.resume();
  }

  Future<void> pause() async {
    await _player?.pause();

    state.value = state.value.copyWith(
      playing: false,
    );

    heartbeatController.pause();
  }

  Future<void> seek(Duration position) async {
    await _player?.seekTo(position);
  }

  Future<void> setSpeed(double speed) async {
    await _player?.setSpeed(speed);

    state.value = state.value.copyWith(
      speed: speed,
    );
  }

  Future<void> enterFullscreen() async {
    _player?.enterFullScreen();

    state.value = state.value.copyWith(
      fullscreen: true,
    );
  }

  Future<void> exitFullscreen() async {
    _player?.exitFullScreen();

    state.value = state.value.copyWith(
      fullscreen: false,
    );
  }

  Future<void> stop() async {
    _progressTimer?.cancel();
    heartbeatController.stop();

    if (_source != null) {
      await resumeController.save(
        _source!.id,
        state.value.position,
      );
    }

    await _player?.pause();
  }

  Future<void> completed() async {
    heartbeatController.stop();

    if (_source != null) {
      await resumeController.completed(
        _source!.id,
      );
    }
  }


  Future<void> dispose() async {
    _progressTimer?.cancel();

    heartbeatController.dispose();
    resumeController.dispose();

    state.dispose();
  }
}