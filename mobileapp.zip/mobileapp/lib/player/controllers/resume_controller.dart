import 'dart:async';

import '../models/video_source.dart';

abstract class ResumeRepository {
  Future<void> savePosition(
      String contentId,
      Duration position,
      );

  Future<Duration?> getPosition(
      String contentId,
      );

  Future<void> clearPosition(
      String contentId,
      );
}

class ResumeController {
  ResumeController({
    required this.repository,
  });

  final ResumeRepository repository;

  Timer? _timer;

  /// Save every 10 seconds
  void startAutoSave({
    required VideoSource source,
    required Duration Function() currentPosition,
  }) {
    stopAutoSave();

    _timer = Timer.periodic(
      const Duration(seconds: 10),
          (_) async {
        await save(
          source.id,
          currentPosition(),
        );
      },
    );
  }

  void stopAutoSave() {
    _timer?.cancel();
    _timer = null;
  }

  Future<void> save(
      String contentId,
      Duration position,
      ) async {
    await repository.savePosition(
      contentId,
      position,
    );
  }

  Future<Duration?> restore(
      String contentId,
      ) async {
    return repository.getPosition(
      contentId,
    );
  }

  Future<void> completed(
      String contentId,
      ) async {
    await repository.clearPosition(
      contentId,
    );
  }

  void dispose() {
    stopAutoSave();
  }
}