import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../core/utils/app_logger.dart';
import '../../core/utils/app_navigator.dart';
import '../../features/home/models/movie.dart';
import '../../models/play_access_response.dart';
import '../../screens/player_page.dart';
import '../../screens/subscription_page.dart';
import '../../services/content_playback_service.dart';
import '../models/payment_request.dart';
import 'payment_engine.dart';

/// The gate every Play button goes through.
///
///   Play
///     |
///     v
///   play-access API
///     |
///     +-- playReady --------------------> Player
///     |
///     +-- type = Subscription ----------> Subscription plans
///     |
///     +-- type = Rent ------------------> Razorpay rental
///                                            |
///                                            v
///                                     verified purchase
///                                            |
///                                            v
///                                     re-check access -> Player
///
/// Entitlement and the playable URL are both server decisions. Nothing here
/// falls back to the URL carried in the catalogue payload, and a rental never
/// opens the player off the Razorpay callback - it re-asks the backend.
class PlaybackController extends GetxController {
  /// App-wide instance, so the gate state survives the pages that use it.
  static PlaybackController get instance {
    return Get.isRegistered<PlaybackController>()
        ? Get.find<PlaybackController>()
        : Get.put(PlaybackController(), permanent: true);
  }

  final ContentPlaybackService _service = ContentPlaybackService();

  PaymentEngine get payments => PaymentEngine.instance;

  /// True while the access check is in flight.
  final RxBool isChecking = false.obs;

  /// Title being checked, for the placeholder.
  final RxString checkingTitle = ''.obs;

  /// True while anything - the check or a rental payment - is running.
  bool get isBusy => isChecking.value || payments.isBusy;

  // ---------------------------------------------------------------------------
  // ENTRY POINT
  // ---------------------------------------------------------------------------

  /// Handles a Play tap for [movie].
  Future<void> play({
    required BuildContext context,
    required Movie movie,
  }) async {
    // One check per tap, and never while a rental payment is on screen.
    if (isBusy) {
      return;
    }

    final PlayAccessResponse access;

    try {
      isChecking.value = true;
      checkingTitle.value = movie.title;

      access = await _service.checkPlayAccess(movie.id);
    } catch (e) {
      AppLogger.error('Play access check failed: $e');

      if (context.mounted) {
        _notify(context, _presentable(e.toString()));
      }
      return;
    } finally {
      isChecking.value = false;
      checkingTitle.value = '';
    }

    if (!context.mounted) {
      return;
    }

    if (access.message=='Playback authorized') {
      _openPlayer(context, movie, access.videoUrl);
      return;
    }

    // Entitled but no URL is a backend problem, not permission to play.
    if (access.playReady) {
      _notify(
        context,
        'This title cannot be played right now. Please try again later.',
      );
      return;
    }

    switch (access.type) {
      case PlayAccessType.subscription:
        _openSubscriptionPlans(context);
        return;

      case PlayAccessType.rent:
        await _rent(context, movie, access);
        return;

      case PlayAccessType.ready:
      case PlayAccessType.unknown:
        _notify(
          context,
          access.message.isNotEmpty
              ? access.message
              : 'This title is not available to watch right now.',
        );
        return;
    }
  }

  // ---------------------------------------------------------------------------
  // RENT
  // ---------------------------------------------------------------------------

  /// Starts a rental purchase.
  ///
  /// The result screen stays up when this resolves - [continueAfterRental] is
  /// what actually opens the player, once the user taps through it.
  Future<void> _rent(
    BuildContext context,
    Movie movie,
    PlayAccessResponse access,
  ) async {
    await payments.pay(
      PaymentRequest.rental(
        contentId: movie.id,
        title: movie.title,
        amount: access.amount,
        currency: access.currency,
      ),
    );
  }

  /// Success screen, "Watch Now", after a rental.
  ///
  /// Deliberately re-runs the whole gate rather than trusting the payment
  /// result: the backend re-states the entitlement and hands back a fresh
  /// playable URL.
  Future<void> continueAfterRental({
    required BuildContext context,
    required Movie movie,
  }) async {
    payments.reset();

    await play(context: context, movie: movie);
  }

  // ---------------------------------------------------------------------------
  // NAVIGATION
  // ---------------------------------------------------------------------------

  void _openPlayer(
    BuildContext context,
    Movie movie,
    String videoUrl,
  ) {
    AppNavigator.push(
      context,
      PlayerPage(
        videoUrl: videoUrl,
        title: movie.title,
      ),
    );
  }

  void _openSubscriptionPlans(BuildContext context) {
    AppNavigator.push(
      context,
      SubscriptionPage(),
    );
  }

  // ---------------------------------------------------------------------------
  // FEEDBACK
  // ---------------------------------------------------------------------------

  void _notify(BuildContext context, String message) {
    if (message.isEmpty) {
      return;
    }

    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(
            message,
            style: const TextStyle(color: Colors.white),
          ),
          backgroundColor: const Color(0xff151C35),
          behavior: SnackBarBehavior.floating,
          duration: const Duration(seconds: 4),
        ),
      );
  }

  /// Keeps the first line only, so a stack trace can never reach the screen.
  String _presentable(String raw) {
    final String text = raw
        .replaceFirst(
          RegExp(r'^(_?Exception|Error|DioException)\s*:\s*'),
          '',
        )
        .split('\n')
        .first
        .trim();

    if (text.isEmpty || text.contains('#0')) {
      return 'Unable to start playback. Please try again.';
    }

    return text;
  }
}
