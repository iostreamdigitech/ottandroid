import 'package:get/get.dart';
import 'package:uuid/uuid.dart';

import '../../models/subscription_plan.dart';
import '../../services/subscription_api_service.dart';
import '../models/payment_request.dart';
import 'payment_engine.dart';

/// Subscription plans, and the Subscribe entry point.
///
/// The purchase itself is run by the shared [PaymentEngine] - create order,
/// Razorpay checkout, verify transaction - so subscriptions and rentals go
/// through exactly one gateway implementation.
class SubscriptionController extends GetxController {
  final SubscriptionApiService api = SubscriptionApiService();

  /// Payment state for the page and its cards to render.
  PaymentEngine get payments => PaymentEngine.instance;

  final RxBool isLoading = false.obs;

  final RxInt selectedTab = 0.obs;

  final RxString errorMessage = ''.obs;

  final RxList<SubscriptionPlan> monthlyPlans = <SubscriptionPlan>[].obs;

  final RxList<SubscriptionPlan> yearlyPlans = <SubscriptionPlan>[].obs;

  RxList<SubscriptionPlan> get currentPlans {
    return selectedTab.value == 0 ? monthlyPlans : yearlyPlans;
  }

  @override
  void onInit() {
    super.onInit();

    // Touch the engine so its Razorpay listeners are registered before the
    // user can reach the Subscribe button.
    payments;

    loadPlans();
  }

  // ---------------------------------------------------------------------------
  // PLANS
  // ---------------------------------------------------------------------------

  Future<void> loadPlans() async {
    try {
      isLoading.value = true;
      errorMessage.value = '';

      final response = await api.getPlans();

      monthlyPlans.assignAll(response.monthly);

      yearlyPlans.assignAll(response.yearly);
    } catch (e) {
      errorMessage.value = 'Unable to load subscription plans.';
    } finally {
      isLoading.value = false;
    }
  }

  void changeTab(int index) {
    selectedTab.value = index;
  }

  // ---------------------------------------------------------------------------
  // PURCHASE
  // ---------------------------------------------------------------------------

  /// Entry point for the Subscribe button.
  ///
  /// Duplicate taps, the gateway lifecycle and backend verification are all
  /// handled by the engine; the result stays on screen until the user acts on
  /// it.
  Future<void> subscribe(SubscriptionPlan plan) async {
    final requestId = const Uuid().v4();
    await payments.pay(
      PaymentRequest.subscription(
        plan: plan,
        billingCycle: _billingCycleOf(plan),
        requestId: requestId,
      ),
    );
  }

  String _billingCycleOf(SubscriptionPlan plan) {
    return plan.isYearly ? 'YEARLY' : 'MONTHLY';
  }
}
