import 'dart:async';

import '../models/video_source.dart';
import '../services/analytics_service.dart';

class HeartbeatController {
  HeartbeatController({
    this.interval = const Duration(seconds: 30),
  });

  final Duration interval;

  Timer? _timer;

  bool _isRunning = false;

  /// Called every heartbeat
  Future<void> Function()? onHeartbeat;

  void start({
    required VideoSource source,
    required Duration Function() currentPosition,
  }) {
    stop();

    _isRunning = true;

    _timer = Timer.periodic(interval, (_) async {
      if (!_isRunning) return;

      final position = currentPosition();

      await AnalyticsService.instance.heartbeat(
        contentId: source.id,
        watchTime: position.inSeconds,
      );

      if (onHeartbeat != null) {
        await onHeartbeat!();
      }
    });
  }

  void pause() {
    _isRunning = false;
  }

  void resume() {
    _isRunning = true;
  }

  void stop() {
    _timer?.cancel();
    _timer = null;
    _isRunning = false;
  }

  void dispose() {
    stop();
  }
}