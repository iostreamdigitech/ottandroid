import 'dart:async';
import 'dart:convert';
import 'dart:js_interop';
import '../../features/payment/web/razorpay_web.dart';
import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';

import '../../analytics/services/payment_tracker.dart';
import '../../core/services/app_config_service.dart';
import '../../core/utils/app_logger.dart';
import '../../core/utils/json_parse.dart';
import '../../models/create_payment_orderResponse.dart';
import '../../models/verify_transaction_response.dart';
import '../../services/subscription_api_service.dart';
import '../models/payment_request.dart';
import '../models/payment_state.dart';

/// The one place that talks to Razorpay.
///
/// Every purchase - subscription or rental - runs through here:
///
///   pay(request)
///        -> create order API          (PaymentStatus.creatingOrder)
///        -> Razorpay checkout         (PaymentStatus.openingRazorpay)
///        -> verify transaction API    (PaymentStatus.verifying)
///        -> success / failed
///
/// The Razorpay success callback only proves the checkout sheet closed
/// happily. A purchase counts as bought exclusively when the verify-transaction
/// API says so.
///
/// There is a single, app-wide instance so the gateway listeners are
/// registered exactly once. Reach it through [instance].
class PaymentEngine extends GetxController {
  /// The app-wide engine, created on first use.
  ///
  /// Permanent on purpose: one Razorpay instance, one set of listeners, for
  /// the lifetime of the app.
  static PaymentEngine get instance {
    return Get.isRegistered<PaymentEngine>()
        ? Get.find<PaymentEngine>()
        : Get.put(PaymentEngine(), permanent: true);
  }

  final SubscriptionApiService api = SubscriptionApiService();

  /// Null on web - `razorpay_flutter` has no web implementation.
  Razorpay? _razorpay;

  // ---------------------------------------------------------------------------
  // STATE
  //
  // The payment UI is a pure function of these values.
  // ---------------------------------------------------------------------------

  final Rx<PaymentStatus> paymentStatus = PaymentStatus.idle.obs;

  final Rx<PaymentFailureKind> failureKind =
      PaymentFailureKind.unexpected.obs;

  /// Heading for the current payment screen.
  final RxString paymentTitle = ''.obs;

  /// Body copy for the current payment screen.
  final RxString paymentMessage = ''.obs;

  /// Optional extra line on the failure screen - the backend or gateway
  /// message, already stripped of anything technical.
  final RxString paymentErrorDetail = ''.obs;

  /// Razorpay order id for the attempt in flight.
  final RxString orderId = ''.obs;

  /// Our transaction reference, shown on the result screen.
  final RxString transactionId = ''.obs;

  /// What is being bought, so the placeholder can name it.
  final RxString itemTitle = ''.obs;

  /// Label for the button on the success screen.
  final RxString continueLabel = 'Continue'.obs;

  /// Verified purchase details, when the backend returned them.
  final Rxn<VerifyTransactionResponse> verification =
  Rxn<VerifyTransactionResponse>();

  PaymentRequest? _request;
  CreatePaymentOrderResponse? _order;

  /// Completes when the attempt in flight reaches a terminal state.
  Completer<bool>? _pending;

  /// Longest backend/gateway message we will put in front of a user.
  static const int _maxDetailLength = 180;

  /// True while an attempt is running or its result is still on screen.
  bool get isBusy => paymentStatus.value != PaymentStatus.idle;

  // ---------------------------------------------------------------------------
  // LIFECYCLE
  // ---------------------------------------------------------------------------

  @override
  void onInit() {
    super.onInit();
    _initializeRazorpay();
  }

  /// Razorpay is constructed and subscribed exactly once.
  ///
  /// Registering the listeners twice would deliver every payment callback
  /// twice, which on the success path means verifying - and potentially
  /// double-settling - the same transaction.
  void _initializeRazorpay() {
    AppLogger.log(
      '[PaymentEngine] Razorpay initialization started | '
          'kIsWeb=$kIsWeb | '
          'isClosed=$isClosed | '
          'existingInstance=${_razorpay != null}',
    );

    if (kIsWeb) {
      AppLogger.log(
        '[PaymentEngine] Running on Web. '
            'razorpay_flutter will not be initialized. '
            'Web checkout will use the web payment implementation.',
      );
      return;
    }

    if (_razorpay != null) {
      AppLogger.log(
        '[PaymentEngine] Razorpay already initialized.',
      );
      return;
    }

    try {
      final Razorpay razorpay = Razorpay();

      AppLogger.log(
        '[PaymentEngine] Razorpay instance created.',
      );

      razorpay.on(
        Razorpay.EVENT_PAYMENT_SUCCESS,
        _handlePaymentSuccess,
      );

      AppLogger.log(
        '[PaymentEngine] PAYMENT_SUCCESS listener registered.',
      );

      razorpay.on(
        Razorpay.EVENT_PAYMENT_ERROR,
        _handlePaymentError,
      );

      AppLogger.log(
        '[PaymentEngine] PAYMENT_ERROR listener registered.',
      );

      razorpay.on(
        Razorpay.EVENT_EXTERNAL_WALLET,
        _handleExternalWallet,
      );

      AppLogger.log(
        '[PaymentEngine] EXTERNAL_WALLET listener registered.',
      );

      _razorpay = razorpay;

      AppLogger.log(
        '[PaymentEngine] Razorpay initialization completed | '
            'initialized=${_razorpay != null}',
      );
    } catch (e, stackTrace) {
      AppLogger.error(
        '[PaymentEngine] Razorpay initialization failed: $e\n'
            '$stackTrace',
      );
    }
  }

  @override
  void onClose() {
    // Drops every listener, so a late callback cannot reach a disposed engine.
    _razorpay?.clear();
    _razorpay = null;

    // Never leave a caller awaiting a future that can no longer complete.
    _settle(false);

    super.onClose();
  }

  // ---------------------------------------------------------------------------
  // ENTRY POINT
  // ---------------------------------------------------------------------------

  /// Runs one purchase end to end.
  ///
  /// Resolves `true` only once the backend has verified the transaction.
  /// Resolves `false` for every other outcome, including a duplicate call
  /// while another attempt is still in flight.
  ///
  /// The result screen stays up after this resolves - the caller decides what
  /// the Continue button does, then calls [reset].
  Future<bool> pay(PaymentRequest request) {
    // One order per tap, however fast the taps come.
    if (isBusy) {
      return Future<bool>.value(false);
    }

    _begin(request);

    final completer = Completer<bool>();
    _pending = completer;

    unawaited(_createOrder(request));

    return completer.future;
  }

  // ---------------------------------------------------------------------------
  // STEP 1 - CREATE ORDER
  // ---------------------------------------------------------------------------

  Future<void> _createOrder(PaymentRequest request) async {
    unawaited(
      PaymentTracker.paymentStarted(
        planId: request.analyticsItemId,
        amount: request.displayAmount,
        currency: request.currency,
      ),
    );

    try {
      final order = await api.createOrder(
        payload: request.orderPayload,
      );

      if (isClosed) {
        return;
      }

      _order = order;
      orderId.value = order.razorpayOrderId;
      transactionId.value = order.transactionId;

      if (!order.isUsable) {
        _fail(
          kind: PaymentFailureKind.orderCreation,
          detail: order.message.isNotEmpty
              ? order.message
              : 'The payment order returned by the server was incomplete.',
        );
        return;
      }

      _openCheckout(request, order);
    } catch (e) {
      if (isClosed) {
        return;
      }

      AppLogger.error('Create order failed: $e');

      _fail(
        kind: PaymentFailureKind.orderCreation,
        detail: e.toString(),
      );
    }
  }

  // ---------------------------------------------------------------------------
  // STEP 2 - RAZORPAY CHECKOUT
  // ---------------------------------------------------------------------------

  void _openCheckout(PaymentRequest request,
      CreatePaymentOrderResponse order,) {
    AppLogger.log(
      '[PaymentEngine] Opening checkout | '
          'platform=${kIsWeb ? "WEB" : "MOBILE"} | '
          'orderId=${order.razorpayOrderId} | '
          'transactionId=${order.transactionId}',
    );

    _setProgress(PaymentStatus.openingRazorpay);

    if (kIsWeb) {
      AppLogger.log(
        '[PaymentEngine] Web platform detected. '
            'Using web Razorpay checkout.',
      );

      _openWebRazorpay(request, order);
      return;
    }

    final Razorpay? razorpay = _razorpay;

    AppLogger.log(
      '[PaymentEngine] Mobile Razorpay instance check | '
          'initialized=${razorpay != null}',
    );

    if (razorpay == null) {
      AppLogger.error(
        '[PaymentEngine] Razorpay instance is NULL on mobile.',
      );

      _fail(
        kind: PaymentFailureKind.gateway,
        detail: 'Payment gateway is unavailable on this device.',
      );
      return;
    }

    final String keyId = order.razorpayKeyId.isNotEmpty
        ? order.razorpayKeyId
        : AppConfigService.razorpayKeyId;

    AppLogger.log(
      '[PaymentEngine] Razorpay configuration | '
          'keyConfigured=${keyId.isNotEmpty} | '
          'currency=${order.currency} | '
          'amount=${order.amountInMinorUnits}',
    );

    if (keyId.isEmpty) {
      AppLogger.error(
        '[PaymentEngine] Razorpay key ID is missing.',
      );

      _fail(
        kind: PaymentFailureKind.gateway,
        detail: 'Payment gateway is not configured.',
      );
      return;
    }

    final options = {
      'key': keyId,
      'amount': order.amountInMinorUnits,
      'currency': order.currency,
      'name': AppConfigService.razorpayMerchantName,
      'description': request.description,
      'order_id': order.razorpayOrderId,
      'timeout': AppConfigService.razorpayCheckoutTimeoutSeconds,
      'prefill': _prefillFor(order),
      'notes': {
        ...request.gatewayNotes,
        'transaction_id': order.transactionId,
      },
      'theme': {
        'color': AppConfigService.razorpayThemeColor,
      },
    };

    AppLogger.log(
      '[PaymentEngine] Calling razorpay.open() | '
          'orderId=${order.razorpayOrderId}',
    );

    try {
      razorpay.open(options);

      AppLogger.log(
        '[PaymentEngine] razorpay.open() invoked successfully.',
      );
    } catch (e, stackTrace) {
      AppLogger.error(
        '[PaymentEngine] razorpay.open() failed: $e\n'
            '$stackTrace',
      );

      _fail(
        kind: PaymentFailureKind.gateway,
        detail: e.toString(),
      );
    }
  }

  /// Razorpay rejects blank prefill values, so only send what we actually have.
  Map<String, dynamic> _prefillFor(CreatePaymentOrderResponse order) {
    return {
      if (order.customerName.isNotEmpty) 'name': order.customerName,
      if (order.customerEmail.isNotEmpty) 'email': order.customerEmail,
      if (order.customerPhone.isNotEmpty) 'contact': order.customerPhone,
    };
  }

  // ---------------------------------------------------------------------------
  // STEP 3 - VERIFY TRANSACTION
  // ---------------------------------------------------------------------------

  Future<void> _handlePaymentSuccess(PaymentSuccessResponse response,) async {
    if (isClosed || !_acceptsGatewayCallback()) {
      return;
    }

    _setProgress(PaymentStatus.verifying);

    try {
      final result = await api.verifyTransaction(
        razorpayOrderId: JsonParse.text(
          response.orderId,
          fallback: orderId.value,
        ),
        razorpayPaymentId: JsonParse.text(response.paymentId),
        razorpaySignature: JsonParse.text(response.signature),
        transactionId: _order?.transactionId,
        purchaseOrderId: _order?.purchaseOrderId,
        paymentTransactionId: _order?.paymentTransactionId,
      );

      if (isClosed) {
        return;
      }

      if (result.isVerified) {
        _succeed(result);
      } else {
        _fail(
          kind: PaymentFailureKind.verification,
          detail: result.message,
        );
      }
    } catch (e) {
      if (isClosed) {
        return;
      }

      AppLogger.error('Verify transaction failed: $e');

      // The money may well have left the account - say nothing that implies
      // otherwise, and keep the references so support can trace it.
      _fail(
        kind: PaymentFailureKind.verification,
        detail: e.toString(),
      );
    }
  }

  void _succeed(VerifyTransactionResponse result) {
    verification.value = result;

    if (result.transactionId.isNotEmpty) {
      transactionId.value = result.transactionId;
    }

    if (result.orderId.isNotEmpty) {
      orderId.value = result.orderId;
    }

    paymentStatus.value = PaymentStatus.success;
    paymentTitle.value = 'Payment Successful';
    paymentMessage.value = _request?.successMessage ??
        'Your purchase was completed successfully.';
    paymentErrorDetail.value = '';

    unawaited(
      PaymentTracker.paymentSuccess(
        transactionId: transactionId.value,
        planId: _request?.analyticsItemId ?? '',
        amount: _request?.displayAmount ?? 0,
      ),
    );

    _settle(true);
  }

  // ---------------------------------------------------------------------------
  // RAZORPAY FAILURE / CANCELLATION
  // ---------------------------------------------------------------------------

  void _handlePaymentError(PaymentFailureResponse response) {
    if (isClosed || !_acceptsGatewayCallback()) {
      return;
    }

    final bool cancelled = response.code == Razorpay.PAYMENT_CANCELLED;

    AppLogger.warn(
      'Razorpay error ${response.code}: ${response.message}',
    );

    _fail(
      kind: cancelled
          ? PaymentFailureKind.cancelled
          : PaymentFailureKind.gateway,

      // A cancellation needs no explanation - the user just did it.
      detail: cancelled ? '' : _describeGatewayError(response),

      errorCode: response.code?.toString(),
    );
  }

  void _handleExternalWallet(ExternalWalletResponse response) {
    if (isClosed || !_acceptsGatewayCallback()) {
      return;
    }

    // Razorpay still delivers a success or error event once the wallet
    // finishes, so the flow stays exactly where it is - only the wording
    // changes while the user is away in the wallet app.
    final String wallet = JsonParse.text(response.walletName);

    if (wallet.isNotEmpty) {
      paymentMessage.value = 'Completing payment with $wallet...';
    }
  }

  /// Whether a gateway callback belongs to the attempt currently in flight.
  ///
  /// `razorpay_flutter` replays lost responses when listeners are registered,
  /// so a callback can arrive for an attempt that already ended. Acting on one
  /// would overwrite a finished result, or verify a transaction twice.
  bool _acceptsGatewayCallback() {
    if (paymentStatus.value == PaymentStatus.openingRazorpay) {
      return true;
    }

    AppLogger.warn(
      'Ignored a Razorpay callback arriving in state '
          '${paymentStatus.value}',
    );

    return false;
  }

  // ---------------------------------------------------------------------------
  // STATE TRANSITIONS
  // ---------------------------------------------------------------------------

  void _begin(PaymentRequest request) {
    _request = request;
    _order = null;
    verification.value = null;
    orderId.value = '';
    transactionId.value = '';
    paymentErrorDetail.value = '';
    itemTitle.value = request.itemTitle;
    continueLabel.value = request.continueLabel;

    _setProgress(PaymentStatus.creatingOrder);
  }

  void _setProgress(PaymentStatus status) {
    paymentStatus.value = status;
    paymentTitle.value = status.progressTitle;
    paymentMessage.value = status.progressMessage;
  }

  void _fail({
    required PaymentFailureKind kind,
    String? detail,
    String? errorCode,
  }) {
    failureKind.value = kind;
    paymentStatus.value = PaymentStatus.failed;
    paymentTitle.value = kind.title;
    paymentMessage.value = kind.message;
    paymentErrorDetail.value = _presentable(detail);

    unawaited(
      PaymentTracker.paymentFailed(
        reason: kind.analyticsReason,
        errorCode: errorCode,
      ),
    );

    _settle(false);
  }

  /// Resolves the pending [pay] future exactly once.
  void _settle(bool purchased) {
    final Completer<bool>? pending = _pending;
    _pending = null;

    if (pending != null && !pending.isCompleted) {
      pending.complete(purchased);
    }
  }

  /// Dismisses the result screen and clears every trace of the attempt.
  ///
  /// Called once the caller has acted on the outcome, so the next purchase
  /// creates a brand new order rather than reusing a dead one.
  void reset() {
    _request = null;
    _order = null;
    verification.value = null;
    orderId.value = '';
    transactionId.value = '';
    itemTitle.value = '';
    paymentTitle.value = '';
    paymentMessage.value = '';
    paymentErrorDetail.value = '';
    paymentStatus.value = PaymentStatus.idle;
  }

  // ---------------------------------------------------------------------------
  // HELPERS
  // ---------------------------------------------------------------------------

  /// Pulls the human-readable part out of a Razorpay failure.
  ///
  /// Razorpay hands back either a populated error map or a JSON envelope
  /// stuffed into `message`.
  String _describeGatewayError(PaymentFailureResponse response) {
    final String fromBody = _descriptionIn(
      JsonParse.object(response.error),
    );

    if (fromBody.isNotEmpty) {
      return fromBody;
    }

    final String raw = JsonParse.text(response.message);

    if (raw.isEmpty || !raw.startsWith('{')) {
      return raw;
    }

    try {
      final String decoded = _descriptionIn(
        JsonParse.object(jsonDecode(raw)),
      );

      if (decoded.isNotEmpty) {
        return decoded;
      }
    } catch (_) {
      // Not JSON after all - fall through to the raw string.
    }

    return raw;
  }

  /// Reads a gateway description, whether it sits at the top level or under
  /// an `error` envelope.
  String _descriptionIn(Map<String, dynamic>? body) {
    if (body == null) {
      return '';
    }

    final Map<String, dynamic> source =
        JsonParse.object(body['error']) ?? body;

    return JsonParse.text(
      JsonParse.pick(source, const [
        'description',
        'reason',
        'message',
      ]),
    );
  }

  /// Makes a thrown error safe to show.
  ///
  /// Strips the exception prefix, keeps only the first line so a stack trace
  /// can never reach the screen, and drops anything that still looks internal.
  String _presentable(String? raw) {
    var text = (raw ?? '').trim();

    if (text.isEmpty) {
      return '';
    }

    text = text.replaceFirst(
      RegExp(r'^(_?Exception|Error|DioException)\s*:\s*'),
      '',
    );

    final String firstLine = text
        .split('\n')
        .first
        .trim();

    if (firstLine.isEmpty ||
        firstLine.contains('#0') ||
        firstLine.startsWith('Instance of')) {
      return '';
    }

    if (firstLine.length <= _maxDetailLength) {
      return firstLine;
    }

    return '${firstLine.substring(0, _maxDetailLength)}...';
  }

  void _handleWebPaymentFailure(RazorpayWebFailureResponse response,) {
    if (isClosed || !_acceptsGatewayCallback()) {
      AppLogger.warn(
        '[PaymentEngine] Ignoring WEB failure callback | '
            'closed=$isClosed | '
            'status=${paymentStatus.value}',
      );
      return;
    }

    AppLogger.warn(
      '[PaymentEngine] WEB Razorpay payment failure callback received.',
    );

    final String code = response.code.trim();
    final String description = response.description.trim();
    final String reason = response.reason.trim();
    final String source = response.source.trim();
    final String step = response.step.trim();

    final String orderIdFromResponse =
    response.orderId
        .trim()
        .isNotEmpty
        ? response.orderId.trim()
        : orderId.value.trim();

    AppLogger.warn(
      '[PaymentEngine] WEB Razorpay failure details | '
          'code=$code | '
          'description=${_presentable(description)} | '
          'reason=$reason | '
          'source=$source | '
          'step=$step | '
          'orderId=$orderIdFromResponse',
    );

    // Razorpay cancellation codes/reasons can vary.
    final String normalizedCode = code.toUpperCase();
    final String normalizedReason = reason.toUpperCase();

    final bool isCancelled =
        normalizedCode == 'PAYMENT_CANCELLED' ||
            normalizedCode == 'USER_CANCELLED' ||
            normalizedReason == 'CANCELLED' ||
            normalizedReason == 'USER_CANCELLED';

    if (isCancelled) {
      AppLogger.log(
        '[PaymentEngine] WEB Razorpay checkout cancelled by user | '
            'orderId=$orderIdFromResponse',
      );

      _fail(
        kind: PaymentFailureKind.cancelled,
        detail: 'Payment was cancelled.',
      );

      return;
    }

    final String detail = _presentable(
      description.isNotEmpty
          ? description
          : reason.isNotEmpty
          ? reason
          : 'Payment failed. Please try again.',
    );

    AppLogger.error(
      '[PaymentEngine] WEB Razorpay payment failed | '
          'code=$code | '
          'orderId=$orderIdFromResponse | '
          'detail=$detail',
    );

    _fail(
      kind: PaymentFailureKind.gateway,
      detail: detail,
    );
  }

  void _openWebRazorpay(PaymentRequest request,
      CreatePaymentOrderResponse order,) {
    AppLogger.log(
      '[PaymentEngine] WEB Razorpay checkout starting | '
          'orderId=${order.razorpayOrderId} | '
          'transactionId=${order.transactionId}',
    );

    final String keyId = order.razorpayKeyId.isNotEmpty
        ? order.razorpayKeyId
        : AppConfigService.razorpayKeyId;

    if (keyId.isEmpty) {
      AppLogger.error(
        '[PaymentEngine] WEB Razorpay key is missing.',
      );

      _fail(
        kind: PaymentFailureKind.gateway,
        detail: 'Payment gateway is not configured.',
      );
      return;
    }

    try {
      RazorpayWeb.open(
        key: keyId,
        amount: order.amountInMinorUnits,
        currency: order.currency,
        name: AppConfigService.razorpayMerchantName,
        description: request.description,
        orderId: order.razorpayOrderId,

        onSuccess: (response) {
          AppLogger.log(
            '[PaymentEngine] WEB Razorpay success callback received | '
                'paymentId=${response.paymentId} | '
                'orderId=${response.orderId} | '
                'signaturePresent=${response.signature.isNotEmpty}',
          );

          _handleWebPaymentSuccess(response);
        },

        onFailure: (response) {
          AppLogger.error(
            '[PaymentEngine] WEB Razorpay failure callback received | '
                'code=${response.code} | '
                'description=${response.description}',
          );

          _handleWebPaymentFailure(response);
        },
      );

      AppLogger.log(
        '[PaymentEngine] WEB Razorpay checkout opened.',
      );
    } catch (e, stackTrace) {
      AppLogger.error(
        '[PaymentEngine] WEB Razorpay open failed: $e\n$stackTrace',
      );

      _fail(
        kind: PaymentFailureKind.gateway,
        detail: e.toString(),
      );
    }
  }

  Map<String, dynamic> _jsToMap(JSAny? raw) {
    if (raw == null) {
      return <String, dynamic>{};
    }

    final dynamic value = raw.dartify();

    if (value is Map) {
      return Map<String, dynamic>.from(value);
    }

    return <String, dynamic>{};
  }

  Future<void> _handleWebPaymentSuccess(
      RazorpayWebSuccessResponse response,) async {
    if (isClosed || !_acceptsGatewayCallback()) {
      AppLogger.warn(
        '[PaymentEngine] Ignoring WEB success callback | '
            'closed=$isClosed | '
            'status=${paymentStatus.value}',
      );
      return;
    }

    AppLogger.log(
      '[PaymentEngine] WEB Razorpay success callback received.',
    );

    _setProgress(PaymentStatus.verifying);

    final String razorpayPaymentId =
    response.paymentId.trim();

    // The Web callback does not contain razorpay_order_id.
    // Use the order ID created by our backend.
    final String razorpayOrderId =
    response.orderId
        .trim()
        .isNotEmpty
        ? response.orderId.trim()
        : orderId.value.trim();

    AppLogger.log(
      '[PaymentEngine] WEB payment response extracted | '
          'orderId=$razorpayOrderId | '
          'paymentId=$razorpayPaymentId',
    );

    // --------------------------------------------------
    // Validate callback
    // --------------------------------------------------

    if (razorpayPaymentId.isEmpty) {
      AppLogger.error(
        '[PaymentEngine] WEB Razorpay payment ID is missing.',
      );

      _fail(
        kind: PaymentFailureKind.verification,
        detail: 'Payment ID was not received from Razorpay.',
      );

      return;
    }

    if (razorpayOrderId.isEmpty) {
      AppLogger.error(
        '[PaymentEngine] WEB Razorpay order ID is missing.',
      );

      _fail(
        kind: PaymentFailureKind.verification,
        detail: 'Payment order ID is missing.',
      );

      return;
    }

    // --------------------------------------------------
    // Validate against the order created by our backend
    // --------------------------------------------------

    final String expectedOrderId =
    orderId.value.trim();

    if (expectedOrderId.isNotEmpty &&
        expectedOrderId != razorpayOrderId) {
      AppLogger.error(
        '[PaymentEngine] WEB Razorpay order ID mismatch | '
            'expected=$expectedOrderId | '
            'received=$razorpayOrderId',
      );

      _fail(
        kind: PaymentFailureKind.verification,
        detail: 'Payment order validation failed.',
      );

      return;
    }

    // --------------------------------------------------
    // Server-side WEB verification
    // --------------------------------------------------

    try {
      AppLogger.log(
        '[PaymentEngine] Calling server-side WEB payment verification | '
            'orderId=$razorpayOrderId | '
            'paymentId=$razorpayPaymentId',
      );

      final result = await api.verifyWebTransaction(
        razorpayOrderId: razorpayOrderId,
        razorpayPaymentId: razorpayPaymentId,
        transactionId: _order?.transactionId,
        purchaseOrderId: _order?.purchaseOrderId,
        paymentTransactionId: _order?.paymentTransactionId,
      );

      if (isClosed) {
        return;
      }

      AppLogger.log(
        '[PaymentEngine] WEB verification completed | '
            'verified=${result.isVerified} | '
            'transactionId=${result.transactionId} | '
            'message=${result.message}',
      );

      if (result.paymentStatus=="PAYMENT_SUCCESS") {
        AppLogger.log(
          '[PaymentEngine] WEB PAYMENT VERIFIED SUCCESSFULLY | '
              'orderId=$razorpayOrderId | '
              'paymentId=$razorpayPaymentId',
        );

        _succeed(result);
        return;
      }

      AppLogger.error(
        '[PaymentEngine] WEB PAYMENT VERIFICATION FAILED | '
            'orderId=$razorpayOrderId | '
            'paymentId=$razorpayPaymentId | '
            'message=${result.message}',
      );

      _fail(
        kind: PaymentFailureKind.verification,
        detail: result.message.isNotEmpty
            ? result.message
            : 'Payment verification failed.',
      );
    } catch (e, stackTrace) {
      if (isClosed) {
        return;
      }

      AppLogger.error(
        '[PaymentEngine] WEB payment verification failed: '
            '$e\n$stackTrace',
      );

      _fail(
        kind: PaymentFailureKind.verification,
        detail: 'Unable to verify the payment. Please try again.',
      );
    }
  }
}
