import 'package:flutter/material.dart';

import '../models/audio_track_model.dart';

class OTTAudioSelector extends StatelessWidget {
  final List<AudioTrackModel> audioTracks;
  final AudioTrackModel? selectedTrack;
  final ValueChanged<AudioTrackModel> onTrackSelected;

  const OTTAudioSelector({
    super.key,
    required this.audioTracks,
    required this.selectedTrack,
    required this.onTrackSelected,
  });

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: Colors.black87,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      title: const Text(
        "Audio",
        style: TextStyle(color: Colors.white),
      ),
      content: SizedBox(
        width: 320,
        child: ListView.separated(
          shrinkWrap: true,
          itemCount: audioTracks.length,
          separatorBuilder: (_, __) =>
          const Divider(color: Colors.white24),
          itemBuilder: (_, index) {
            final track = audioTracks[index];

            final selected =
                selectedTrack?.id == track.id;

            return ListTile(
              leading: Icon(
                selected
                    ? Icons.check_circle
                    : Icons.volume_up_outlined,
                color: Colors.white,
              ),
              title: Text(
                track.languageName,
                style: const TextStyle(
                  color: Colors.white,
                ),
              ),
              subtitle: Text(
                track.label,
                style: const TextStyle(
                  color: Colors.white70,
                  fontSize: 12,
                ),
              ),
              trailing: Text(
                _audioType(track.type),
                style: const TextStyle(
                  color: Colors.grey,
                  fontSize: 11,
                ),
              ),
              onTap: () {
                Navigator.pop(context);
                onTrackSelected(track);
              },
            );
          },
        ),
      ),
    );
  }

  static String _audioType(AudioTrackType type) {
    switch (type) {
      case AudioTrackType.stereo:
        return "Stereo";

      case AudioTrackType.surround51:
        return "5.1";

      case AudioTrackType.surround71:
        return "7.1";

      case AudioTrackType.dolbyAtmos:
        return "Dolby Atmos";

      case AudioTrackType.commentary:
        return "Commentary";

      case AudioTrackType.descriptive:
        return "Audio Description";
    }
  }

  static Future<void> show(
      BuildContext context, {
        required List<AudioTrackModel> tracks,
        required AudioTrackModel? selected,
        required ValueChanged<AudioTrackModel> onSelected,
      }) {
    return showDialog(
      context: context,
      builder: (_) => OTTAudioSelector(
        audioTracks: tracks,
        selectedTrack: selected,
        onTrackSelected: onSelected,
      ),
    );
  }
}