import 'package:better_player/better_player.dart';
import 'package:flutter/material.dart';

import '../controllers/ott_player_controller.dart';
import '../models/video_source.dart';
import 'ott_buffer_indicator.dart';
import 'ott_player_controls.dart';
import 'ott_progress_bar.dart';

class OTTVideoPlayer extends StatefulWidget {
  final OTTPlayerController controller;
  final VideoSource source;

  const OTTVideoPlayer({
    super.key,
    required this.controller,
    required this.source,
  });

  @override
  State<OTTVideoPlayer> createState() => _OTTVideoPlayerState();
}

class _OTTVideoPlayerState extends State<OTTVideoPlayer> {
  late BetterPlayerController _betterPlayer;

  bool _buffering = false;

  @override
  void initState() {
    super.initState();

    _initializePlayer();
  }

  Future<void> _initializePlayer() async {
    BetterPlayerDataSource dataSource;

    if (widget.source.isDrmProtected && widget.source.drm != null) {
      dataSource = BetterPlayerDataSource(
        BetterPlayerDataSourceType.network,
        widget.source.url,
        headers: widget.source.headers,
        drmConfiguration: BetterPlayerDrmConfiguration(
          drmType: BetterPlayerDrmType.widevine,
          licenseUrl: widget.source.drm!.licenseUrl!,
          headers: widget.source.drm!.headers,
        ),
      );
    } else {
      dataSource = BetterPlayerDataSource(
        BetterPlayerDataSourceType.network,
        widget.source.url,
        headers: widget.source.headers,
      );
    }

    _betterPlayer = BetterPlayerController(
      const BetterPlayerConfiguration(
        autoPlay: true,
        controlsConfiguration: BetterPlayerControlsConfiguration(
          showControls: false,
        ),
      ),
    );

    await _betterPlayer.setupDataSource(dataSource);

    await widget.controller.initialize(
      player: _betterPlayer,
      source: widget.source,
    );

    _betterPlayer.addEventsListener(_onPlayerEvent);

    if (mounted) {
      setState(() {});
    }
  }

  void _onPlayerEvent(BetterPlayerEvent event) {
    switch (event.betterPlayerEventType) {
      case BetterPlayerEventType.bufferingStart:
        setState(() => _buffering = true);
        break;

      case BetterPlayerEventType.bufferingEnd:
        setState(() => _buffering = false);
        break;

      case BetterPlayerEventType.finished:
        widget.controller.completed();
        break;

      default:
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!widget.controller.isInitialized) {
      return const Center(
        child: CircularProgressIndicator(),
      );
    }

    return AspectRatio(
      aspectRatio: 16 / 9,
      child: Stack(
        fit: StackFit.expand,
        children: [
          BetterPlayer(controller: _betterPlayer),

          OTTBufferIndicator(
            isBuffering: _buffering,
          ),

          OTTPlayerControls(
            controller: widget.controller,

            onFullscreen: () {
              widget.controller.enterFullscreen();
            },

            onSpeed: () {
             // OTTSpeedSelector.show(...)
            },

            onAudio: () {
              // OTTAudioSelector.show(...)
            },

            onSubtitle: () {
              // OTTSubtitleSelector.show(...)
            },

            onQuality: () {
              // OTTQualitySelector.show(...)
            },

            onSkipIntro: () {},

            onNextEpisode: () {},
          ),

          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: OTTProgressBar(
              controller: widget!.controller,
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _betterPlayer.removeEventsListener(_onPlayerEvent);
    widget.controller.dispose();
    super.dispose();
  }
}