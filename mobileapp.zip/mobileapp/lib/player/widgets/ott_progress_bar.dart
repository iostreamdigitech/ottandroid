import 'package:flutter/material.dart';
import 'package:ottoneapp/player/widgets/player_state.dart';

import '../controllers/ott_player_controller.dart';


class OTTProgressBar extends StatelessWidget {
  final OTTPlayerController controller;

  const OTTProgressBar({
    super.key,
    required this.controller,
  });

  String _format(Duration d) {
    String two(int n) => n.toString().padLeft(2, '0');

    if (d.inHours > 0) {
      return "${two(d.inHours)}:${two(d.inMinutes.remainder(60))}:${two(d.inSeconds.remainder(60))}";
    }

    return "${two(d.inMinutes)}:${two(d.inSeconds.remainder(60))}";
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<PlayerState>(
      valueListenable: controller.state,
      builder: (context, state, child) {
        final duration = state.duration;
        final position = state.position;

        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Slider(
              min: 0,
              max: duration.inMilliseconds > 0
                  ? duration.inMilliseconds.toDouble()
                  : 1,
              value: position.inMilliseconds
                  .clamp(0, duration.inMilliseconds > 0 ? duration.inMilliseconds : 1)
                  .toDouble(),
              onChanged: (value) {
                controller.seek(
                  Duration(milliseconds: value.toInt()),
                );
              },
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Row(
                children: [
                  Text(
                    _format(position),
                    style: const TextStyle(color: Colors.white),
                  ),
                  const Spacer(),
                  Text(
                    _format(duration),
                    style: const TextStyle(color: Colors.white),
                  ),
                ],
              ),
            ),
          ],
        );
      },
    );
  }
}