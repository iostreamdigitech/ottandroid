import 'package:flutter/material.dart';

import '../models/subtitle_model.dart';

class OTTSubtitleSelector extends StatelessWidget {
  final List<SubtitleModel> subtitles;
  final SubtitleModel? selectedSubtitle;
  final ValueChanged<SubtitleModel?> onSubtitleSelected;

  const OTTSubtitleSelector({
    super.key,
    required this.subtitles,
    required this.selectedSubtitle,
    required this.onSubtitleSelected,
  });

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: Colors.black87,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      title: const Text(
        "Subtitles",
        style: TextStyle(color: Colors.white),
      ),
      content: SizedBox(
        width: 320,
        child: ListView.separated(
          shrinkWrap: true,
          itemCount: subtitles.length + 1,
          separatorBuilder: (_, __) =>
          const Divider(color: Colors.white24),
          itemBuilder: (_, index) {
            if (index == 0) {
              final off = selectedSubtitle == null;

              return ListTile(
                leading: Icon(
                  off
                      ? Icons.check_circle
                      : Icons.subtitles_off,
                  color: Colors.white,
                ),
                title: const Text(
                  "Off",
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.pop(context);
                  onSubtitleSelected(null);
                },
              );
            }

            final subtitle = subtitles[index - 1];

            final selected =
                selectedSubtitle?.id ==
                    subtitle.id;

            return ListTile(
              leading: Icon(
                selected
                    ? Icons.check_circle
                    : Icons.subtitles,
                color: Colors.white,
              ),
              title: Text(
                subtitle.languageName,
                style: const TextStyle(
                  color: Colors.white,
                ),
              ),
              subtitle: Text(
                subtitle.label,
                style: const TextStyle(
                  color: Colors.white70,
                  fontSize: 12,
                ),
              ),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (subtitle.isForced)
                    const Padding(
                      padding: EdgeInsets.only(right: 8),
                      child: Text(
                        "Forced",
                        style: TextStyle(
                          color: Colors.orange,
                          fontSize: 11,
                        ),
                      ),
                    ),
                  if (subtitle.isSDH)
                    const Text(
                      "SDH",
                      style: TextStyle(
                        color: Colors.green,
                        fontSize: 11,
                      ),
                    ),
                ],
              ),
              onTap: () {
                Navigator.pop(context);
                onSubtitleSelected(subtitle);
              },
            );
          },
        ),
      ),
    );
  }

  static Future<void> show(
      BuildContext context, {
        required List<SubtitleModel> subtitles,
        required SubtitleModel? selectedSubtitle,
        required ValueChanged<SubtitleModel?> onSelected,
      }) {
    return showDialog(
      context: context,
      builder: (_) => OTTSubtitleSelector(
        subtitles: subtitles,
        selectedSubtitle: selectedSubtitle,
        onSubtitleSelected: onSelected,
      ),
    );
  }
}