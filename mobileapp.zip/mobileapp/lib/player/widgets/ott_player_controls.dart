import 'dart:async';

import 'package:better_player/better_player.dart';
import 'package:flutter/material.dart';
import 'package:ottoneapp/player/controllers/ott_player_controller.dart';
import 'package:ottoneapp/player/widgets/player_state.dart';

import 'ott_progress_bar.dart';

class OTTPlayerControls extends StatefulWidget {
  final OTTPlayerController controller;

  final VoidCallback? onFullscreen;

  final VoidCallback? onSpeed;

  final VoidCallback? onSubtitle;

  final VoidCallback? onAudio;

  final VoidCallback? onQuality;

  final VoidCallback? onNextEpisode;

  final VoidCallback? onSkipIntro;

  const OTTPlayerControls({
    super.key,
    required this.controller,
    this.onFullscreen,
    this.onSpeed,
    this.onSubtitle,
    this.onAudio,
    this.onQuality,
    this.onNextEpisode,
    this.onSkipIntro,
  });

  @override
  State<OTTPlayerControls> createState() =>
      _OTTPlayerControlsState();
}

class _OTTPlayerControlsState
    extends State<OTTPlayerControls> {
  bool _visible = true;

  Timer? _timer;

  @override
  void initState() {
    super.initState();

    _restartTimer();
  }

  void _restartTimer() {
    _timer?.cancel();

    _timer = Timer(
      const Duration(seconds: 5),
          () {
        if (mounted) {
          setState(() {
            _visible = false;
          });
        }
      },
    );
  }

  void _toggle() {
    setState(() {
      _visible = !_visible;
    });

    if (_visible) {
      _restartTimer();
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: _toggle,
      child: AnimatedOpacity(
        duration: const Duration(milliseconds: 250),
        opacity: _visible ? 1 : 0,
        child: Container(
          color: Colors.black26,
          child: Column(
            children: [

              //---------------- Top ----------------

              SafeArea(
                child: Row(
                  children: [

                    const Spacer(),

                    IconButton(
                      color: Colors.white,
                      icon: const Icon(Icons.speed),
                      onPressed: widget.onSpeed,
                    ),

                    IconButton(
                      color: Colors.white,
                      icon: const Icon(Icons.subtitles),
                      onPressed: widget.onSubtitle,
                    ),

                    IconButton(
                      color: Colors.white,
                      icon: const Icon(Icons.audiotrack),
                      onPressed: widget.onAudio,
                    ),

                    IconButton(
                      color: Colors.white,
                      icon: const Icon(Icons.hd),
                      onPressed: widget.onQuality,
                    ),
                  ],
                ),
              ),

              //---------------- Center ----------------

              Expanded(
                child: Row(
                  mainAxisAlignment:
                  MainAxisAlignment.center,
                  children: [

                    IconButton(
                      iconSize: 42,
                      color: Colors.white,
                      onPressed: () async {

                        final pos = widget.controller.state.value.position;



                        await widget.controller.seek(
                          pos -
                              const Duration(
                                seconds: 10,
                              ),
                        );
                      },
                      icon: const Icon(
                        Icons.replay_10,
                      ),
                    ),

                    const SizedBox(width: 20),

                    IconButton(
                      iconSize: 72,
                      color: Colors.white,
                      onPressed: () {
                        if (widget.controller.state.value.playing) {
                          widget.controller.pause();
                        } else {
                          widget.controller.play();
                        }

                        setState(() {});
                      },
                      icon: Icon(
                        widget.controller.state.value.playing
                            ? Icons.pause_circle
                            : Icons.play_circle,
                      ),
                    ),

                    const SizedBox(width: 20),

                    IconButton(
                      iconSize: 42,
                      color: Colors.white,
                      onPressed: () async {

                        final pos = widget.controller.state.value.position;

                        await widget.controller.seek(
                          pos + const Duration(seconds: 10),
                        );
                      },
                      icon: const Icon(
                        Icons.forward_10,
                      ),
                    ),
                  ],
                ),
              ),

              //---------------- Bottom ----------------

              OTTProgressBar(
                controller: widget!.controller,

              ),

              Padding(
                padding:
                const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 6,
                ),
                child: Row(
                  children: [

                    ValueListenableBuilder<PlayerState>(
                      valueListenable: widget.controller.state,
                      builder: (context, state, child) {
                        return Text(
                          _format(state.position),
                          style: const TextStyle(
                            color: Colors.white,
                          ),
                        );
                      },
                    ),
                    const Spacer(),

                    ElevatedButton(
                      onPressed:
                      widget.onSkipIntro,
                      child: const Text(
                        "Skip Intro",
                      ),
                    ),

                    const SizedBox(width: 8),

                    ElevatedButton(
                      onPressed:
                      widget.onNextEpisode,
                      child: const Text(
                        "Next",
                      ),
                    ),

                    IconButton(
                      color: Colors.white,
                      icon: const Icon(
                        Icons.fullscreen,
                      ),
                      onPressed:
                      widget.onFullscreen,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _format(Duration d) {
    String two(int n) =>
        n.toString().padLeft(2, '0');

    return "${two(d.inMinutes.remainder(60))}:${two(d.inSeconds.remainder(60))}";
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }
}