import 'package:flutter/foundation.dart';

@immutable
class PlayerState {
  final bool initialized;
  final bool playing;
  final bool buffering;
  final bool fullscreen;

  final Duration position;
  final Duration duration;
  final Duration buffered;

  final double speed;

  const PlayerState({
    this.initialized = false,
    this.playing = false,
    this.buffering = false,
    this.fullscreen = false,
    this.position = Duration.zero,
    this.duration = Duration.zero,
    this.buffered = Duration.zero,
    this.speed = 1.0,
  });

  PlayerState copyWith({
    bool? initialized,
    bool? playing,
    bool? buffering,
    bool? fullscreen,
    Duration? position,
    Duration? duration,
    Duration? buffered,
    double? speed,
  }) {
    return PlayerState(
      initialized: initialized ?? this.initialized,
      playing: playing ?? this.playing,
      buffering: buffering ?? this.buffering,
      fullscreen: fullscreen ?? this.fullscreen,
      position: position ?? this.position,
      duration: duration ?? this.duration,
      buffered: buffered ?? this.buffered,
      speed: speed ?? this.speed,
    );
  }
}