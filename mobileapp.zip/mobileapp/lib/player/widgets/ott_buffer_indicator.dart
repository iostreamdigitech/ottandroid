import 'package:flutter/material.dart';

class OTTBufferIndicator extends StatelessWidget {
  final bool isBuffering;
  final String? message;

  const OTTBufferIndicator({
    super.key,
    required this.isBuffering,
    this.message,
  });

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      ignoring: !isBuffering,
      child: AnimatedOpacity(
        duration: const Duration(milliseconds: 250),
        opacity: isBuffering ? 1 : 0,
        child: Container(
          color: Colors.black45,
          alignment: Alignment.center,
          child: Container(
            width: 180,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.black87,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const SizedBox(
                  width: 42,
                  height: 42,
                  child: CircularProgressIndicator(
                    strokeWidth: 3,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 18),
                Text(
                  message ?? "Buffering...",
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 15,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}