import 'package:flutter/material.dart';

class OTTSpeedSelector extends StatelessWidget {
  final double selectedSpeed;
  final ValueChanged<double> onSpeedChanged;

  const OTTSpeedSelector({
    super.key,
    required this.selectedSpeed,
    required this.onSpeedChanged,
  });

  static const List<double> speeds = [
    0.25,
    0.5,
    0.75,
    1.0,
    1.25,
    1.5,
    1.75,
    2.0,
  ];

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: Colors.black87,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      title: const Text(
        "Playback Speed",
        style: TextStyle(color: Colors.white),
      ),
      content: SizedBox(
        width: 250,
        child: ListView.builder(
          shrinkWrap: true,
          itemCount: speeds.length,
          itemBuilder: (_, index) {
            final speed = speeds[index];

            return ListTile(
              leading: Icon(
                selectedSpeed == speed
                    ? Icons.check_circle
                    : Icons.circle_outlined,
                color: Colors.white,
              ),
              title: Text(
                "${speed}x",
                style: const TextStyle(
                  color: Colors.white,
                ),
              ),
              onTap: () {
                Navigator.pop(context);
                onSpeedChanged(speed);
              },
            );
          },
        ),
      ),
    );
  }

  static Future<void> show(
      BuildContext context, {
        required double currentSpeed,
        required ValueChanged<double> onChanged,
      }) {
    return showDialog(
      context: context,
      builder: (_) => OTTSpeedSelector(
        selectedSpeed: currentSpeed,
        onSpeedChanged: onChanged,
      ),
    );
  }
}