import 'package:flutter/material.dart';

import '../models/video_quality.dart';



class OTTQualitySelector extends StatelessWidget {
  final List<VideoQuality> qualities;

  final VideoQuality selectedQuality;

  final ValueChanged<VideoQuality> onQualitySelected;

  const OTTQualitySelector({
    super.key,
    required this.qualities,
    required this.selectedQuality,
    required this.onQualitySelected,
  });

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: Colors.black87,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      title: const Text(
        "Video Quality",
        style: TextStyle(
          color: Colors.white,
        ),
      ),
      content: SizedBox(
        width: 320,
        child: ListView.separated(
          shrinkWrap: true,
          itemCount: qualities.length,
          separatorBuilder: (_, __) =>
          const Divider(
            color: Colors.white24,
          ),
          itemBuilder: (_, index) {
            final quality = qualities[index];

            final selected =
                selectedQuality.id == quality.id;

            return ListTile(
              leading: Icon(
                selected
                    ? Icons.check_circle
                    : Icons.hd,
                color: Colors.white,
              ),
              title: Text(
                quality.label,
                style: const TextStyle(
                  color: Colors.white,
                ),
              ),
              subtitle: Text(
                _bitrate(quality.bitrate),
                style: const TextStyle(
                  color: Colors.white70,
                ),
              ),
              trailing: quality.isAuto
                  ? const Chip(
                label: Text("AUTO"),
              )
                  : Text(
                "${quality.height}p",
                style: const TextStyle(
                  color: Colors.white,
                ),
              ),
              onTap: () {
                Navigator.pop(context);
                onQualitySelected(quality);
              },
            );
          },
        ),
      ),
    );
  }

  String _bitrate(int bitrate) {
    return "${(bitrate / 1000000).toStringAsFixed(1)} Mbps";
  }

  static Future<void> show(
      BuildContext context, {
        required List<VideoQuality> qualities,
        required VideoQuality selected,
        required ValueChanged<VideoQuality> onSelected,
      }) {
    return showDialog(
      context: context,
      builder: (_) => OTTQualitySelector(
        qualities: qualities,
        selectedQuality: selected,
        onQualitySelected: onSelected,
      ),
    );
  }
}