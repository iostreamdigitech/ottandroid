import 'package:flutter/cupertino.dart';

class SearchCategory {
  final String title;
  final IconData icon;

  const SearchCategory({
    required this.title,
    required this.icon,
  });
}