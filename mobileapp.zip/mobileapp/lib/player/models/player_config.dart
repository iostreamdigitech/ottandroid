import 'package:flutter/material.dart';

class PlayerConfig {
  final bool autoPlay;
  final bool looping;
  final bool allowFullScreen;
  final bool allowPip;
  final bool allowPlaybackSpeed;
  final bool allowQualitySelection;
  final bool allowSubtitles;
  final bool allowAudioTracks;
  final bool allowBrightnessControl;
  final bool allowVolumeControl;
  final bool allowGestureControls;
  final bool allowScreenSleep;
  final bool showControls;
  final bool showThumbnail;
  final bool showSkipIntro;
  final bool showNextEpisode;
  final bool rememberPlaybackPosition;
  final bool enableAnalytics;
  final bool enableHeartbeat;
  final bool enableResumePlayback;
  final bool enableOfflinePlayback;
  final bool enableCasting;
  final bool enableCache;

  final bool isLive;
  final bool isDrmProtected;

  final Duration heartbeatInterval;
  final Duration controlsHideDuration;
  final Duration skipDuration;
  final Duration bufferingTimeout;

  final double aspectRatio;
  final double playbackSpeed;

  final Color backgroundColor;

  const PlayerConfig({
    this.autoPlay = true,
    this.looping = false,
    this.allowFullScreen = true,
    this.allowPip = true,
    this.allowPlaybackSpeed = true,
    this.allowQualitySelection = true,
    this.allowSubtitles = true,
    this.allowAudioTracks = true,
    this.allowBrightnessControl = true,
    this.allowVolumeControl = true,
    this.allowGestureControls = true,
    this.allowScreenSleep = false,
    this.showControls = true,
    this.showThumbnail = true,
    this.showSkipIntro = false,
    this.showNextEpisode = false,
    this.rememberPlaybackPosition = true,
    this.enableAnalytics = true,
    this.enableHeartbeat = true,
    this.enableResumePlayback = true,
    this.enableOfflinePlayback = false,
    this.enableCasting = false,
    this.enableCache = false,
    this.isLive = false,
    this.isDrmProtected = false,
    this.heartbeatInterval = const Duration(seconds: 30),
    this.controlsHideDuration = const Duration(seconds: 4),
    this.skipDuration = const Duration(seconds: 10),
    this.bufferingTimeout = const Duration(seconds: 20),
    this.aspectRatio = 16 / 9,
    this.playbackSpeed = 1.0,
    this.backgroundColor = Colors.black,
  });

  PlayerConfig copyWith({
    bool? autoPlay,
    bool? looping,
    bool? allowFullScreen,
    bool? allowPip,
    bool? allowPlaybackSpeed,
    bool? allowQualitySelection,
    bool? allowSubtitles,
    bool? allowAudioTracks,
    bool? allowBrightnessControl,
    bool? allowVolumeControl,
    bool? allowGestureControls,
    bool? allowScreenSleep,
    bool? showControls,
    bool? showThumbnail,
    bool? showSkipIntro,
    bool? showNextEpisode,
    bool? rememberPlaybackPosition,
    bool? enableAnalytics,
    bool? enableHeartbeat,
    bool? enableResumePlayback,
    bool? enableOfflinePlayback,
    bool? enableCasting,
    bool? enableCache,
    bool? isLive,
    bool? isDrmProtected,
    Duration? heartbeatInterval,
    Duration? controlsHideDuration,
    Duration? skipDuration,
    Duration? bufferingTimeout,
    double? aspectRatio,
    double? playbackSpeed,
    Color? backgroundColor,
  }) {
    return PlayerConfig(
      autoPlay: autoPlay ?? this.autoPlay,
      looping: looping ?? this.looping,
      allowFullScreen:
      allowFullScreen ?? this.allowFullScreen,
      allowPip: allowPip ?? this.allowPip,
      allowPlaybackSpeed:
      allowPlaybackSpeed ??
          this.allowPlaybackSpeed,
      allowQualitySelection:
      allowQualitySelection ??
          this.allowQualitySelection,
      allowSubtitles:
      allowSubtitles ?? this.allowSubtitles,
      allowAudioTracks:
      allowAudioTracks ?? this.allowAudioTracks,
      allowBrightnessControl:
      allowBrightnessControl ??
          this.allowBrightnessControl,
      allowVolumeControl:
      allowVolumeControl ??
          this.allowVolumeControl,
      allowGestureControls:
      allowGestureControls ??
          this.allowGestureControls,
      allowScreenSleep:
      allowScreenSleep ?? this.allowScreenSleep,
      showControls: showControls ?? this.showControls,
      showThumbnail:
      showThumbnail ?? this.showThumbnail,
      showSkipIntro:
      showSkipIntro ?? this.showSkipIntro,
      showNextEpisode:
      showNextEpisode ?? this.showNextEpisode,
      rememberPlaybackPosition:
      rememberPlaybackPosition ??
          this.rememberPlaybackPosition,
      enableAnalytics:
      enableAnalytics ?? this.enableAnalytics,
      enableHeartbeat:
      enableHeartbeat ?? this.enableHeartbeat,
      enableResumePlayback:
      enableResumePlayback ??
          this.enableResumePlayback,
      enableOfflinePlayback:
      enableOfflinePlayback ??
          this.enableOfflinePlayback,
      enableCasting:
      enableCasting ?? this.enableCasting,
      enableCache: enableCache ?? this.enableCache,
      isLive: isLive ?? this.isLive,
      isDrmProtected:
      isDrmProtected ?? this.isDrmProtected,
      heartbeatInterval:
      heartbeatInterval ??
          this.heartbeatInterval,
      controlsHideDuration:
      controlsHideDuration ??
          this.controlsHideDuration,
      skipDuration:
      skipDuration ?? this.skipDuration,
      bufferingTimeout:
      bufferingTimeout ??
          this.bufferingTimeout,
      aspectRatio:
      aspectRatio ?? this.aspectRatio,
      playbackSpeed:
      playbackSpeed ?? this.playbackSpeed,
      backgroundColor:
      backgroundColor ?? this.backgroundColor,
    );
  }
}