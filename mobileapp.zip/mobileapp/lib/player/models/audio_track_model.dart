enum AudioTrackType {
  stereo,
  surround51,
  surround71,
  dolbyAtmos,
  commentary,
  descriptive,
}

class AudioTrackModel {
  final String id;
  final String languageCode;
  final String languageName;
  final String label;

  final AudioTrackType type;

  final bool isDefault;
  final bool isSelected;

  final String? codec;
  final int? bitrate;

  const AudioTrackModel({
    required this.id,
    required this.languageCode,
    required this.languageName,
    required this.label,
    this.type = AudioTrackType.stereo,
    this.isDefault = false,
    this.isSelected = false,
    this.codec,
    this.bitrate,
  });

  AudioTrackModel copyWith({
    String? id,
    String? languageCode,
    String? languageName,
    String? label,
    AudioTrackType? type,
    bool? isDefault,
    bool? isSelected,
    String? codec,
    int? bitrate,
  }) {
    return AudioTrackModel(
      id: id ?? this.id,
      languageCode: languageCode ?? this.languageCode,
      languageName: languageName ?? this.languageName,
      label: label ?? this.label,
      type: type ?? this.type,
      isDefault: isDefault ?? this.isDefault,
      isSelected: isSelected ?? this.isSelected,
      codec: codec ?? this.codec,
      bitrate: bitrate ?? this.bitrate,
    );
  }

  factory AudioTrackModel.fromJson(
      Map<String, dynamic> json) {
    return AudioTrackModel(
      id: json["id"],
      languageCode: json["languageCode"],
      languageName: json["languageName"],
      label: json["label"],
      type: AudioTrackType.values.firstWhere(
            (e) =>
        e.name ==
            (json["type"] ?? "stereo"),
        orElse: () => AudioTrackType.stereo,
      ),
      isDefault: json["isDefault"] ?? false,
      isSelected: json["isSelected"] ?? false,
      codec: json["codec"],
      bitrate: json["bitrate"],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "id": id,
      "languageCode": languageCode,
      "languageName": languageName,
      "label": label,
      "type": type.name,
      "isDefault": isDefault,
      "isSelected": isSelected,
      "codec": codec,
      "bitrate": bitrate,
    };
  }
}