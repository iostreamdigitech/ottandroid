enum SubtitleFormat {
  webvtt,
  srt,
  ass,
  ssa,
  ttml,
}

class SubtitleModel {
  final String id;

  /// en, ta, hi, fr...
  final String languageCode;

  /// English, Tamil...
  final String languageName;

  /// Display Name
  final String label;

  /// Subtitle URL
  final String url;

  final SubtitleFormat format;

  /// Default subtitle
  final bool isDefault;

  /// Currently selected
  final bool isSelected;

  /// Forced subtitle
  final bool isForced;

  /// Hearing impaired
  final bool isSDH;

  const SubtitleModel({
    required this.id,
    required this.languageCode,
    required this.languageName,
    required this.label,
    required this.url,
    this.format = SubtitleFormat.webvtt,
    this.isDefault = false,
    this.isSelected = false,
    this.isForced = false,
    this.isSDH = false,
  });

  SubtitleModel copyWith({
    String? id,
    String? languageCode,
    String? languageName,
    String? label,
    String? url,
    SubtitleFormat? format,
    bool? isDefault,
    bool? isSelected,
    bool? isForced,
    bool? isSDH,
  }) {
    return SubtitleModel(
      id: id ?? this.id,
      languageCode: languageCode ?? this.languageCode,
      languageName: languageName ?? this.languageName,
      label: label ?? this.label,
      url: url ?? this.url,
      format: format ?? this.format,
      isDefault: isDefault ?? this.isDefault,
      isSelected: isSelected ?? this.isSelected,
      isForced: isForced ?? this.isForced,
      isSDH: isSDH ?? this.isSDH,
    );
  }

  factory SubtitleModel.fromJson(
      Map<String, dynamic> json) {
    return SubtitleModel(
      id: json["id"],
      languageCode: json["languageCode"],
      languageName: json["languageName"],
      label: json["label"],
      url: json["url"],
      format: SubtitleFormat.values.firstWhere(
            (e) => e.name == (json["format"] ?? "webvtt"),
        orElse: () => SubtitleFormat.webvtt,
      ),
      isDefault: json["isDefault"] ?? false,
      isSelected: json["isSelected"] ?? false,
      isForced: json["isForced"] ?? false,
      isSDH: json["isSDH"] ?? false,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "id": id,
      "languageCode": languageCode,
      "languageName": languageName,
      "label": label,
      "url": url,
      "format": format.name,
      "isDefault": isDefault,
      "isSelected": isSelected,
      "isForced": isForced,
      "isSDH": isSDH,
    };
  }
}