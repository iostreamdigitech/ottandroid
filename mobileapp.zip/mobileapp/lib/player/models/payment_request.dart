import '../../models/subscription_plan.dart';

/// What the user is buying.
enum PurchaseKind {
  subscription,
  rental,
}

/// One purchase, described well enough to create an order, open the gateway
/// and word the result screen.
///
/// Note what is absent: no amount is ever sent to the backend. The order
/// payload names *what* is being bought, and the server prices it.
/// [displayAmount] exists only for analytics and on-screen copy.
class PaymentRequest {
  final PurchaseKind kind;

  /// Body of the create-order call.
  final Map<String, dynamic> orderPayload;

  /// Shown as the line item on the Razorpay sheet.
  final String description;

  /// Named on the progress placeholder.
  final String itemTitle;

  /// Result-screen copy for a verified payment.
  final String successMessage;

  /// Label of the button on the success screen.
  final String continueLabel;

  final double displayAmount;
  final String currency;

  /// Id reported to analytics.
  final String analyticsItemId;

  /// Extra context attached to the Razorpay order.
  final Map<String, String> gatewayNotes;

  const PaymentRequest({
    required this.kind,
    required this.orderPayload,
    required this.description,
    required this.itemTitle,
    required this.successMessage,
    required this.continueLabel,
    required this.displayAmount,
    required this.currency,
    required this.analyticsItemId,
    required this.gatewayNotes,
  });

  /// A subscription plan purchase.

  factory PaymentRequest.subscription({
    required SubscriptionPlan plan,
    required String billingCycle,
    required String requestId,
  }) {
    return PaymentRequest(
      kind: PurchaseKind.subscription,

      orderPayload: {
        'purchaseType': 'SUBSCRIPTION',
        'subscriptionPlanId': plan.id,
        'planCode': plan.planCode,
        'requestId': requestId,
      },

      description: plan.planName,
      itemTitle: plan.planName,

      successMessage:
      'Your subscription has been activated successfully.',
      continueLabel: 'Continue Watching',

      displayAmount: plan.price,
      currency: plan.currency,
      analyticsItemId: plan.id.toString(),

      gatewayNotes: {
        'purchase_type': 'SUBSCRIPTION',
        'plan_id': plan.id.toString(),
        'plan_code': plan.planCode,
        'billing_cycle': billingCycle,
        'request_id': requestId,
      },
    );
  }
  /// A single-title rental.
  factory PaymentRequest.rental({
    required int contentId,
    required String title,
    required double amount,
    required String currency,
  }) {
    return PaymentRequest(
      kind: PurchaseKind.rental,

      orderPayload: {
        'purchaseType': 'RENT',
        'contentId': contentId,
      },

      description: 'Rental - $title',
      itemTitle: title,

      successMessage: 'Your rental is ready. Enjoy the show!',
      continueLabel: 'Watch Now',

      displayAmount: amount,
      currency: currency,
      analyticsItemId: contentId.toString(),

      gatewayNotes: {
        'purchase_type': 'RENT',
        'content_id': contentId.toString(),
      },
    );
  }
}
