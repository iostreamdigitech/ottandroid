class VideoQuality {
  final String id;

  final String label;

  final String url;

  final int width;

  final int height;

  final int bitrate;

  final bool isAuto;

  const VideoQuality({
    required this.id,
    required this.label,
    required this.url,
    required this.width,
    required this.height,
    required this.bitrate,
    this.isAuto = false,
  });
}