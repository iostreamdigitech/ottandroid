/// Where a subscription purchase currently is.
///
/// The whole payment UI is derived from this single value, so there is exactly
/// one place that decides what the user is looking at.
enum PaymentStatus {
  /// Nothing in flight - subscription plans are interactive.
  idle,

  /// Create-order API in flight.
  creatingOrder,

  /// Order created, handing off to the Razorpay checkout sheet.
  openingRazorpay,

  /// Razorpay reported success, verify-transaction API in flight.
  verifying,

  /// Backend verified the transaction. Only this means "subscribed".
  success,

  /// Anything that stopped the flow, including a user cancellation.
  failed,
}

/// Why a payment ended in [PaymentStatus.failed].
///
/// Drives the wording on the failure screen - "cancelled" and "we took your
/// money but could not verify it" are very different messages to receive.
enum PaymentFailureKind {
  /// Create-order API failed, so Razorpay was never opened.
  orderCreation,

  /// User dismissed the Razorpay sheet.
  cancelled,

  /// Razorpay itself reported a failure.
  gateway,

  /// Razorpay succeeded but the backend did not verify the transaction.
  verification,

  /// Anything we did not anticipate.
  unexpected,
}

extension PaymentStatusX on PaymentStatus {
  /// A step is running - show the progress placeholder.
  bool get isInProgress =>
      this == PaymentStatus.creatingOrder ||
      this == PaymentStatus.openingRazorpay ||
      this == PaymentStatus.verifying;

  /// The flow finished - show the result screen.
  bool get isTerminal =>
      this == PaymentStatus.success || this == PaymentStatus.failed;

  /// Plans must not be tappable while anything payment-related is on screen.
  bool get blocksPlanSelection => this != PaymentStatus.idle;

  /// Heading for the progress placeholder.
  String get progressTitle {
    switch (this) {
      case PaymentStatus.creatingOrder:
        return 'Creating Order';
      case PaymentStatus.openingRazorpay:
        return 'Opening Payment';
      case PaymentStatus.verifying:
        return 'Verifying Payment';
      default:
        return '';
    }
  }

  /// Sub-heading for the progress placeholder.
  String get progressMessage {
    switch (this) {
      case PaymentStatus.creatingOrder:
      case PaymentStatus.openingRazorpay:
        return 'Please wait...';
      case PaymentStatus.verifying:
        return 'Please do not close the application...';
      default:
        return '';
    }
  }
}

extension PaymentFailureKindX on PaymentFailureKind {
  String get title {
    switch (this) {
      case PaymentFailureKind.cancelled:
        return 'Payment Cancelled';
      case PaymentFailureKind.verification:
        return 'Payment Verification Failed';
      case PaymentFailureKind.orderCreation:
      case PaymentFailureKind.gateway:
      case PaymentFailureKind.unexpected:
        return 'Payment Failed';
    }
  }

  String get message {
    switch (this) {
      case PaymentFailureKind.orderCreation:
        return 'Unable to create payment order.\nPlease try again.';
      case PaymentFailureKind.cancelled:
        return 'No amount has been confirmed as successfully paid.';
      case PaymentFailureKind.gateway:
        return 'Your payment could not be completed.';
      case PaymentFailureKind.verification:
        return 'We could not verify your payment.\n'
            'Please try again or contact support.';
      case PaymentFailureKind.unexpected:
        return 'We could not complete or verify your payment.';
    }
  }

  /// Analytics reason code.
  String get analyticsReason {
    switch (this) {
      case PaymentFailureKind.orderCreation:
        return 'order_creation_failed';
      case PaymentFailureKind.cancelled:
        return 'cancelled_by_user';
      case PaymentFailureKind.gateway:
        return 'gateway_error';
      case PaymentFailureKind.verification:
        return 'verification_failed';
      case PaymentFailureKind.unexpected:
        return 'unexpected_error';
    }
  }
}
