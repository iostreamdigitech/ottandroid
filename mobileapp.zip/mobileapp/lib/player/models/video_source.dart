import '../services/drm_service.dart';
import 'audio_track_model.dart';

import 'player_config.dart';
import 'subtitle_model.dart';

enum VideoType {
  movie,
  episode,
  trailer,
  live,
  sports,
  music,
}

class VideoSource {
  final String id;
  final String title;
  final String url;

  final String? description;
  final String? poster;
  final String? thumbnail;

  final VideoType type;

  final bool isLive;
  final bool isOffline;
  final bool isDrmProtected;

  final DRMConfig? drm;

  final Duration? resumePosition;
  final Duration? duration;

  final Map<String, String> headers;

  final List<SubtitleModel> subtitles;
  final List<AudioTrackModel> audioTracks;

  final PlayerConfig config;

  /// Analytics metadata
  final String? category;
  final String? genre;
  final String? language;
  final String? seasonId;
  final String? episodeId;

  const VideoSource({
    required this.id,
    required this.title,
    required this.url,

    this.description,
    this.poster,
    this.thumbnail,

    this.type = VideoType.movie,

    this.isLive = false,
    this.isOffline = false,
    this.isDrmProtected = false,

    this.drm,

    this.resumePosition,
    this.duration,

    this.headers = const {},

    this.subtitles = const [],
    this.audioTracks = const [],

    this.config = const PlayerConfig(),

    this.category,
    this.genre,
    this.language,
    this.seasonId,
    this.episodeId,
  });

  VideoSource copyWith({
    String? id,
    String? title,
    String? url,
    String? description,
    String? poster,
    String? thumbnail,
    VideoType? type,
    bool? isLive,
    bool? isOffline,
    bool? isDrmProtected,
    DRMConfig? drm,
    Duration? resumePosition,
    Duration? duration,
    Map<String, String>? headers,
    List<SubtitleModel>? subtitles,
    List<AudioTrackModel>? audioTracks,
    PlayerConfig? config,
    String? category,
    String? genre,
    String? language,
    String? seasonId,
    String? episodeId,
  }) {
    return VideoSource(
      id: id ?? this.id,
      title: title ?? this.title,
      url: url ?? this.url,
      description: description ?? this.description,
      poster: poster ?? this.poster,
      thumbnail: thumbnail ?? this.thumbnail,
      type: type ?? this.type,
      isLive: isLive ?? this.isLive,
      isOffline: isOffline ?? this.isOffline,
      isDrmProtected:
      isDrmProtected ?? this.isDrmProtected,
      drm: drm ?? this.drm,
      resumePosition:
      resumePosition ?? this.resumePosition,
      duration: duration ?? this.duration,
      headers: headers ?? this.headers,
      subtitles: subtitles ?? this.subtitles,
      audioTracks:
      audioTracks ?? this.audioTracks,
      config: config ?? this.config,
      category: category ?? this.category,
      genre: genre ?? this.genre,
      language: language ?? this.language,
      seasonId: seasonId ?? this.seasonId,
      episodeId: episodeId ?? this.episodeId,
    );
  }

  factory VideoSource.fromJson(
      Map<String, dynamic> json) {
    return VideoSource(
      id: json["id"],
      title: json["title"],
      url: json["url"],
      description: json["description"],
      poster: json["poster"],
      thumbnail: json["thumbnail"],
      isLive: json["isLive"] ?? false,
      isOffline: json["isOffline"] ?? false,
      isDrmProtected:
      json["isDrmProtected"] ?? false,
      category: json["category"],
      genre: json["genre"],
      language: json["language"],
      seasonId: json["seasonId"],
      episodeId: json["episodeId"],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "id": id,
      "title": title,
      "url": url,
      "description": description,
      "poster": poster,
      "thumbnail": thumbnail,
      "isLive": isLive,
      "isOffline": isOffline,
      "isDrmProtected": isDrmProtected,
      "category": category,
      "genre": genre,
      "language": language,
      "seasonId": seasonId,
      "episodeId": episodeId,
    };
  }
}