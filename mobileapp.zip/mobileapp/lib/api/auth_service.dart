import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import 'api_service.dart';
import 'crypto_service.dart';

class AuthService {
  AuthService._();

  static final AuthService instance = AuthService._();

  static const FlutterSecureStorage _storage =
  FlutterSecureStorage();
  Future<Map<String, dynamic>> verifyOtp({
    required int userId,
    required String otp,
    required String purpose,
  }) async {
    try {
      final response = await ApiService.instance.dio.post(
        "/iam/api/users/auth/2fa/verify-otp",
        data: {
          "userId": userId,
          "otpCode": otp,
          "purpose": purpose,
        },
      );

      final payload = response.data;

      // Save JWT only for LOGIN
      if (purpose == "LOGIN" && payload["success"] == true) {
        final data = payload["data"] ?? {};

        final token = data["token"];

        if (token != null) {
          await _storage.write(
            key: "ott_token",
            value: token.toString(),
          );
        }

        // Optional: Save user profile
        if (data["user"] != null) {
          await _storage.write(
            key: "ott_user",
            value: jsonEncode(data["user"]),
          );
        }
      }

      return payload;
    } on DioException catch (e) {
      return e.response?.data ??
          {
            "success": false,
            "message": "OTP Verification Failed",
          };
    }
  }
  Future<Map<String, dynamic>> register(
      Map<String, dynamic> user) async {

    await CryptoService.initSessionKeys();

    try {

      debugPrint("[Auth] Register Request : $user");

      final response =
      await ApiService.instance.dio.post(
        "/iam/api/users/auth/register",
        data: user,
      );

      debugPrint(
          "[Auth] Register Response : ${response.data}");

      final payload = response.data;

      final token =
          payload["token"] ??
              payload["accessToken"];

      final userInfo = payload["user"];

      if (token != null &&
          token.toString().isNotEmpty) {
        await _storage.write(
          key: "ott_token",
          value: token.toString(),
        );
      }

      final data = payload["data"] ?? {};

      return {
        "success": payload["success"] ?? false,
        "message": payload["message"],
        "userId": data["userId"],
        "maskedEmail": data["maskedEmail"],
        "maskedMobile": data["maskedMobile"],
        "otpExpiresInSeconds": data["otpExpiresInSeconds"],
      };

    } on DioException catch (e) {

      debugPrint(
          "[Auth] Register Error : ${e.response?.data}");

      if (e.response?.statusCode == 401) {
        CryptoService.invalidatePublicKeyCache();
      }

      rethrow;
    }
  }
  Future<Map<String, dynamic>> socialLogin({
    required String provider,
    required String idToken,
    required String accessToken,
  }) async {
    await CryptoService.initSessionKeys();

    try {
      final request = {
        "provider": provider,
        "idToken": idToken,
        "accessToken": accessToken,
      };

      print("[Auth] Social Login Request: $request");

      final response = await ApiService.instance.dio.post(
        "/iam/api/users/auth/social-login",
        data: request,
      );

      print("[Auth] Social Login Response: ${response.data}");

      final payload = response.data;


      final data = payload["data"] as Map<String, dynamic>? ?? {};

      final token = data["token"] ?? data["accessToken"];
      final user = data["user"];

      if (token != null && token.toString().isNotEmpty) {
        await _storage.write(
          key: "ott_token",
          value: token.toString(),
        );
      }

      return {
        "success": payload["success"] ?? false,
        "message": payload["message"],
        "token": token,
        "user": user,
      };
    } on DioException catch (e) {
      debugPrint("[Auth] Social Login Error: ${e.response?.data}");

      if (e.response?.statusCode == 401) {
        CryptoService.invalidatePublicKeyCache();
      }

      rethrow;
    }
  }

  /// Login
  Future<Map<String, dynamic>> login(
      Map<String, dynamic> credentials) async {

    await CryptoService.initSessionKeys();

    try {
      debugPrint("[Auth] Login Request : ${credentials["email"]}");

      final response = await ApiService.instance.dio.post(
        "/iam/api/users/auth/login",
        data: credentials,
      );

      debugPrint("[Auth] Login Response : ${response.data}");

      final payload = response.data;
      final level1 = payload["data"] ?? {};
      final level2 = level1["data"] ?? {};

      // 2FA Login
      if (level1["twoFaRequired"] == true ||
          level2["twoFaRequired"] == true) {

        return {
          "success": true,
          "twoFaRequired": true,
          "userId": level2["userId"],
          "purpose": level2["purpose"],
          "maskedEmail": level2["maskedEmail"],
          "maskedMobile": level2["maskedMobile"],
          "otpExpiresInSeconds": level2["otpExpiresInSeconds"],
          "message": payload["message"],
        };
      }

      // Normal Login
      final token = level1["token"] ?? payload["token"];
      final user = level1["user"] ?? payload["user"];

      if (token != null) {
        await _storage.write(
          key: "ott_token",
          value: token.toString(),
        );
      }

      return {
        "success": payload["success"] ?? true,
        "twoFaRequired": false,
        "token": token,
        "user": user,
        "message": payload["message"],
      };

    } on DioException catch (e) {
      debugPrint("[Auth] Login Error : ${e.response?.data}");

      if (e.response?.statusCode == 401) {
        CryptoService.invalidatePublicKeyCache();
      }

      rethrow;
    }
  }

  /// Logout
  Future<void> logout() async {

   /* try {
      await ApiService.instance.dio.post(
        "/auth/logout",
      );
    } catch (_) {}*/

    await _storage.delete(key: "ott_token");

    CryptoService.clearSessionKeys();
  }

  /// Profile
  Future<dynamic> getProfile() async {

    final response =
    await ApiService.instance.dio.get(
      "/auth/profile",
    );

    return response.data;
  }

  /// Get JWT Token
  Future<String?> getToken() async {

    return await _storage.read(
      key: "ott_token",
    );
  }

  /// Check Login Status
  Future<bool> isLoggedIn() async {

    final token = await getToken();

    return token != null &&
        token.isNotEmpty;
  }

  /// Clear Local Session
  Future<void> clearSession() async {

    await _storage.deleteAll();

    CryptoService.clearSessionKeys();
  }
}