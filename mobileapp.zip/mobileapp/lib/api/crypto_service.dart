import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';

import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';

import 'package:basic_utils/basic_utils.dart';
import 'package:crypto/crypto.dart' as crypto hide Hmac;
import 'package:cryptography/cryptography.dart' as cryptography;
import 'package:fast_rsa/fast_rsa.dart' as rsa;
import 'package:dio/dio.dart';

import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:pointycastle/asymmetric/oaep.dart';
import 'package:pointycastle/asymmetric/rsa.dart';
import 'package:webcrypto/webcrypto.dart';



class CryptoService {
  static const gatewayUrl = "https://apiottone.ottone.in/api-gateway";
  static RSAPublicKey? _publicKey;
  static const gatewayPathPrefix = "/api-gateway";
  static const FlutterSecureStorage _storage =
  FlutterSecureStorage();

  static const _sessionKeyStorage = "aes_session_key";
  static const apiToken = "dev-api-token-001";

  static const secretKey =
      "d3vHmacS3cretK3yVal1d4t10nX9ZpQ7";

  static const channel = "WEB";

  static String? _publicKeyPem;

  static String? _keyId;

  static DateTime? _expiry;

  static cryptography.SecretKey? _sessionKey;
  static String sha256Hex(Uint8List data) {
    return crypto.sha256.convert(data).toString();
  }
  static Future<String> hmacSha256Base64(
      String secret,
      String message,
      ) async {
    final algorithm = cryptography.Hmac.sha256();

    final mac = await algorithm.calculateMac(
      utf8.encode(message),
      secretKey: cryptography.SecretKey(utf8.encode(secret)),
    );

    return base64Encode(mac.bytes);
  }
  static void invalidatePublicKeyCache() {
    _publicKeyPem = null;
    _publicKey = null;
    _keyId = null;
    _expiry = null;
  }
  static Future<Map<String, String>> buildHmacHeaders(
      String requestUri,
      Uint8List bodyBytes,
      ) async {

    final timestamp =
    (DateTime.now().millisecondsSinceEpoch ~/ 1000)
        .toString();

    final nonce = _generateNonce();

    final requestHash = sha256Hex(bodyBytes);

    final message =
        apiToken +
            channel +
            requestUri +
            timestamp +
            nonce +
            requestHash;

    final signature =
    await hmacSha256Base64(secretKey, message);

    return {
      "apiToken": apiToken,
      "channel": channel,
      "timestamp": timestamp,
      "nonce": nonce,
      "signature": signature,
    };
  }

  static String _generateNonce() {
    final random = Random.secure();

    return List.generate(
        16,
            (_) => random.nextInt(16).toRadixString(16))
        .join();
  }
  static Future<void> fetchPublicKey() async {

    if (_publicKeyPem != null &&
        _expiry != null &&
        _expiry!.isAfter(DateTime.now())) {
      return;
    }

    final headers = await buildHmacHeaders(
        "$gatewayPathPrefix/gateway/security/public-key",
        Uint8List(0));

    final dio = Dio();

    final response = await dio.get(
      "$gatewayUrl/gateway/security/public-key",
      options: Options(headers: headers),
    );

    final json = response.data;
    debugPrint("========================================");
    debugPrint("🚀 API REQUEST");
    debugPrint("publicMethod : ${response}");

    debugPrint("========================================");

    _keyId = json["keyId"];

    _publicKeyPem = json["publicKey"];

    _expiry = DateTime.parse(json["expiry"]);
  }
  static Future<void> initSessionKeys() async {
    await fetchPublicKey();

    if (_sessionKey != null) {
      return;
    }

    final storedKey =
    await _storage.read(key: _sessionKeyStorage);

    if (storedKey != null) {
      final bytes = base64Decode(storedKey);

      _sessionKey =
          cryptography.SecretKey(bytes);

      debugPrint("AES Session Key Loaded");
      return;
    }

    final algorithm = cryptography.AesGcm.with256bits();

    _sessionKey =
    await algorithm.newSecretKey();

    final rawKey =
    await _sessionKey!.extractBytes();

    await _storage.write(
      key: _sessionKeyStorage,
      value: base64Encode(rawKey),
    );

    debugPrint("AES Session Key Generated");
  }

  static Future<Map<String, dynamic>> encryptPayload(dynamic payload) async {
    //------------------------------------
    // Use existing session AES key
    //------------------------------------
    await initSessionKeys();

    final aesKey = _sessionKey!;
    debugPrint("AES Session Key Loaded $aesKey");
    //------------------------------------
    // AES GCM
    //------------------------------------

    final algorithm = cryptography.AesGcm.with256bits();

    final nonce = algorithm.newNonce();

    final plainText = payload is String
        ? payload
        : jsonEncode(payload);

    final secretBox = await algorithm.encrypt(
      utf8.encode(plainText),
      secretKey: aesKey,
      nonce: nonce,
    );

    //------------------------------------
    // Export AES Key
    //------------------------------------

    final rawAesKey = await aesKey.extractBytes();

    _publicKey =
        CryptoUtils.rsaPublicKeyFromPem(_publicKeyPem!);


    final encryptedKey =
    rsaEncrypt(rawAesKey, _publicKeyPem!);

    //------------------------------------
    // Cipher + Tag
    //------------------------------------

    final encryptedBytes = Uint8List.fromList([
      ...secretBox.cipherText,
      ...secretBox.mac.bytes,
    ]);

    return {
      "encryptedKey": base64Encode(await encryptedKey),
      "encryptedData": base64Encode(encryptedBytes),
      "iv": base64Encode(nonce),
      "keyId": _keyId,
    };
  }


  static Future<Uint8List> rsaEncrypt(
      List<int> data,
      String publicKeyPem,
      ) async {
    if (kIsWeb) {
      return _rsaEncryptWeb(data, publicKeyPem);
    }

    return _rsaEncrypt(data, publicKeyPem);
  }

  static Future<Uint8List> _rsaEncryptWeb(
      List<int> data,
      String publicKeyPem,
      ) async {
    final RSAPublicKey publicKey =
    CryptoUtils.rsaPublicKeyFromPem(publicKeyPem);

    final cipher = OAEPEncoding.withSHA256(RSAEngine())
      ..init(
        true,
        PublicKeyParameter<RSAPublicKey>(publicKey),
      );

    return Uint8List.fromList(
      cipher.process(Uint8List.fromList(data)),
    );
  }
  static  Future<Uint8List> _rsaEncrypt(
      List<int> data,
      String publicKeyPem,
      ) async {
    final encrypted = await rsa.RSA.encryptOAEPBytes(
      Uint8List.fromList(data),
      "",
      rsa.Hash.SHA256,
      publicKeyPem,
    );

    return Uint8List.fromList(encrypted);
  }
  static Future<dynamic> decryptResponse(

      Map<String, dynamic> response,
      ) async {
    if (_sessionKey == null) {
      final storedKey =
      await _storage.read(key: _sessionKeyStorage);

      if (storedKey == null) {
        throw Exception("AES Session Key not found.");
      }

      _sessionKey = cryptography.SecretKey(
          base64Decode(storedKey));
    }

    final algorithm = cryptography.AesGcm.with256bits();

    final nonce = base64Decode(response["iv"]);

    final encryptedBytes =
    base64Decode(response["encryptedData"]);

    // Last 16 bytes = GCM authentication tag
    final cipherText =
    encryptedBytes.sublist(0, encryptedBytes.length - 16);

    final macBytes =
    encryptedBytes.sublist(encryptedBytes.length - 16);

    final decrypted = await algorithm.decrypt(
      cryptography.SecretBox(
        cipherText,
        nonce: nonce,
        mac: cryptography.Mac(macBytes),
      ),
      secretKey: _sessionKey!,
    );

    return jsonDecode(utf8.decode(decrypted));
  }

  static Future<void> clearSessionKeys() async {

    _publicKeyPem = null;
    _publicKey = null;
    _keyId = null;
    _expiry = null;
    _sessionKey = null;

    await _storage.delete(
        key: _sessionKeyStorage);
  }
}