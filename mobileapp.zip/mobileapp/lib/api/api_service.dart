import 'dart:convert';
import 'dart:typed_data';

import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import '../core/constants/api_constants.dart';
import 'crypto_service.dart';
import 'loading_service.dart';

class ApiService {
  ApiService._();

  static final ApiService instance = ApiService._();

  final FlutterSecureStorage _storage = const FlutterSecureStorage();

  late final Dio dio = Dio(
    BaseOptions(
      baseUrl:ApiConstants.baseUrl ,
      connectTimeout: const Duration(seconds: 10),
      receiveTimeout: const Duration(seconds: 10),
      headers: {
        'Content-Type': 'application/json',
      },
    ),
  )..interceptors.add(
    InterceptorsWrapper(
      onRequest: _onRequest,
      onResponse: _onResponse,
      onError: _onError,
    ),
  );

  /// Request-level opt-out from the global [LoadingService] overlay.
  ///
  /// Pass `extra: {ApiService.hideLoaderKey: true}` on requests that render
  /// their own progress UI - the payment flow, for instance, drives a
  /// full-screen payment placeholder and must not be covered by the generic
  /// "Please wait..." dialog.
  static const String hideLoaderKey = "hideLoader";

  static bool hidesLoader(RequestOptions options) {
    return options.extra[hideLoaderKey] == true;
  }

  static const encryptMethods = {
    'POST',
    'PUT',
    'PATCH',
  };

  String getRequestPath(RequestOptions options) {
    try {
      return options.uri.path;
    } catch (_) {
      return options.path;
    }
  }

  Future<void> _onRequest(
      RequestOptions options,
      RequestInterceptorHandler handler,
      ) async {
    //---------------------------------------
    // Attach Bearer Token
    //---------------------------------------
    final token = await _storage.read(key: "ott_token");

    if (!hidesLoader(options)) {
      LoadingService.show();
    }

    if (token != null &&
        token.isNotEmpty &&
        token != "undefined" &&
        token != "null") {
      options.headers["Authorization"] = "Bearer $token";
    } else {
      await _storage.delete(key: "ott_token");
    }


    debugPrint("========================================");
    debugPrint("🚀 API REQUEST");
    debugPrint("Method : ${options.method}");
    debugPrint("Base URL : ${options.baseUrl}");
    debugPrint("Path : ${options.path}");
    debugPrint("Full URL : ${options.uri}");
    if (options.data != null) {
      debugPrint("Request Body (Plain):");
      debugPrint(const JsonEncoder.withIndent("  ").convert(options.data));
    }
    debugPrint("========================================");
    final method = options.method.toUpperCase();
    final requestUri = getRequestPath(options);

    Uint8List bodyBytes = Uint8List(0);

    //---------------------------------------
    // Encrypt Request Body
    //---------------------------------------
    if (encryptMethods.contains(method) && options.data != null) {
      if (options.data is FormData) {
        // Multipart request
        bodyBytes = Uint8List(0);
      } else {
        print("🔐 API Request: $method $requestUri");
        print("Plain Request:");
        print(const JsonEncoder.withIndent("  ").convert(options.data));

        final encrypted =
        await CryptoService.encryptPayload(options.data);

        final encryptedJson = jsonEncode(encrypted);
        print("encryptedJson Request:");
        print(encrypted);
        options.data = encrypted;

        options.headers["Content-Type"] = "application/json";

        bodyBytes = Uint8List.fromList(utf8.encode(encryptedJson));
      }
    }

    //---------------------------------------
    // Build HMAC Headers
    //---------------------------------------
    final hmacHeaders = await CryptoService.buildHmacHeaders(
      requestUri,
      bodyBytes,
    );

    options.headers.addAll(hmacHeaders);
    debugPrint("Headers:");
    options.headers.forEach((key, value) {
      debugPrint("$key : $value");
    });
    handler.next(options);
  }

  Future<void> _onResponse(
      Response response,
      ResponseInterceptorHandler handler,
      ) async {

    debugPrint("========================================");
    debugPrint("🚀 API RESPONSE");
    debugPrint(" response.data : ${ response.data}");


    debugPrint("========================================");
    if (
        response.data is Map &&
        response.data["encryptedData"] != null &&
        response.data["iv"] != null) {
      try {
        final decrypted =
        await CryptoService.decryptResponse(response.data);

        response.data = decrypted;
      } catch (e) {
        handler.reject(
          DioException(
            requestOptions: response.requestOptions,
            error: e,
          ),
        );
        return;
      }
    }
    if (!hidesLoader(response.requestOptions)) {
      LoadingService.hide();
    }

    handler.next(response);
  }

  Future<void> _onError(
      DioException err,
      ErrorInterceptorHandler handler,
      ) async {
    print(
      "[API] Error ${err.response?.statusCode} ${err.requestOptions.path}",
    );

    print(err.response?.data.toString());
    if (!hidesLoader(err.requestOptions)) {
      LoadingService.hide();
    }

    final status = err.response?.statusCode;

    if (status == 401 || status == 403) {
      await _storage.deleteAll();

      // Navigate to Login Screen
      // navigatorKey.currentState?.pushNamedAndRemoveUntil("/", (r) => false);
    }

    handler.next(err);
  }

  void operator [](String other) {}
}