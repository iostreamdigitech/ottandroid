import 'package:dio/dio.dart';

import 'loading_service.dart';

class LoaderInterceptor extends Interceptor {
  @override
  void onRequest(RequestOptions options, RequestInterceptorHandler handler) {
   // LoadingService.show();
    super.onRequest(options, handler);
  }

  @override
  void onResponse(Response response, ResponseInterceptorHandler handler) {
    LoadingService.hide();
    super.onResponse(response, handler);
  }

  @override
  void onError(DioException err, ErrorInterceptorHandler handler) {
    LoadingService.hide();
    super.onError(err, handler);
  }
}