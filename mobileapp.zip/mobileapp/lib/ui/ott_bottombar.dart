import 'dart:ui';
import 'package:flutter/material.dart';

class OTTBottomBar extends StatelessWidget {
  final int currentIndex;
  final ValueChanged<int> onChanged;

  const OTTBottomBar({
    super.key,
    required this.currentIndex,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      minimum: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(28),
        child: BackdropFilter(
          filter: ImageFilter.blur(
            sigmaX: 18,
            sigmaY: 18,
          ),
          child: Container(
            height: 72,
            decoration: BoxDecoration(
              color: const Color(0xff081326).withOpacity(.92),
              borderRadius: BorderRadius.circular(28),
              border: Border.all(
                color: Colors.white10,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(.35),
                  blurRadius: 24,
                  offset: const Offset(0, 12),
                )
              ],
            ),
            child: Row(
              children: [
                Expanded(
                    child: _item(
                        0,
                        Icons.home_rounded,
                        "Home")),

                Expanded(
                    child: _item(
                        1,
                        Icons.search_rounded,
                        "Search")),

                Expanded(
                    child: _item(
                        2,
                        Icons.grid_view_rounded,
                        "OTTONE")),

                Expanded(
                    child: _item(
                        3,
                        Icons.download_rounded,
                        "Downloads")),

                Expanded(
                    child: _item(
                        4,
                        Icons.person_outline_rounded,
                        "Profile")),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _item(
      int index,
      IconData icon,
      String title,
      ) {
    final selected = currentIndex == index;

    return InkWell(
      borderRadius: BorderRadius.circular(22),
      onTap: () => onChanged(index),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        margin: const EdgeInsets.symmetric(
          horizontal: 4,
          vertical: 8,
        ),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          gradient: selected
              ? const LinearGradient(
            colors: [
              Color(0xff6D4CFF),
              Color(0xffFF2E63),
            ],
          )
              : null,
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [

            Icon(
              icon,
              size: 23,
              color: selected
                  ? Colors.white
                  : Colors.white54,
            ),

            const SizedBox(height: 4),

            Text(
              title,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w600,
                color: selected
                    ? Colors.white
                    : Colors.white54,
              ),
            ),
          ],
        ),
      ),
    );
  }
}