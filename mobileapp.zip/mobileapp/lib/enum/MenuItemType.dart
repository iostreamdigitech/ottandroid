enum MenuItemType {
  home,
  search,
  liveTv,
  movies,
  sports,
  myList,
  profile,
  settings, subscription,
}