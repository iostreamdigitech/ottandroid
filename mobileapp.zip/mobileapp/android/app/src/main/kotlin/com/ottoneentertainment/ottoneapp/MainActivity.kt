package com.ottoneentertainment.ottoneapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
